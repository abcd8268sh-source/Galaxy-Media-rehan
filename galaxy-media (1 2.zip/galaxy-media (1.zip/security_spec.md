# Galaxy Media — Firestore Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Strict PII & Telemetry Isolation**: Every user profile (`/users/{userId}`), session telemetry log (`/users/{userId}/sessions/{sessionId}`), and Gemini chat message (`/users/{userId}/chatMessages/{messageId}`) is strictly private to the authenticated, email-verified owner (`request.auth.uid == userId && request.auth.token.email_verified == true`) or the verified bootstrapped admin (`request.auth.token.email == 'abcd8268sh@gmail.com' && request.auth.token.email_verified == true`). No blanket `isSignedIn()` reads exist.
2. **Master Gate Relational Sync**: Subcollection writes (`sessions`, `chatMessages`) require the parent `/users/{userId}` document to exist (`exists(/databases/$(database)/documents/users/$(userId))`).
3. **Immutable Audit Logs & Timestamps**: All `createdAt` fields must strictly equal `request.time` on creation and can never be modified on update. Session logs (`UserSessionLog`) and chat messages (`ChatMessage`) are append-only (no `update` allowed; owner or verified admin may `delete`).
4. **Volumetric & Key Hardening**: Every string field enforces explicit min/max `.size()` bounds matching `firebase-blueprint.json`. All document IDs (`userId`, `sessionId`, `messageId`) must pass `isValidId()`. Every create enforces `hasAll` + `hasOnly` to block shadow fields, and profile updates enforce `affectedKeys().hasOnly(...)` + full `isValidUserProfile(incoming())`.
5. **No `get()`/`exists()` inside `allow list`**: Admin list queries rely strictly on `isBootstrappedAdmin()` (verified token email check) without per-document DB lookups.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Profile Read**: Anonymous client attempts `get /users/victimUid` or `list /users`. Expected: `PERMISSION_DENIED`.
2. **Cross-User PII Read (PII Blanket Test)**: Regular authenticated user `attackerUid` attempts `get /users/victimUid` or `list /users`. Expected: `PERMISSION_DENIED`.
3. **Admin Email Spoofing Attack (Email Spoofing Test)**: Authenticated user with `email: "abcd8268sh@gmail.com"` and `email_verified: false` attempts `list /users` or `get /users/victimUid`. Expected: `PERMISSION_DENIED`.
4. **Identity Spoofing on Create**: User `attackerUid` writes `/users/attackerUid` with `uid: "victimUid"`. Expected: `PERMISSION_DENIED`.
5. **Shadow Field Injection (Shadow Update Test)**: User creates `/users/attackerUid` with extra ghost field `isAdmin: true`. Expected: `PERMISSION_DENIED`.
6. **Immutable `createdAt` Tampering**: User updates `/users/attackerUid` attempting to overwrite `createdAt` or `uid`. Expected: `PERMISSION_DENIED`.
7. **Client-Forged Timestamp**: User creates `/users/attackerUid/sessions/sess_1` with a past client timestamp instead of `request.time`. Expected: `PERMISSION_DENIED`.
8. **Orphaned Subcollection Write (Master Gate)**: User creates `/users/newUid/sessions/sess_1` before `/users/newUid` exists. Expected: `PERMISSION_DENIED`.
9. **ID Poisoning Attack**: User creates `/users/attackerUid/sessions/<200-char-invalid-id!@#>` violating `isValidId()`. Expected: `PERMISSION_DENIED`.
10. **Value Poisoning / Oversized String**: User creates `/users/attackerUid/chatMessages/msg_1` with `content` length > 8000 bytes or invalid `role: "system"`. Expected: `PERMISSION_DENIED`.
11. **Forbidden Session Mutation**: User attempts `update` on an existing immutable `/users/attackerUid/sessions/sess_1` document. Expected: `PERMISSION_DENIED`.
12. **Cross-User Subcollection List Query**: Regular user `attackerUid` attempts `list /users/victimUid/sessions` or `list /users/victimUid/chatMessages`. Expected: `PERMISSION_DENIED`.
