import express from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import {fileURLToPath} from 'url';
import {GoogleGenAI, ThinkingLevel} from '@google/genai';
import {sendGalaxyInsightsWelcomeEmail} from './src/server/mailer.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.resolve(__dirname, 'data');
const CONTACT_FILE = path.join(DATA_DIR, 'contact-submissions.json');
const NEWSLETTER_FILE = path.join(DATA_DIR, 'newsletter-subscribers.json');

const GALAXY_MEDIA_AGENT_SYSTEM_INSTRUCTION = `You are the Galaxy Media Studio AI Agent—an intelligent, concise, and practical creative advisor for Galaxy Media, an independent digital media company specializing in building, producing, and growing distinctive YouTube content brands.

Core brand knowledge:
- Brand message: "We Build Media That Moves People."
- Five core services:
  01. Content Strategy — Research, audience analysis, content positioning, video ideas, and channel direction.
  02. Scriptwriting & Storytelling — Narrative development, compelling hooks, retention-driven scripting, and researched storytelling.
  03. Video Production — Voiceover workflows, video editing, motion graphics, visual storytelling, and complete content production.
  04. Thumbnails & Packaging — Visual concepts, thumbnail design, title development, and content packaging.
  05. Channel Development — Content planning, production operations, publishing workflows, and channel optimization.
- Four-step creative process: 01 Discover -> 02 Develop -> 03 Produce -> 04 Refine.
- Account & database context: Signed-in users can store their profile, conversation history, and session diagnostics (server-detected IP address, browser network connection type, timezone, screen resolution, platform, and user agent) securely in Firestore. If asked about Wi-Fi SSID or MAC addresses, explain clearly that modern web browsers restrict access to private Wi-Fi SSIDs and hardware MAC addresses for user security, so the app captures real server-detected IP and browser Network Information API data instead.

Guidelines:
- Give concrete, high-signal advice tailored to YouTube creators, founders, and media teams.
- Keep responses focused, well-structured, and easy to read (avoid fluff or generic agency buzzwords).
- Never invent real client names, fake view counts, or fabricated Galaxy Media case studies.
- When a user wants to start a project, recommend filling out the Start a Project form on the page.`;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, {recursive: true});
  }
}

function readJsonArray<T>(filePath: string): T[] {
  ensureDataDir();
  if (!fs.existsSync(filePath)) {
    return [];
  }
  try {
    const raw = fs.readFileSync(filePath, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeJsonArray<T>(filePath: string, records: T[]) {
  ensureDataDir();
  fs.writeFileSync(filePath, JSON.stringify(records, null, 2), 'utf-8');
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

async function forwardWebhook(url: string | undefined, payload: unknown): Promise<boolean> {
  if (!url || !url.startsWith('http')) {
    return false;
  }
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload),
    });
    return response.ok;
  } catch (err) {
    console.error('Webhook forwarding error:', err);
    return false;
  }
}

function extractClientIp(req: express.Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  let ip = '';
  if (typeof forwarded === 'string' && forwarded.trim().length > 0) {
    ip = forwarded.split(',')[0].trim();
  } else if (Array.isArray(forwarded) && forwarded.length > 0) {
    ip = forwarded[0].trim();
  } else {
    ip = req.socket.remoteAddress || req.ip || 'Unavailable';
  }
  if (ip.startsWith('::ffff:')) {
    ip = ip.slice(7);
  }
  return ip.slice(0, 64) || 'Unavailable';
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.set('trust proxy', true);
  app.use(express.json({limit: '1mb'}));

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({status: 'ok', service: 'galaxy-media'});
  });

  // Real server-detected client network info for transparent Firestore session diagnostics
  app.get('/api/client-info', (req, res) => {
    res.json({
      ipAddress: extractClientIp(req),
      userAgent: String(req.headers['user-agent'] || 'Unavailable').slice(0, 400),
      acceptLanguage: String(req.headers['accept-language'] || 'Unavailable').slice(0, 64),
      detectedAt: new Date().toISOString(),
    });
  });

  // Server-side multi-turn Gemini AI Agent chat endpoint
  app.post('/api/chat', async (req, res) => {
    const {message, history, mode} = req.body ?? {};
    const cleanMessage = typeof message === 'string' ? message.trim() : '';

    if (!cleanMessage) {
      res.status(400).json({ok: false, error: 'Please enter a message.'});
      return;
    }
    if (cleanMessage.length > 4000) {
      res.status(400).json({
        ok: false,
        error: 'Message is too long. Please keep prompts under 4,000 characters.',
      });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        ok: false,
        error:
          'Gemini API key is not configured on the server. Please check your GEMINI_API_KEY secret in Settings > Secrets.',
      });
      return;
    }

    const selectedModel = mode === 'fast' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';

    // Convert prior multi-turn messages to @google/genai Content[] history
    const formattedHistory: Array<{role: 'user' | 'model'; parts: Array<{text: string}>}> = [];
    if (Array.isArray(history)) {
      const recent = history.slice(-20);
      for (const turn of recent) {
        if (
          turn &&
          (turn.role === 'user' || turn.role === 'model') &&
          typeof turn.content === 'string' &&
          turn.content.trim().length > 0
        ) {
          formattedHistory.push({
            role: turn.role,
            parts: [{text: turn.content.trim().slice(0, 8000)}],
          });
        }
      }
    }

    const runChatWithModel = async (modelName: string) => {
      const chat = ai.chats.create({
        model: modelName,
        history: formattedHistory,
        config: {
          systemInstruction: GALAXY_MEDIA_AGENT_SYSTEM_INSTRUCTION,
          ...(modelName === 'gemini-4-hydrogen'
            ? {thinkingConfig: {thinkingLevel: ThinkingLevel.LOW}}
            : {}),
        },
      });
      const response = await chat.sendMessage({message: cleanMessage});
      return (response.text ?? '').trim();
    };

    try {
      let activeModel = selectedModel;
      let reply = '';

      try {
        reply = await runChatWithModel(activeModel);
      } catch (primaryErr: unknown) {
        const msg = primaryErr instanceof Error ? primaryErr.message : String(primaryErr);
        const isAuthOrRateError =
          msg.includes('429') ||
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('403') ||
          msg.includes('PERMISSION_DENIED') ||
          msg.includes('API_KEY_INVALID');

        if (isAuthOrRateError) {
          throw primaryErr;
        }

        // Graceful retry with short backoff, or fall back to live gemini-3.1-flash-lite for general mode
        await new Promise((resolve) => setTimeout(resolve, 450));
        if (activeModel === 'gemini-4-hydrogen') {
          activeModel = 'gemini-3.1-flash-lite';
        }
        reply = await runChatWithModel(activeModel);
      }

      if (!reply) {
        res.status(502).json({
          ok: false,
          error: 'The AI agent returned an empty response. Please try rephrasing your question.',
        });
        return;
      }

      res.json({
        ok: true,
        reply,
        modelUsed: activeModel,
      });
    } catch (err: unknown) {
      console.error('Gemini chat API error:', err);
      const errMsg = err instanceof Error ? err.message : String(err);
      const status =
        errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED')
          ? 429
          : errMsg.includes('403') || errMsg.includes('PERMISSION_DENIED')
            ? 403
            : errMsg.includes('404') || errMsg.includes('NOT_FOUND')
              ? 404
              : errMsg.includes('400') || errMsg.includes('API_KEY_INVALID')
                ? 400
                : 500;

      res.status(status).json({
        ok: false,
        error:
          status === 429
            ? 'Rate limit reached for the Gemini API. Please wait a moment and try again.'
            : status === 403 || status === 400
              ? 'Gemini API rejected the request. Please verify your API key in Settings > Secrets.'
              : status === 404
                ? `The selected model (${selectedModel}) was not found for your API key.`
                : 'Unable to reach the Gemini AI agent right now. Please try again shortly.',
      });
    }
  });

  // Real contact inquiry submission endpoint with validation, storage, and optional webhook forwarding
  app.post('/api/contact', async (req, res) => {
    const {name, email, companyOrChannel, service, details} = req.body ?? {};

    const cleanName = typeof name === 'string' ? name.trim() : '';
    const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';
    const cleanOrg = typeof companyOrChannel === 'string' ? companyOrChannel.trim() : '';
    const cleanService = typeof service === 'string' ? service.trim() : '';
    const cleanDetails = typeof details === 'string' ? details.trim() : '';

    const fieldErrors: Record<string, string> = {};
    if (cleanName.length < 2) {
      fieldErrors.name = 'Please enter your full name.';
    }
    if (!EMAIL_REGEX.test(cleanEmail)) {
      fieldErrors.email = 'Please enter a valid email address.';
    }
    if (!cleanService) {
      fieldErrors.service = 'Please select the service you are interested in.';
    }
    if (cleanDetails.length < 15) {
      fieldErrors.details = 'Please share a brief overview of your project (at least 15 characters).';
    }

    if (Object.keys(fieldErrors).length > 0) {
      res.status(400).json({
        ok: false,
        error: 'Please review the highlighted fields and try again.',
        fieldErrors,
      });
      return;
    }

    const submission = {
      id: `GM-${crypto.randomBytes(4).toString('hex').toUpperCase()}`,
      name: cleanName,
      email: cleanEmail,
      companyOrChannel: cleanOrg || 'Not specified',
      service: cleanService,
      details: cleanDetails,
      receivedAt: new Date().toISOString(),
    };

    try {
      const existing = readJsonArray<typeof submission>(CONTACT_FILE);
      existing.push(submission);
      writeJsonArray(CONTACT_FILE, existing);

      const webhookForwarded = await forwardWebhook(process.env.CONTACT_WEBHOOK_URL, {
        type: 'galaxy_media_contact_inquiry',
        ...submission,
      });

      res.status(201).json({
        ok: true,
        id: submission.id,
        receivedAt: submission.receivedAt,
        webhookForwarded,
        message: 'Your inquiry has been received. Our production team will respond within two business days.',
      });
    } catch (err) {
      console.error('Contact submission error:', err);
      res.status(500).json({
        ok: false,
        error: 'We could not save your inquiry right now. Please try again shortly.',
      });
    }
  });

  // Real newsletter signup endpoint with validation, consent enforcement, duplicate handling, and optional webhook
  app.post('/api/newsletter', async (req, res) => {
    const {email, consent} = req.body ?? {};
    const cleanEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';

    if (!EMAIL_REGEX.test(cleanEmail)) {
      res.status(400).json({
        ok: false,
        error: 'Please enter a valid email address.',
      });
      return;
    }

    if (consent !== true) {
      res.status(400).json({
        ok: false,
        error: 'Please confirm that you would like to receive Galaxy Insights emails.',
      });
      return;
    }

    try {
      const subscribers = readJsonArray<{
        id: string;
        email: string;
        consent: boolean;
        subscribedAt: string;
        welcomeEmailSent?: boolean;
      }>(NEWSLETTER_FILE);

      const originHeader =
        typeof req.headers.origin === 'string' && req.headers.origin.startsWith('http')
          ? req.headers.origin
          : (process.env.APP_URL || '').startsWith('http')
            ? process.env.APP_URL!
            : `https://${req.headers.host || 'localhost:3000'}`;

      const existing = subscribers.find((item) => item.email === cleanEmail);
      if (existing) {
        if (!existing.welcomeEmailSent) {
          const retryEmailResult = await sendGalaxyInsightsWelcomeEmail(cleanEmail, originHeader);
          if (retryEmailResult.sent) {
            existing.welcomeEmailSent = true;
            writeJsonArray(NEWSLETTER_FILE, subscribers);
            res.status(200).json({
              ok: true,
              alreadySubscribed: false,
              id: existing.id,
              subscribedAt: existing.subscribedAt,
              welcomeEmailSent: true,
              message: `You are subscribed to Galaxy Insights. We've sent a welcome message to ${cleanEmail}.`,
            });
            return;
          }
        }

        res.status(200).json({
          ok: true,
          alreadySubscribed: true,
          subscribedAt: existing.subscribedAt,
          welcomeEmailSent: Boolean(existing.welcomeEmailSent),
          message: 'This email is already subscribed to Galaxy Insights.',
        });
        return;
      }

      const emailResult = await sendGalaxyInsightsWelcomeEmail(cleanEmail, originHeader);

      const record = {
        id: `SUB-${crypto.randomBytes(4).toString('hex').toUpperCase()}`,
        email: cleanEmail,
        consent: true,
        subscribedAt: new Date().toISOString(),
        welcomeEmailSent: emailResult.sent,
      };

      subscribers.push(record);
      writeJsonArray(NEWSLETTER_FILE, subscribers);

      const webhookForwarded = await forwardWebhook(process.env.NEWSLETTER_WEBHOOK_URL, {
        type: 'galaxy_media_newsletter_subscription',
        ...record,
      });

      res.status(201).json({
        ok: true,
        alreadySubscribed: false,
        id: record.id,
        subscribedAt: record.subscribedAt,
        welcomeEmailSent: emailResult.sent,
        webhookForwarded,
        message: emailResult.sent
          ? `You are subscribed to Galaxy Insights. We've sent a welcome message to ${cleanEmail}.`
          : 'You are subscribed to Galaxy Insights. Expect occasional, high-signal notes on digital media.',
      });
    } catch (err) {
      console.error('Newsletter subscription error:', err);
      res.status(500).json({
        ok: false,
        error: 'We could not process your subscription right now. Please try again shortly.',
      });
    }
  });

  // Vite middleware for development or static serving for production
  if (process.env.NODE_ENV !== 'production') {
    const {createServer: createViteServer} = await import('vite');
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Galaxy Media server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
