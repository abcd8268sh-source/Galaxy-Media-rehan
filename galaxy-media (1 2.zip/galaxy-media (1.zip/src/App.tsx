import {useCallback, useEffect, useState} from 'react';
import {MotionConfig} from 'motion/react';
import {FirebaseProvider} from './context/FirebaseContext';
import {ErrorBoundary} from './components/ErrorBoundary';
import {Navbar} from './components/Navbar';
import {HeroSection} from './components/HeroSection';
import {ServicesSection} from './components/ServicesSection';
import {FeatureCardsSection} from './components/FeatureCardsSection';
import {WorkSection} from './components/WorkSection';
import {FormatsSection} from './components/FormatsSection';
import {ProcessSection} from './components/ProcessSection';
import {ApproachSection} from './components/ApproachSection';
import {AboutSection} from './components/AboutSection';
import {ContactSection} from './components/ContactSection';
import {NewsletterSection} from './components/NewsletterSection';
import {Footer} from './components/Footer';
import {AccountPanelModal} from './components/AccountPanelModal';
import {AdminDashboardModal} from './components/AdminDashboardModal';
import {GeminiChatWidget} from './components/GeminiChatWidget';
import {CheckoutPaymentTab, type PaymentDashboardTab} from './components/CheckoutPaymentTab';
import {PORTFOLIO_PROJECTS} from './data/siteContent';

const UNLOCKED_STORAGE_KEY = 'galaxy_media_unlocked_projects';

interface PaymentRouteState {
  active: boolean;
  view: PaymentDashboardTab;
  projectId: string;
}

function readPaymentRouteFromUrl(): PaymentRouteState {
  if (typeof window === 'undefined') {
    return {active: false, view: 'card', projectId: 'meridian-archive'};
  }
  const params = new URLSearchParams(window.location.search);
  const active = params.get('tab') === 'payments' || params.get('tab') === 'checkout';
  const rawView = params.get('view');
  const view: PaymentDashboardTab =
    rawView === 'packages' || rawView === 'card' || rawView === 'promo' ? rawView : 'card';
  const projectId = params.get('project') || 'meridian-archive';
  return {active, view, projectId};
}

function loadUnlockedProjects(): Record<string, boolean> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(UNLOCKED_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    return parsed && typeof parsed === 'object' ? (parsed as Record<string, boolean>) : {};
  } catch {
    return {};
  }
}

export default function App() {
  const [contactService, setContactService] = useState<string | undefined>(undefined);
  const [contactNote, setContactNote] = useState<string | undefined>(undefined);
  const [accountOpen, setAccountOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [paymentRoute, setPaymentRoute] = useState<PaymentRouteState>(readPaymentRouteFromUrl);
  const [unlockedProjects, setUnlockedProjects] =
    useState<Record<string, boolean>>(loadUnlockedProjects);

  useEffect(() => {
    const onPopState = () => {
      setPaymentRoute(readPaymentRouteFromUrl());
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const handleUnlockAllWork = useCallback((extraPackageId?: string) => {
    setUnlockedProjects((prev) => {
      const next: Record<string, boolean> = {...prev};
      for (const project of PORTFOLIO_PROJECTS) {
        next[project.id] = true;
      }
      if (extraPackageId) {
        next[extraPackageId] = true;
      }
      try {
        window.localStorage.setItem(UNLOCKED_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage errors in restricted frames
      }
      return next;
    });
  }, []);

  const handleResetLocks = useCallback(() => {
    setUnlockedProjects({});
    try {
      window.localStorage.removeItem(UNLOCKED_STORAGE_KEY);
    } catch {
      // Ignore storage errors in restricted frames
    }
  }, []);

  const handleOpenCheckout = useCallback((projectId: string) => {
    const nextUrl = `${window.location.pathname}?tab=payments&view=card&project=${encodeURIComponent(projectId)}&amount=499`;
    window.history.pushState({tab: 'payments', view: 'card', projectId}, '', nextUrl);
    setPaymentRoute({active: true, view: 'card', projectId});
  }, []);

  const handleOpenPaymentsDashboard = useCallback(() => {
    const nextUrl = `${window.location.pathname}?tab=payments&view=card`;
    window.history.pushState({tab: 'payments', view: 'card'}, '', nextUrl);
    setPaymentRoute({
      active: true,
      view: 'card',
      projectId: 'meridian-archive',
    });
  }, []);

  const handleCloseCheckout = useCallback(() => {
    window.history.pushState({}, '', window.location.pathname);
    setPaymentRoute({
      active: false,
      view: 'card',
      projectId: 'meridian-archive',
    });
  }, []);

  const scrollToContact = () => {
    const target = document.getElementById('contact');
    if (target) {
      target.scrollIntoView({behavior: 'smooth'});
    }
  };

  const handleSelectServiceForContact = (serviceTitle: string) => {
    setContactService(serviceTitle);
    scrollToContact();
  };

  const handleStartSimilarProject = (projectTitle: string) => {
    setContactService('Full Video Production');
    setContactNote(
      `Interested in developing a project inspired by the "${projectTitle}" production format. `,
    );
    scrollToContact();
  };

  const handleSelectFormatForContact = (formatTitle: string) => {
    setContactService('Full Video Production');
    setContactNote(
      `Interested in producing a YouTube series using the "${formatTitle}" format. `,
    );
    scrollToContact();
  };

  return (
    <ErrorBoundary>
      <FirebaseProvider>
        <MotionConfig reducedMotion="user">
          {paymentRoute.active ? (
            <CheckoutPaymentTab
              projectId={paymentRoute.projectId}
              initialView={paymentRoute.view}
              unlockedProjects={unlockedProjects}
              onUnlockAllWork={handleUnlockAllWork}
              onResetLocks={handleResetLocks}
              onBack={handleCloseCheckout}
            />
          ) : (
            <div className="min-h-screen bg-white text-[#101421] flex flex-col">
              <Navbar
                onOpenAccount={() => setAccountOpen(true)}
                onOpenAdmin={() => setAdminOpen(true)}
                onOpenPayments={handleOpenPaymentsDashboard}
              />
              <main className="flex-1">
                <HeroSection />
                <ServicesSection onSelectServiceForContact={handleSelectServiceForContact} />
                <FeatureCardsSection />
                <WorkSection
                  onStartSimilarProject={handleStartSimilarProject}
                  onOpenCheckout={handleOpenCheckout}
                  unlockedProjects={unlockedProjects}
                />
                <FormatsSection onSelectFormatForContact={handleSelectFormatForContact} />
                <ProcessSection />
                <ApproachSection />
                <AboutSection />
                <ContactSection
                  preselectedService={contactService}
                  preselectedNote={contactNote}
                />
                <NewsletterSection />
              </main>
              <Footer />

              <AccountPanelModal
                open={accountOpen}
                onClose={() => setAccountOpen(false)}
                onOpenAdmin={() => setAdminOpen(true)}
              />
              <AdminDashboardModal open={adminOpen} onClose={() => setAdminOpen(false)} />
              <GeminiChatWidget onOpenAccount={() => setAccountOpen(true)} />
            </div>
          )}
        </MotionConfig>
      </FirebaseProvider>
    </ErrorBoundary>
  );
}

