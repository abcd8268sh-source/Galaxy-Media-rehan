import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import {
  browserPopupRedirectResolver,
  inMemoryPersistence,
  onAuthStateChanged,
  setPersistence,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  type Timestamp,
} from 'firebase/firestore';
import {auth, db, FIREBASE_PROJECT_ID, googleProvider} from '../lib/firebase';
import {handleFirestoreError, OperationType} from '../lib/firestoreError';
import {collectClientDiagnostics, sanitizeField} from '../lib/diagnostics';

export interface UserProfileRecord {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  lastIpAddress: string;
  lastNetworkType: string;
  lastUserAgent: string;
  lastTimezone: string;
  lastScreenResolution: string;
  lastLanguage: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface UserSessionRecord {
  id: string;
  userId: string;
  ipAddress: string;
  networkType: string;
  downlinkMbps: string;
  rttMs: string;
  wifiAccessNote: string;
  userAgent: string;
  platform: string;
  language: string;
  timezone: string;
  screenResolution: string;
  referrer: string;
  createdAt?: Timestamp;
}

export const ADMIN_EMAIL = 'abcd8268sh@gmail.com';

export interface AuthErrorDetails {
  message: string;
  code?: string;
  actionLabel?: string;
  actionUrl?: string;
}

interface FirebaseContextValue {
  user: User | null;
  authReady: boolean;
  isAdmin: boolean;
  signingIn: boolean;
  profile: UserProfileRecord | null;
  sessions: UserSessionRecord[];
  syncingSession: boolean;
  authError: AuthErrorDetails | null;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  recordCurrentSession: () => Promise<void>;
  clearSessionHistory: () => Promise<void>;
}

const FirebaseContext = createContext<FirebaseContextValue | null>(null);

function generateSafeDocId(prefix: string): string {
  const randomPart =
    typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 16)
      : Math.random().toString(36).slice(2, 14);
  return `${prefix}_${Date.now()}_${randomPart}`;
}

export function FirebaseProvider({children}: {children: ReactNode}) {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [signingIn, setSigningIn] = useState(false);
  const [profile, setProfile] = useState<UserProfileRecord | null>(null);
  const [sessions, setSessions] = useState<UserSessionRecord[]>([]);
  const [syncingSession, setSyncingSession] = useState(false);
  const [authError, setAuthError] = useState<AuthErrorDetails | null>(null);

  const syncedUidRef = useRef<string | null>(null);

  const syncUserAndRecordSession = useCallback(async (currentUser: User) => {
    if (!currentUser.emailVerified) {
      setAuthError({
        message: 'Please verify your Google account email to save session data.',
      });
      return;
    }

    setSyncingSession(true);
    setAuthError(null);

    try {
      const diag = await collectClientDiagnostics();
      const userPath = `users/${currentUser.uid}`;
      const userRef = doc(db, 'users', currentUser.uid);

      let existingSnap;
      try {
        existingSnap = await getDoc(userRef);
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, userPath);
      }

      const cleanDisplayName = sanitizeField(
        currentUser.displayName || currentUser.email?.split('@')[0],
        120,
        'Galaxy Member',
      );
      const cleanEmail = sanitizeField(currentUser.email, 254, 'member@galaxymedia.co');
      const cleanPhoto = (currentUser.photoURL || '').trim().slice(0, 512);

      if (!existingSnap.exists()) {
        const createPayload: Record<string, unknown> = {
          uid: currentUser.uid,
          displayName: cleanDisplayName,
          email: cleanEmail,
          lastIpAddress: diag.ipAddress,
          lastNetworkType: diag.networkType,
          lastUserAgent: diag.userAgent,
          lastTimezone: diag.timezone,
          lastScreenResolution: diag.screenResolution,
          lastLanguage: diag.language,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        };
        if (cleanPhoto) {
          createPayload.photoURL = cleanPhoto;
        }
        try {
          await setDoc(userRef, createPayload);
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, userPath);
        }
      } else {
        const updatePayload: Record<string, unknown> = {
          displayName: cleanDisplayName,
          email: cleanEmail,
          lastIpAddress: diag.ipAddress,
          lastNetworkType: diag.networkType,
          lastUserAgent: diag.userAgent,
          lastTimezone: diag.timezone,
          lastScreenResolution: diag.screenResolution,
          lastLanguage: diag.language,
          updatedAt: serverTimestamp(),
        };
        if (cleanPhoto) {
          updatePayload.photoURL = cleanPhoto;
        }
        try {
          await updateDoc(userRef, updatePayload);
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, userPath);
        }
      }

      // Append immutable session snapshot under /users/{uid}/sessions/{sessionId}
      const sessionId = generateSafeDocId('sess');
      const sessionPath = `users/${currentUser.uid}/sessions/${sessionId}`;
      const sessionRef = doc(db, 'users', currentUser.uid, 'sessions', sessionId);
      try {
        await setDoc(sessionRef, {
          userId: currentUser.uid,
          ipAddress: diag.ipAddress,
          networkType: diag.networkType,
          downlinkMbps: diag.downlinkMbps,
          rttMs: diag.rttMs,
          wifiAccessNote: diag.wifiAccessNote,
          userAgent: diag.userAgent,
          platform: diag.platform,
          language: diag.language,
          timezone: diag.timezone,
          screenResolution: diag.screenResolution,
          referrer: diag.referrer,
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, sessionPath);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to save session diagnostics.';
      setAuthError({
        message: msg.includes('Quota exceeded')
          ? 'Firestore daily free-tier quota exceeded. Quota resets tomorrow.'
          : 'Could not sync session diagnostics to Firestore.',
      });
    } finally {
      setSyncingSession(false);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);
      if (!nextUser) {
        setProfile(null);
        setSessions([]);
        syncedUidRef.current = null;
      }
    });
    return () => unsubscribe();
  }, []);

  // Attach Firestore listeners and auto-record session ONLY when auth is ready and user is authenticated
  useEffect(() => {
    if (!authReady || !user || !user.emailVerified) return;

    if (syncedUidRef.current !== user.uid) {
      syncedUidRef.current = user.uid;
      void syncUserAndRecordSession(user);
    }

    const userPath = `users/${user.uid}`;
    const unsubProfile = onSnapshot(
      doc(db, 'users', user.uid),
      (snap) => {
        if (snap.exists()) {
          setProfile(snap.data() as UserProfileRecord);
        } else {
          setProfile(null);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, userPath);
      },
    );

    const sessionsPath = `users/${user.uid}/sessions`;
    const sessionsQuery = query(
      collection(db, 'users', user.uid, 'sessions'),
      where('userId', '==', user.uid),
    );
    const unsubSessions = onSnapshot(
      sessionsQuery,
      (snapshot) => {
        const list: UserSessionRecord[] = snapshot.docs.map((docSnap) => ({
          id: docSnap.id,
          ...(docSnap.data() as Omit<UserSessionRecord, 'id'>),
        }));
        list.sort((a, b) => {
          const timeA = a.createdAt?.toMillis?.() ?? Date.now();
          const timeB = b.createdAt?.toMillis?.() ?? Date.now();
          return timeB - timeA;
        });
        setSessions(list.slice(0, 20));
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, sessionsPath);
      },
    );

    return () => {
      unsubProfile();
      unsubSessions();
    };
  }, [authReady, user, syncUserAndRecordSession]);

  const signInWithGoogle = useCallback(async () => {
    if (signingIn) return;
    setAuthError(null);
    setSigningIn(true);

    try {
      // Call signInWithPopup synchronously on the first tick to preserve browser user gesture
      await signInWithPopup(auth, googleProvider, browserPopupRedirectResolver);
    } catch (err: unknown) {
      const firebaseErr = err as {code?: string; message?: string};
      const code = firebaseErr?.code || '';
      console.error('Firebase Google Sign-In error:', code, firebaseErr?.message);

      if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
        return;
      }

      // If browser storage is blocked in an embedded iframe, retry with in-memory persistence
      if (code === 'auth/web-storage-unsupported') {
        try {
          await setPersistence(auth, inMemoryPersistence);
          await signInWithPopup(auth, googleProvider, browserPopupRedirectResolver);
          return;
        } catch (retryErr: unknown) {
          const retryCode = (retryErr as {code?: string})?.code || code;
          setAuthError({
            code: retryCode,
            message:
              'Browser storage is restricted inside this embedded preview. Open the app in a full browser tab to sign in with Google.',
            actionLabel: 'Open in New Tab',
            actionUrl: typeof window !== 'undefined' ? window.location.href : undefined,
          });
          return;
        }
      }

      if (code === 'auth/unauthorized-domain') {
        const host = typeof window !== 'undefined' ? window.location.hostname : 'this domain';
        setAuthError({
          code,
          message: `This domain (${host}) is not listed under Firebase Authorized Domains yet. Add it in Firebase Console > Authentication > Settings > Authorized domains, then retry.`,
          actionLabel: 'Open Firebase Auth Settings',
          actionUrl: `https://console.firebase.google.com/project/${FIREBASE_PROJECT_ID}/authentication/settings`,
        });
        return;
      }

      if (code === 'auth/operation-not-allowed') {
        setAuthError({
          code,
          message:
            'Google Sign-In is not enabled in this Firebase project yet. Enable Google under Authentication > Sign-in method.',
          actionLabel: 'Enable Google Sign-In',
          actionUrl: `https://console.firebase.google.com/project/${FIREBASE_PROJECT_ID}/authentication/providers`,
        });
        return;
      }

      if (code === 'auth/popup-blocked') {
        setAuthError({
          code,
          message:
            'Your browser blocked the Google Sign-In popup inside the preview frame. Allow popups for this site or open the app in a full tab to sign in.',
          actionLabel: 'Open in New Tab',
          actionUrl: typeof window !== 'undefined' ? window.location.href : undefined,
        });
        return;
      }

      setAuthError({
        code: code || 'auth/unknown',
        message: `Google Sign-In failed${code ? ` (${code})` : ''}. If you are viewing inside an embedded preview, try opening the app in a new tab and signing in there.`,
        actionLabel: 'Open in New Tab',
        actionUrl: typeof window !== 'undefined' ? window.location.href : undefined,
      });
    } finally {
      setSigningIn(false);
    }
  }, [signingIn]);

  const signOutUser = useCallback(async () => {
    setAuthError(null);
    await signOut(auth);
  }, []);

  const recordCurrentSession = useCallback(async () => {
    if (!user) return;
    await syncUserAndRecordSession(user);
  }, [user, syncUserAndRecordSession]);

  const clearSessionHistory = useCallback(async () => {
    if (!user) return;
    setSyncingSession(true);
    try {
      await Promise.all(
        sessions.map(async (session) => {
          const path = `users/${user.uid}/sessions/${session.id}`;
          try {
            await deleteDoc(doc(db, 'users', user.uid, 'sessions', session.id));
          } catch (err) {
            handleFirestoreError(err, OperationType.DELETE, path);
          }
        }),
      );
    } finally {
      setSyncingSession(false);
    }
  }, [user, sessions]);

  const isAdmin = Boolean(
    user && user.emailVerified && user.email?.toLowerCase() === ADMIN_EMAIL,
  );

  return (
    <FirebaseContext.Provider
      value={{
        user,
        authReady,
        isAdmin,
        signingIn,
        profile,
        sessions,
        syncingSession,
        authError,
        signInWithGoogle,
        signOutUser,
        recordCurrentSession,
        clearSessionHistory,
      }}
    >
      {children}
    </FirebaseContext.Provider>
  );
}

export function useFirebase() {
  const ctx = useContext(FirebaseContext);
  if (!ctx) {
    throw new Error('useFirebase must be used inside FirebaseProvider');
  }
  return ctx;
}
