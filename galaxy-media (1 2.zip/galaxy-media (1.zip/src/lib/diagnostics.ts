export interface ClientDiagnosticsSnapshot {
  ipAddress: string;
  networkType: string;
  downlinkMbps: string;
  rttMs: string;
  wifiAccessNote: string;
  userAgent: string;
  platform: string;
  language: string;
  timezone: string;
  screenResolution: string;
  referrer: string;
}

interface NetworkInformationLike {
  type?: string;
  effectiveType?: string;
  downlink?: number;
  rtt?: number;
}

function clampString(value: string | null | undefined, maxLen: number, fallback: string): string {
  const trimmed = (value ?? '').trim();
  if (!trimmed) return fallback.slice(0, maxLen);
  return trimmed.slice(0, maxLen);
}

export function sanitizeField(value: string | null | undefined, maxLen: number, fallback = 'Unknown'): string {
  return clampString(value, maxLen, fallback);
}

export async function collectClientDiagnostics(): Promise<ClientDiagnosticsSnapshot> {
  let ipAddress = 'Unavailable';
  let serverUserAgent = '';

  try {
    const res = await fetch('/api/client-info', {cache: 'no-store'});
    if (res.ok) {
      const data = await res.json();
      if (typeof data.ipAddress === 'string' && data.ipAddress.trim()) {
        ipAddress = data.ipAddress.trim();
      }
      if (typeof data.userAgent === 'string') {
        serverUserAgent = data.userAgent;
      }
    }
  } catch {
    // Fallback cleanly if endpoint unreachable
  }

  const nav = typeof navigator !== 'undefined' ? navigator : undefined;
  const connection = (nav as (Navigator & {connection?: NetworkInformationLike}) | undefined)
    ?.connection;

  const rawNetworkType =
    connection?.type && connection.type !== 'unknown'
      ? `${connection.type}${connection.effectiveType ? ` (${connection.effectiveType})` : ''}`
      : connection?.effectiveType
        ? `Browser estimate: ${connection.effectiveType}`
        : 'Browser API unavailable';

  const downlinkMbps =
    typeof connection?.downlink === 'number' ? `${connection.downlink} Mbps` : 'Unavailable';

  const rttMs = typeof connection?.rtt === 'number' ? `${connection.rtt} ms` : 'Unavailable';

  const timezone = (() => {
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    } catch {
      return 'UTC';
    }
  })();

  const screenResolution =
    typeof window !== 'undefined' && window.screen
      ? `${window.screen.width}x${window.screen.height} @${window.devicePixelRatio || 1}x`
      : 'Unavailable';

  const platform =
    (nav as (Navigator & {userAgentData?: {platform?: string}}) | undefined)?.userAgentData
      ?.platform ||
    nav?.platform ||
    'Web Browser';

  return {
    ipAddress: clampString(ipAddress, 64, 'Unavailable'),
    networkType: clampString(rawNetworkType, 48, 'Browser API unavailable'),
    downlinkMbps: clampString(downlinkMbps, 32, 'Unavailable'),
    rttMs: clampString(rttMs, 32, 'Unavailable'),
    wifiAccessNote: clampString(
      'Web browsers restrict direct Wi-Fi SSID & MAC access for security; real IP and browser network type are recorded instead.',
      200,
      'Restricted by browser sandbox',
    ),
    userAgent: clampString(nav?.userAgent || serverUserAgent, 400, 'Unavailable'),
    platform: clampString(platform, 80, 'Web Browser'),
    language: clampString(nav?.language, 32, 'en-US'),
    timezone: clampString(timezone, 80, 'UTC'),
    screenResolution: clampString(screenResolution, 40, 'Unavailable'),
    referrer: (typeof document !== 'undefined' ? document.referrer || '' : '').trim().slice(0, 300),
  };
}
