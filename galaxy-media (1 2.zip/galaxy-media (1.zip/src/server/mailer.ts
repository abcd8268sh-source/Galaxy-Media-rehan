import nodemailer from 'nodemailer';

export interface EmailSendResult {
  sent: boolean;
  provider?: 'resend' | 'smtp';
  messageId?: string;
  reason?: string;
}

function buildWelcomeEmailContent() {
  const subject = 'Welcome to Galaxy Insights — Galaxy Media';

  const text = [
    'Welcome to Galaxy Insights.',
    '',
    'Thank you for subscribing to Galaxy Media—we are glad to have you with us.',
    '',
    "At Galaxy Media, we don't follow trends. We invent original YouTube formats and build digital media that moves people.",
    '',
    'Here is what you can expect in occasional, high-signal dispatches:',
    '- Format blueprints behind standout series (Explainer Format, 7 Levels Of, The Rise and Fall Of, and The Entire History Of)',
    '- Retention-driven storytelling, scripting, and visual pacing takeaways',
    '- Practical notes on building durable YouTube channels and creative production systems',
    '',
    'No filler, no daily noise—only ideas worth your time.',
    '',
    'HOW WE WORK: 01 Discover -> 02 Develop -> 03 Produce -> 04 Refine',
    "Working on a channel or have a format you'd like us to break down next? Just reply directly to this email—we read every message.",
    '',
    'Warm regards,',
    'The Galaxy Media Team',
  ].join('\n');

  const html = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${subject}</title>
  </head>
  <body style="margin:0;padding:0;background-color:#FAFBFD;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#101421;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#FAFBFD;padding:32px 16px;">
      <tr>
        <td align="center">
          <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width:600px;width:100%;background-color:#FFFFFF;border-radius:16px;overflow:hidden;border:1px solid #E5EAF2;">
            <!-- Header Banner -->
            <tr>
              <td style="background:linear-gradient(135deg,#030B2C 0%,#0B328D 60%,#1769F4 100%);background-color:#030B2C;padding:36px 36px 32px 36px;">
                <p style="margin:0 0 12px 0;font-size:11px;font-weight:700;letter-spacing:0.16em;text-transform:uppercase;color:#BFE8FF;">
                  GALAXY MEDIA &middot; GALAXY INSIGHTS
                </p>
                <h1 style="margin:0;font-size:28px;line-height:1.2;font-weight:600;letter-spacing:-0.02em;color:#FFFFFF;">
                  Good ideas deserve to travel.
                </h1>
              </td>
            </tr>

            <!-- Body -->
            <tr>
              <td style="padding:36px 36px 28px 36px;">
                <p style="margin:0 0 16px 0;font-size:16px;line-height:1.65;color:#101421;">
                  Welcome to <strong>Galaxy Insights</strong>—we&rsquo;re glad you&rsquo;re here.
                </p>
                <p style="margin:0 0 22px 0;font-size:15px;line-height:1.7;color:#3B4254;">
                  At Galaxy Media, we don&rsquo;t follow trends—we invent original YouTube formats and craft digital media that moves people. Whenever we send a dispatch, it will be concise, thoughtful, and worth opening.
                </p>

                <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#F4F8FF;border:1px solid #D9E8FF;border-radius:12px;margin-bottom:20px;">
                  <tr>
                    <td style="padding:20px 22px;">
                      <p style="margin:0 0 10px 0;font-size:12px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:#1769F4;">
                        What you&rsquo;ll receive
                      </p>
                      <ul style="margin:0;padding-left:18px;font-size:14.5px;line-height:1.7;color:#1F2739;">
                        <li>Breakdowns of iconic storytelling formats (<em>Explainer</em>, <em>7 Levels Of</em>, <em>The Rise and Fall Of</em>, and <em>The Entire History Of</em>)</li>
                        <li>Practical insights on narrative hooks, visual pacing, and audience retention</li>
                        <li>Behind-the-scenes lessons from building scalable YouTube channels</li>
                      </ul>
                    </td>
                  </tr>
                </table>

                <!-- Studio Note & Direct Reply Callout -->
                <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color:#030B2C;border-radius:12px;margin-bottom:26px;">
                  <tr>
                    <td style="padding:20px 22px;">
                      <p style="margin:0 0 6px 0;font-size:11px;font-weight:700;letter-spacing:0.14em;text-transform:uppercase;color:#E7FF4B;">
                        01 Discover &middot; 02 Develop &middot; 03 Produce &middot; 04 Refine
                      </p>
                      <p style="margin:0;font-size:14px;line-height:1.65;color:#E5EEFF;">
                        Building a channel or curious how a specific YouTube format works? Simply <strong>reply directly to this email</strong>&mdash;our team reads every note and loves hearing what you&rsquo;re working on.
                      </p>
                    </td>
                  </tr>
                </table>

                <p style="margin:0;font-size:14.5px;line-height:1.65;color:#3B4254;">
                  Thanks again for joining us.<br />
                  <strong style="color:#030B2C;">The Galaxy Media Team</strong>
                </p>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style="padding:20px 36px;background-color:#FAFBFD;border-top:1px solid #E5EAF2;">
                <p style="margin:0;font-size:12px;line-height:1.6;color:#727B8E;">
                  You&rsquo;re receiving this welcome note because you subscribed to Galaxy Insights at Galaxy Media.
                </p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`;

  return {subject, text, html};
}

export async function sendGalaxyInsightsWelcomeEmail(
  recipientEmail: string,
  _siteUrl?: string,
): Promise<EmailSendResult> {
  const {subject, text, html} = buildWelcomeEmailContent();

  // 1. Try Resend API if RESEND_API_KEY is configured and SMTP isn't explicitly overriding it without EMAIL_FROM
  const resendKey = (process.env.RESEND_API_KEY || process.env['RESEND-API-KEY'] || '').trim();
  const smtpUser = (process.env.SMTP_USER || '').trim();
  const smtpPass = (process.env.SMTP_PASS || '').replace(/\s+/g, '').trim();
  const customFrom = (process.env.EMAIL_FROM || '').trim();

  let resendFailure: EmailSendResult | null = null;

  // Prefer SMTP directly if user configured Gmail/SMTP and has no verified EMAIL_FROM domain for Resend
  const shouldTryResendFirst = Boolean(resendKey && (customFrom || !(smtpUser && smtpPass)));

  if (shouldTryResendFirst) {
    const fromAddress = customFrom || 'Galaxy Media <onboarding@resend.dev>';
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromAddress,
          to: [recipientEmail],
          subject,
          html,
          text,
        }),
      });

      const data = (await response.json().catch(() => ({}))) as {id?: string; message?: string};
      if (response.ok) {
        return {sent: true, provider: 'resend', messageId: data.id};
      }

      console.error('Resend welcome email failed:', response.status, data);
      resendFailure = {
        sent: false,
        provider: 'resend',
        reason: data?.message || `Resend returned HTTP ${response.status}`,
      };
    } catch (err) {
      console.error('Resend welcome email error:', err);
      resendFailure = {
        sent: false,
        provider: 'resend',
        reason: err instanceof Error ? err.message : 'Resend network error',
      };
    }
  }

  // 2. Use SMTP via Nodemailer (works with free Gmail App Password to send to any email—no custom domain needed)
  if (smtpUser && smtpPass) {
    const inferredHost = smtpUser.toLowerCase().endsWith('@gmail.com') ? 'smtp.gmail.com' : '';
    const smtpHost = (process.env.SMTP_HOST || '').trim() || inferredHost;
    if (!smtpHost) {
      return {
        sent: false,
        provider: 'smtp',
        reason: 'SMTP_HOST is required for non-Gmail SMTP accounts.',
      };
    }

    const smtpPort = Number(process.env.SMTP_PORT || '465') || 465;
    const secure = smtpPort === 465;
    const fromAddress = customFrom || `Galaxy Media <${smtpUser}>`;

    try {
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure,
        auth: {
          user: smtpUser,
          pass: smtpPass,
        },
      });

      const info = await transporter.sendMail({
        from: fromAddress,
        to: recipientEmail,
        subject,
        text,
        html,
      });

      return {sent: true, provider: 'smtp', messageId: info.messageId};
    } catch (err) {
      console.error('SMTP welcome email error:', err);
      return {
        sent: false,
        provider: 'smtp',
        reason: err instanceof Error ? err.message : 'SMTP delivery error',
      };
    }
  }

  if (resendFailure) {
    return resendFailure;
  }

  console.info(
    'Galaxy Insights welcome email skipped: configure SMTP_USER + SMTP_PASS or RESEND_API_KEY in Secrets to send live emails.',
  );
  return {
    sent: false,
    reason: 'Email provider not configured in Secrets (SMTP_USER/SMTP_PASS or RESEND_API_KEY).',
  };
}
