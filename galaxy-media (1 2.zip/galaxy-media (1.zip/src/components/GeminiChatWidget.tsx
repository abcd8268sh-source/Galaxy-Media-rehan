import {useEffect, useRef, useState, type FormEvent} from 'react';
import {
  AlertCircle,
  Loader2,
  MessageSquare,
  Send,
  Trash2,
  UserCheck,
  X,
} from 'lucide-react';
import {AnimatePresence, motion, useReducedMotion} from 'motion/react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
  type Timestamp,
} from 'firebase/firestore';
import {useFirebase} from '../context/FirebaseContext';
import {db} from '../lib/firebase';
import {handleFirestoreError, OperationType} from '../lib/firestoreError';
import {BrandMark} from './BrandMark';

interface ChatTurn {
  id: string;
  role: 'user' | 'model';
  content: string;
  modelUsed: string;
  createdAt?: Timestamp;
}

const STARTER_PROMPTS = [
  'Help me outline a high-retention YouTube documentary concept.',
  'Which Galaxy Media service is best for launching a new channel?',
  'What network and session info is saved in my Firestore profile?',
];

function generateMessageId(): string {
  const rand =
    typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 14)
      : Math.random().toString(36).slice(2, 12);
  return `msg_${Date.now()}_${rand}`;
}

interface GeminiChatWidgetProps {
  onOpenAccount: () => void;
}

export function GeminiChatWidget({onOpenAccount}: GeminiChatWidgetProps) {
  const {user, authReady, profile, recordCurrentSession} = useFirebase();
  const prefersReducedMotion = useReducedMotion();

  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState<'general' | 'fast'>('general');
  const [input, setInput] = useState('');
  const [localMessages, setLocalMessages] = useState<ChatTurn[]>([]);
  const [firestoreMessages, setFirestoreMessages] = useState<ChatTurn[]>([]);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const threadEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const isPersistedMode = Boolean(authReady && user && user.emailVerified);
  const messages = isPersistedMode ? firestoreMessages : localMessages;

  // Real-time Firestore chat history listener for signed-in users
  useEffect(() => {
    if (!isPersistedMode || !user) {
      setFirestoreMessages([]);
      return;
    }

    const chatPath = `users/${user.uid}/chatMessages`;
    const q = query(
      collection(db, 'users', user.uid, 'chatMessages'),
      where('userId', '==', user.uid),
    );

    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const list: ChatTurn[] = snapshot.docs.map((docSnap) => {
          const data = docSnap.data() as Omit<ChatTurn, 'id'>;
          return {
            id: docSnap.id,
            role: data.role,
            content: data.content,
            modelUsed: data.modelUsed,
            createdAt: data.createdAt,
          };
        });
        list.sort((a, b) => {
          const tA = a.createdAt?.toMillis?.() ?? Number.MAX_SAFE_INTEGER;
          const tB = b.createdAt?.toMillis?.() ?? Number.MAX_SAFE_INTEGER;
          return tA - tB;
        });
        setFirestoreMessages(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, chatPath);
      },
    );

    return () => unsub();
  }, [isPersistedMode, user]);

  // Auto-scroll to latest message
  useEffect(() => {
    if (isOpen) {
      threadEndRef.current?.scrollIntoView({behavior: prefersReducedMotion ? 'auto' : 'smooth'});
    }
  }, [messages.length, sending, isOpen, prefersReducedMotion]);

  useEffect(() => {
    if (isOpen) {
      const timer = window.setTimeout(() => inputRef.current?.focus(), 180);
      return () => window.clearTimeout(timer);
    }
  }, [isOpen]);

  const persistTurnToFirestore = async (
    uid: string,
    role: 'user' | 'model',
    content: string,
    modelUsed: string,
  ) => {
    const id = generateMessageId();
    const path = `users/${uid}/chatMessages/${id}`;
    try {
      await setDoc(doc(db, 'users', uid, 'chatMessages', id), {
        userId: uid,
        role,
        content: content.slice(0, 8000),
        modelUsed: modelUsed.slice(0, 64),
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  const sendMessage = async (rawText: string) => {
    const trimmed = rawText.trim();
    if (!trimmed || sending) return;

    setError(null);
    setInput('');
    setSending(true);

    const historySnapshot = messages.map((m) => ({
      role: m.role,
      content: m.content,
    }));

    if (isPersistedMode && user) {
      try {
        if (!profile) {
          await recordCurrentSession();
        }
        await persistTurnToFirestore(user.uid, 'user', trimmed, 'user-input');
      } catch (err) {
        setSending(false);
        setError(
          err instanceof Error && err.message.includes('Quota exceeded')
            ? 'Firestore daily free-tier quota exceeded. Quota resets tomorrow.'
            : 'Could not save your message to Firestore. Please try again.',
        );
        return;
      }
    } else {
      setLocalMessages((prev) => [
        ...prev,
        {
          id: generateMessageId(),
          role: 'user',
          content: trimmed,
          modelUsed: 'user-input',
        },
      ]);
    }

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          message: trimmed,
          history: historySnapshot,
          mode,
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.ok) {
        setError(data.error || 'The AI agent could not respond right now.');
        return;
      }

      const replyText = String(data.reply || '').trim();
      const modelUsed = String(data.modelUsed || 'gemini-4-hydrogen');

      if (isPersistedMode && user) {
        await persistTurnToFirestore(user.uid, 'model', replyText, modelUsed);
      } else {
        setLocalMessages((prev) => [
          ...prev,
          {
            id: generateMessageId(),
            role: 'model',
            content: replyText,
            modelUsed,
          },
        ]);
      }
    } catch {
      setError('Network error while contacting the Galaxy Media AI Agent. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    void sendMessage(input);
  };

  const handleClearChat = async () => {
    setError(null);
    if (isPersistedMode && user) {
      try {
        await Promise.all(
          firestoreMessages.map(async (m) => {
            const path = `users/${user.uid}/chatMessages/${m.id}`;
            try {
              await deleteDoc(doc(db, 'users', user.uid, 'chatMessages', m.id));
            } catch (err) {
              handleFirestoreError(err, OperationType.DELETE, path);
            }
          }),
        );
      } catch {
        setError('Could not clear saved chat history right now.');
      }
    } else {
      setLocalMessages([]);
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end">
      <AnimatePresence>
        {isOpen && (
          <motion.section
            aria-label="Galaxy Media AI Agent Chat"
            initial={prefersReducedMotion ? false : {opacity: 0, y: 16, scale: 0.96}}
            animate={{opacity: 1, y: 0, scale: 1}}
            exit={prefersReducedMotion ? undefined : {opacity: 0, y: 12, scale: 0.96}}
            transition={{duration: 0.24, ease: [0.16, 1, 0.3, 1]}}
            className="mb-3.5 w-[calc(100vw-2.5rem)] sm:w-[410px] h-[560px] max-h-[78vh] rounded-2xl overflow-hidden bg-[#05123D] text-white border border-[#BFE8FF]/22 shadow-[0_28px_80px_rgba(3,11,44,0.68)] flex flex-col"
          >
            {/* Chat Header */}
            <div className="px-5 py-4 bg-[#040D31] border-b border-white/10 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <BrandMark className="w-5 h-5 text-[#BFE8FF] shrink-0" />
                <div className="min-w-0">
                  <h2 className="font-display font-medium text-[14.5px] text-white leading-tight truncate">
                    Galaxy Media AI Agent
                  </h2>
                  <p className="text-[11.5px] text-[#BFE8FF]/70 truncate">
                    {isPersistedMode ? 'Synced to Firestore' : 'Studio strategy & support'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                {messages.length > 0 && (
                  <button
                    type="button"
                    onClick={() => void handleClearChat()}
                    title="Clear conversation"
                    aria-label="Clear conversation"
                    className="inline-flex items-center justify-center w-8 h-8 rounded-md text-white/55 hover:text-white hover:bg-white/[0.08] transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  aria-label="Close AI Agent chat"
                  className="inline-flex items-center justify-center w-8 h-8 rounded-md text-white/65 hover:text-white hover:bg-white/[0.08] transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Model Speed/Depth Switcher + Sync status bar */}
            <div className="px-4 py-2.5 bg-[#061648] border-b border-white/[0.08] flex items-center justify-between gap-2">
              <div
                role="tablist"
                aria-label="AI Agent response mode"
                className="inline-flex items-center p-0.5 rounded-md bg-white/[0.06] border border-white/10"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={mode === 'general'}
                  onClick={() => setMode('general')}
                  className={`px-2.5 py-1 text-[11.5px] font-medium rounded transition-colors whitespace-nowrap ${
                    mode === 'general'
                      ? 'bg-[#1769F4] text-white'
                      : 'text-white/65 hover:text-white'
                  }`}
                >
                  Balanced
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={mode === 'fast'}
                  onClick={() => setMode('fast')}
                  className={`px-2.5 py-1 text-[11.5px] font-medium rounded transition-colors whitespace-nowrap ${
                    mode === 'fast'
                      ? 'bg-[#1769F4] text-white'
                      : 'text-white/65 hover:text-white'
                  }`}
                >
                  Fast
                </button>
              </div>

              <button
                type="button"
                onClick={onOpenAccount}
                className="inline-flex items-center gap-1.5 text-[11.5px] text-[#BFE8FF]/85 hover:text-white transition-colors whitespace-nowrap"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>{user ? 'View Saved Profile' : 'Sign in to Save'}</span>
              </button>
            </div>

            {/* Scrollable Multi-Turn Message Thread */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3.5">
              {messages.length === 0 ? (
                <div className="space-y-4 py-2">
                  <div className="rounded-xl bg-[#0A1F5E]/80 border border-white/10 p-4 text-[13.5px] leading-[1.6] text-white/86">
                    Ask me about YouTube content strategy, script hooks, packaging concepts, Galaxy
                    Media services, or your saved session diagnostics.
                  </div>

                  <div className="space-y-2">
                    <p className="text-[11px] font-medium uppercase tracking-[0.12em] text-white/45 px-1">
                      Suggested questions
                    </p>
                    {STARTER_PROMPTS.map((prompt) => (
                      <button
                        key={prompt}
                        type="button"
                        onClick={() => void sendMessage(prompt)}
                        className="w-full text-left rounded-xl bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 hover:border-[#4398FF]/50 px-3.5 py-2.5 text-[13px] text-white/85 transition-colors"
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                messages.map((turn) => {
                  const isUser = turn.role === 'user';
                  return (
                    <div
                      key={turn.id}
                      className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-[86%] rounded-2xl px-3.5 py-2.5 text-[13.5px] leading-[1.6] whitespace-pre-wrap break-words ${
                          isUser
                            ? 'bg-[#1769F4] text-white rounded-br-sm'
                            : 'bg-[#0A1F5E]/90 border border-white/10 text-white/90 rounded-bl-sm'
                        }`}
                      >
                        {turn.content}
                      </div>
                      {!isUser && (
                        <span className="mt-1 px-1 text-[10.5px] font-mono text-white/40">
                          {turn.modelUsed}
                        </span>
                      )}
                    </div>
                  );
                })
              )}

              {sending && (
                <div className="flex items-start">
                  <div className="inline-flex items-center gap-2 rounded-2xl rounded-bl-sm bg-[#0A1F5E]/90 border border-white/10 px-3.5 py-2.5 text-[13px] text-[#BFE8FF]">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Thinking...</span>
                  </div>
                </div>
              )}

              {error && (
                <div
                  role="alert"
                  className="flex items-start gap-2 rounded-xl bg-rose-500/15 border border-rose-400/35 px-3.5 py-2.5 text-[12.5px] text-rose-200"
                >
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div ref={threadEndRef} />
            </div>

            {/* Composer */}
            <form
              onSubmit={handleSubmit}
              className="p-3 bg-[#040D31] border-t border-white/10 flex items-center gap-2"
            >
              <label htmlFor="galaxy-ai-input" className="sr-only">
                Message Galaxy Media AI Agent
              </label>
              <input
                ref={inputRef}
                id="galaxy-ai-input"
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={sending}
                placeholder="Ask Galaxy Media AI Agent..."
                className="flex-1 rounded-lg bg-[#081A52] border border-white/15 hover:border-white/25 px-3.5 py-2.5 text-[13.5px] text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-[#4398FF]"
              />
              <button
                type="submit"
                disabled={sending || !input.trim()}
                aria-label="Send message"
                className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-[#E7FF4B] hover:bg-[#dcfa2d] disabled:opacity-45 text-[#030B2C] transition-colors shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.section>
        )}
      </AnimatePresence>

      {/* Floating Toggle Button */}
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        aria-expanded={isOpen}
        aria-label={isOpen ? 'Close Galaxy Media AI Agent' : 'Open Galaxy Media AI Agent'}
        className="inline-flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#030B2C] hover:bg-[#0B328D] text-white border border-[#BFE8FF]/35 shadow-[0_14px_40px_rgba(3,11,44,0.55)] transition-all duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E7FF4B]"
      >
        {isOpen ? (
          <X className="w-4 h-4 text-[#E7FF4B]" />
        ) : (
          <MessageSquare className="w-4 h-4 text-[#E7FF4B]" />
        )}
        <span className="text-[13.5px] font-medium whitespace-nowrap">
          {isOpen ? 'Close Agent' : 'AI Agent'}
        </span>
      </button>
    </div>
  );
}
