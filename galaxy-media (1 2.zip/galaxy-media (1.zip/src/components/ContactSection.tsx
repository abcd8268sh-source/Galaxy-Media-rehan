import {useEffect, useRef, useState, type FormEvent} from 'react';
import {AlertCircle, ArrowRight, CheckCircle2, Loader2} from 'lucide-react';
import {CONTACT_SERVICE_OPTIONS} from '../data/siteContent';
import {Reveal} from './Reveal';
import {MagneticButton} from './MagneticButton';

interface ContactSectionProps {
  preselectedService?: string;
  preselectedNote?: string;
}

interface FormState {
  name: string;
  email: string;
  companyOrChannel: string;
  service: string;
  details: string;
}

interface FieldErrors {
  name?: string;
  email?: string;
  service?: string;
  details?: string;
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function ContactSection({preselectedService, preselectedNote}: ContactSectionProps) {
  const nameInputRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState<FormState>({
    name: '',
    email: '',
    companyOrChannel: '',
    service: CONTACT_SERVICE_OPTIONS[0],
    details: '',
  });

  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [confirmation, setConfirmation] = useState<{
    id: string;
    message: string;
  } | null>(null);

  useEffect(() => {
    if (preselectedService) {
      const matched = CONTACT_SERVICE_OPTIONS.find(
        (opt) =>
          opt.toLowerCase() === preselectedService.toLowerCase() ||
          opt.toLowerCase().includes(preselectedService.toLowerCase().split(' ')[0]),
      );
      setForm((prev) => ({
        ...prev,
        service: matched ?? prev.service,
      }));
    }
  }, [preselectedService]);

  useEffect(() => {
    if (preselectedNote) {
      setForm((prev) => ({
        ...prev,
        details: preselectedNote,
      }));
    }
  }, [preselectedNote]);

  const validateClient = (values: FormState): FieldErrors => {
    const errors: FieldErrors = {};
    if (values.name.trim().length < 2) {
      errors.name = 'Please enter your full name.';
    }
    if (!EMAIL_PATTERN.test(values.email.trim())) {
      errors.email = 'Please enter a valid email address.';
    }
    if (!values.service.trim()) {
      errors.service = 'Please select a service.';
    }
    if (values.details.trim().length < 15) {
      errors.details = 'Please describe your project or goals (at least 15 characters).';
    }
    return errors;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setServerError(null);

    const errors = validateClient(form);
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      return;
    }

    setFieldErrors({});
    setSubmitting(true);

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(form),
      });

      const data = await response.json();

      if (!response.ok || !data.ok) {
        if (data.fieldErrors) {
          setFieldErrors(data.fieldErrors);
        }
        setServerError(
          data.error || 'We could not submit your inquiry right now. Please try again.',
        );
        return;
      }

      setConfirmation({
        id: data.id,
        message: data.message,
      });
      setForm({
        name: '',
        email: '',
        companyOrChannel: '',
        service: CONTACT_SERVICE_OPTIONS[0],
        details: '',
      });
    } catch {
      setServerError('Network error while sending your inquiry. Please check your connection and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const focusForm = () => {
    nameInputRef.current?.focus();
  };

  return (
    <section
      id="contact"
      className="relative overflow-hidden py-24 sm:py-28 md:py-36 text-white"
      style={{
        background:
          'linear-gradient(160deg, #030B2C 0%, #0B328D 45%, #1769F4 100%)',
      }}
    >
      {/* Subtle halftone dot sheen */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-y-0 left-0 w-72 halftone-dots-light opacity-30"
        style={{
          maskImage: 'radial-gradient(ellipse at 0% 50%, black 0%, transparent 72%)',
          WebkitMaskImage: 'radial-gradient(ellipse at 0% 50%, black 0%, transparent 72%)',
        }}
      />

      <div className="relative z-10 mx-auto max-w-[1320px] px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-start">
          {/* Left: High-impact Editorial CTA Column */}
          <div className="lg:col-span-5 lg:pt-4">
            <Reveal>
              <p className="text-[12px] font-semibold tracking-[0.16em] uppercase text-[#BFE8FF] mb-4">
                Start a Project
              </p>
              <h2 className="font-display font-medium text-white tracking-[-0.03em] leading-[1.06] text-[clamp(2.15rem,4.2vw,3.5rem)] [text-wrap:balance]">
                Have something worth creating?
              </h2>
              <p className="mt-5 text-[16.5px] sm:text-[18px] leading-[1.6] text-white/82 max-w-[440px]">
                Let&apos;s turn your next idea into something people remember.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <MagneticButton
                  type="button"
                  onClick={focusForm}
                  proximity={48}
                  maxPull={9}
                  className="group inline-flex items-center gap-2 px-6 py-3 text-[14.5px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md transition-colors whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  <span>Start a Conversation</span>
                  <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-0.5" />
                </MagneticButton>

                <MagneticButton
                  as="a"
                  href="#work"
                  proximity={46}
                  maxPull={8}
                  className="inline-flex items-center px-5 py-3 text-[14.5px] font-medium text-white border border-white/30 hover:border-white/60 hover:bg-white/[0.08] rounded-md transition-colors whitespace-nowrap"
                >
                  Explore Our Work
                </MagneticButton>
              </div>

              <div className="mt-12 pt-8 border-t border-white/15 space-y-2.5 text-[14px] text-white/75">
                <p className="text-[12px] font-medium uppercase tracking-[0.12em] text-[#BFE8FF]/80">
                  Direct Inquiries
                </p>
                <p>
                  Share your channel link, format goals, or upcoming launch timeline. Every inquiry
                  is reviewed directly by our creative production leads.
                </p>
              </div>
            </Reveal>
          </div>

          {/* Right: Accessible, Real-API Contact Form */}
          <div className="lg:col-span-7">
            <Reveal delay={0.1}>
              <div className="rounded-2xl bg-[#05123D]/85 border border-white/15 backdrop-blur-md p-6 sm:p-9 shadow-[0_24px_70px_rgba(3,11,44,0.45)]">
                {confirmation ? (
                  <div
                    role="status"
                    aria-live="polite"
                    className="py-8 sm:py-10 text-left space-y-4"
                  >
                    <div className="inline-flex items-center gap-2.5 text-[#E7FF4B]">
                      <CheckCircle2 className="w-6 h-6 shrink-0" />
                      <span className="font-mono text-[13px] tracking-wide">
                        Reference {confirmation.id}
                      </span>
                    </div>
                    <h3 className="font-display font-medium text-[26px] text-white tracking-[-0.02em]">
                      Inquiry received.
                    </h3>
                    <p className="text-[15.5px] leading-[1.65] text-white/80 max-w-[500px]">
                      {confirmation.message}
                    </p>
                    <div className="pt-4">
                      <MagneticButton
                        type="button"
                        onClick={() => setConfirmation(null)}
                        proximity={40}
                        maxPull={7}
                        className="inline-flex items-center px-4 py-2.5 text-[13.5px] font-medium text-white border border-white/25 hover:border-white/60 rounded-md transition-colors"
                      >
                        Send another inquiry
                      </MagneticButton>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} noValidate className="space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label
                          htmlFor="contact-name"
                          className="block text-[13px] font-medium text-white/85 mb-2"
                        >
                          Name <span className="text-[#E7FF4B]">*</span>
                        </label>
                        <input
                          ref={nameInputRef}
                          id="contact-name"
                          name="name"
                          type="text"
                          autoComplete="name"
                          required
                          value={form.name}
                          onChange={(e) => {
                            setForm((prev) => ({...prev, name: e.target.value}));
                            if (fieldErrors.name) {
                              setFieldErrors((prev) => ({...prev, name: undefined}));
                            }
                          }}
                          placeholder="Your full name"
                          aria-invalid={Boolean(fieldErrors.name)}
                          aria-describedby={fieldErrors.name ? 'contact-name-error' : undefined}
                          className={`w-full rounded-lg bg-[#030B2C]/70 border px-4 py-3 text-[15px] text-white placeholder:text-white/35 focus:outline-none focus:ring-2 focus:ring-[#4398FF] transition-colors ${
                            fieldErrors.name
                              ? 'border-rose-400'
                              : 'border-white/15 hover:border-white/30'
                          }`}
                        />
                        {fieldErrors.name && (
                          <p id="contact-name-error" className="mt-1.5 text-[12.5px] text-rose-300">
                            {fieldErrors.name}
                          </p>
                        )}
                      </div>

                      <div>
                        <label
                          htmlFor="contact-email"
                          className="block text-[13px] font-medium text-white/85 mb-2"
                        >
                          Email <span className="text-[#E7FF4B]">*</span>
                        </label>
                        <input
                          id="contact-email"
                          name="email"
                          type="email"
                          autoComplete="email"
                          required
                          value={form.email}
                          onChange={(e) => {
                            setForm((prev) => ({...prev, email: e.target.value}));
                            if (fieldErrors.email) {
                              setFieldErrors((prev) => ({...prev, email: undefined}));
                            }
                          }}
                          placeholder="you@company.com"
                          aria-invalid={Boolean(fieldErrors.email)}
                          aria-describedby={fieldErrors.email ? 'contact-email-error' : undefined}
                          className={`w-full rounded-lg bg-[#030B2C]/70 border px-4 py-3 text-[15px] text-white placeholder:text-white/35 focus:outline-none focus:ring-2 focus:ring-[#4398FF] transition-colors ${
                            fieldErrors.email
                              ? 'border-rose-400'
                              : 'border-white/15 hover:border-white/30'
                          }`}
                        />
                        {fieldErrors.email && (
                          <p id="contact-email-error" className="mt-1.5 text-[12.5px] text-rose-300">
                            {fieldErrors.email}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label
                          htmlFor="contact-org"
                          className="block text-[13px] font-medium text-white/85 mb-2"
                        >
                          Company or Channel
                        </label>
                        <input
                          id="contact-org"
                          name="companyOrChannel"
                          type="text"
                          value={form.companyOrChannel}
                          onChange={(e) =>
                            setForm((prev) => ({...prev, companyOrChannel: e.target.value}))
                          }
                          placeholder="Channel name or organization"
                          className="w-full rounded-lg bg-[#030B2C]/70 border border-white/15 hover:border-white/30 px-4 py-3 text-[15px] text-white placeholder:text-white/35 focus:outline-none focus:ring-2 focus:ring-[#4398FF] transition-colors"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="contact-service"
                          className="block text-[13px] font-medium text-white/85 mb-2"
                        >
                          Service required <span className="text-[#E7FF4B]">*</span>
                        </label>
                        <select
                          id="contact-service"
                          name="service"
                          value={form.service}
                          onChange={(e) => {
                            setForm((prev) => ({...prev, service: e.target.value}));
                            if (fieldErrors.service) {
                              setFieldErrors((prev) => ({...prev, service: undefined}));
                            }
                          }}
                          aria-invalid={Boolean(fieldErrors.service)}
                          className="w-full rounded-lg bg-[#030B2C]/90 border border-white/15 hover:border-white/30 px-4 py-3 text-[15px] text-white focus:outline-none focus:ring-2 focus:ring-[#4398FF] transition-colors"
                        >
                          {CONTACT_SERVICE_OPTIONS.map((option) => (
                            <option key={option} value={option} className="bg-[#030B2C] text-white">
                              {option}
                            </option>
                          ))}
                        </select>
                        {fieldErrors.service && (
                          <p className="mt-1.5 text-[12.5px] text-rose-300">
                            {fieldErrors.service}
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="contact-details"
                        className="block text-[13px] font-medium text-white/85 mb-2"
                      >
                        Project details <span className="text-[#E7FF4B]">*</span>
                      </label>
                      <textarea
                        id="contact-details"
                        name="details"
                        rows={4}
                        required
                        value={form.details}
                        onChange={(e) => {
                          setForm((prev) => ({...prev, details: e.target.value}));
                          if (fieldErrors.details) {
                            setFieldErrors((prev) => ({...prev, details: undefined}));
                          }
                        }}
                        placeholder="Tell us about your channel, content format, and what you are looking to build."
                        aria-invalid={Boolean(fieldErrors.details)}
                        aria-describedby={fieldErrors.details ? 'contact-details-error' : undefined}
                        className={`w-full rounded-lg bg-[#030B2C]/70 border px-4 py-3 text-[15px] text-white placeholder:text-white/35 focus:outline-none focus:ring-2 focus:ring-[#4398FF] transition-colors resize-y ${
                          fieldErrors.details
                            ? 'border-rose-400'
                            : 'border-white/15 hover:border-white/30'
                        }`}
                      />
                      {fieldErrors.details && (
                        <p id="contact-details-error" className="mt-1.5 text-[12.5px] text-rose-300">
                          {fieldErrors.details}
                        </p>
                      )}
                    </div>

                    {serverError && (
                      <div
                        role="alert"
                        className="flex items-start gap-2.5 rounded-lg bg-rose-500/15 border border-rose-400/35 px-4 py-3 text-[13.5px] text-rose-200"
                      >
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{serverError}</span>
                      </div>
                    )}

                    <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
                      <p className="text-[12.5px] text-white/55">
                        Submissions are validated and logged server-side.
                      </p>
                      <MagneticButton
                        type="submit"
                        disabled={submitting}
                        proximity={46}
                        maxPull={8}
                        className="inline-flex items-center justify-center gap-2 px-6 py-3 text-[14.5px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] disabled:opacity-65 disabled:cursor-not-allowed rounded-md transition-colors whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                      >
                        {submitting ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Sending...</span>
                          </>
                        ) : (
                          <>
                            <span>Submit Inquiry</span>
                            <ArrowRight className="w-4 h-4" />
                          </>
                        )}
                      </MagneticButton>
                    </div>
                  </form>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
