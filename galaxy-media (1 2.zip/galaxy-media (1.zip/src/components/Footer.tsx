import {NAV_LINKS, SERVICES} from '../data/siteContent';
import {BrandMark} from './BrandMark';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer
      className="relative overflow-hidden text-white pt-20 sm:pt-24"
      style={{
        background:
          'linear-gradient(180deg, #030B2C 0%, #06184F 48%, #0B328D 100%)',
      }}
    >
      {/* Subtle top edge hairline */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#4398FF]/45 to-transparent"
      />

      {/* Ambient royal glow behind giant wordmark */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 bottom-0 -translate-x-1/2 w-[1100px] h-[340px] rounded-full bg-[#1769F4]/30 blur-[120px]"
      />

      {/* Top Navigation & Information Grid */}
      <div className="relative z-10 mx-auto max-w-[1320px] px-5 sm:px-8 pb-16 sm:pb-20">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-12">
          {/* Positioning Statement */}
          <div className="md:col-span-4 space-y-4">
            <a href="#home" className="inline-flex items-center gap-2.5 text-white">
              <BrandMark className="w-6 h-6 text-white" />
              <span className="font-display font-semibold text-[15px] tracking-[0.04em] uppercase">
                Galaxy Media
              </span>
            </a>
            <p className="text-[14.5px] leading-[1.65] text-white/68 max-w-[320px]">
              An independent digital media company transforming ambitious ideas into distinctive
              YouTube channels and enduring content brands.
            </p>
          </div>

          {/* Navigation Column */}
          <div className="md:col-span-2">
            <h3 className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#BFE8FF]/80 mb-4">
              Navigation
            </h3>
            <ul className="space-y-2.5 text-[14px] text-white/72">
              {NAV_LINKS.map((link) => (
                <li key={link.id}>
                  <a href={link.href} className="hover:text-white transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
              <li>
                <a href="#contact" className="hover:text-white transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Services Column */}
          <div className="md:col-span-3">
            <h3 className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#BFE8FF]/80 mb-4">
              Services
            </h3>
            <ul className="space-y-2.5 text-[14px] text-white/72">
              {SERVICES.map((service) => (
                <li key={service.number}>
                  <a href="#services" className="hover:text-white transition-colors">
                    {service.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Social Column */}
          <div className="md:col-span-3">
            <h3 className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#BFE8FF]/80 mb-4">
              Connect
            </h3>
            <ul className="space-y-2.5 text-[14px] text-white/72">
              <li>
                <a href="#contact" className="hover:text-white transition-colors">
                  Start a Project Inquiry
                </a>
              </li>
              <li>
                <a
                  href="mailto:hello@galaxymedia.co"
                  className="hover:text-white transition-colors"
                >
                  hello@galaxymedia.co
                </a>
              </li>
              <li className="pt-2 flex flex-wrap items-center gap-x-4 gap-y-2 text-[13.5px] text-white/65">
                <a
                  href="https://youtube.com"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition-colors"
                >
                  YouTube
                </a>
                <a
                  href="https://x.com"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition-colors"
                >
                  X
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition-colors"
                >
                  LinkedIn
                </a>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition-colors"
                >
                  Instagram
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Giant Edge-to-Edge Typographic Wordmark (inspired by Frames 00:11 & 00:12) */}
      <div className="relative z-10 w-full overflow-hidden select-none px-2 sm:px-4">
        <svg
          viewBox="0 0 1440 215"
          className="w-full h-auto block"
          role="img"
          aria-label="Galaxy Media"
        >
          <defs>
            <linearGradient id="footerWordmarkGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#E6F4FF" stopOpacity="0.88" />
              <stop offset="52%" stopColor="#8CC7FF" stopOpacity="0.46" />
              <stop offset="100%" stopColor="#1769F4" stopOpacity="0.12" />
            </linearGradient>
          </defs>
          <text
            x="720"
            y="174"
            textAnchor="middle"
            fill="url(#footerWordmarkGrad)"
            className="font-display font-bold"
            style={{
              fontSize: '180px',
              letterSpacing: '-0.045em',
            }}
          >
            GALAXY MEDIA
          </text>
        </svg>
      </div>

      {/* Quiet Copyright Strip */}
      <div className="relative z-10 border-t border-white/10">
        <div className="mx-auto max-w-[1320px] px-5 sm:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-[12.5px] text-white/55">
          <p>&copy; {currentYear} Galaxy Media. All rights reserved.</p>
          <p>We Build Media That Moves People.</p>
        </div>
      </div>
    </footer>
  );
}
