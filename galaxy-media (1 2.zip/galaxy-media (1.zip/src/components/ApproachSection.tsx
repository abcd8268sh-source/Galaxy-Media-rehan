import {Reveal} from './Reveal';

function AudienceFirstChart() {
  // Minimalist column visual inspired by Frame 00:08 of the reference
  const bars = [26, 40, 34, 56, 68, 82, 74, 92];
  return (
    <svg
      viewBox="0 0 280 150"
      className="w-full h-full"
      role="img"
      aria-label="Abstract audience attention distribution graphic"
    >
      {[34, 68, 102, 132].map((y) => (
        <line key={y} x1="18" x2="262" y1={y} y2={y} stroke="#101421" strokeOpacity="0.06" />
      ))}
      {bars.map((height, idx) => {
        const x = 28 + idx * 29;
        const y = 132 - height;
        const isPrimary = idx >= 5;
        return (
          <rect
            key={idx}
            x={x}
            y={y}
            width="18"
            height={height}
            rx="3"
            fill={isPrimary ? '#1769F4' : '#BFE8FF'}
            fillOpacity={isPrimary ? 0.92 : 0.72}
          />
        );
      })}
      <circle cx="240" cy="40" r="3.5" fill="#030B2C" />
    </svg>
  );
}

function StoryDrivenChart() {
  // Narrative tension & hook arc diagram
  return (
    <svg
      viewBox="0 0 280 150"
      className="w-full h-full"
      role="img"
      aria-label="Abstract narrative pacing and hook arc diagram"
    >
      <defs>
        <linearGradient id="storyArcFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1769F4" stopOpacity="0.22" />
          <stop offset="100%" stopColor="#1769F4" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[34, 68, 102, 132].map((y) => (
        <line key={y} x1="18" x2="262" y1={y} y2={y} stroke="#101421" strokeOpacity="0.06" />
      ))}
      <path
        d="M 24 114 C 52 54, 72 44, 96 64 C 122 86, 148 48, 182 54 C 216 60, 232 34, 256 38 L 256 132 L 24 132 Z"
        fill="url(#storyArcFill)"
      />
      <path
        d="M 24 114 C 52 54, 72 44, 96 64 C 122 86, 148 48, 182 54 C 216 60, 232 34, 256 38"
        fill="none"
        stroke="#1769F4"
        strokeWidth="2.4"
        strokeLinecap="round"
      />
      {/* Story beats */}
      <circle cx="64" cy="54" r="4" fill="#FFFFFF" stroke="#1769F4" strokeWidth="2" />
      <circle cx="154" cy="56" r="4" fill="#FFFFFF" stroke="#1769F4" strokeWidth="2" />
      <circle cx="256" cy="38" r="4.5" fill="#030B2C" />
    </svg>
  );
}

function BuiltToScaleChart() {
  // Structured modular production workflow lanes
  const lanes = [
    {y: 34, start: 26, len: 84, color: '#030B2C'},
    {y: 62, start: 64, len: 102, color: '#0B328D'},
    {y: 90, start: 112, len: 96, color: '#1769F4'},
    {y: 118, start: 162, len: 90, color: '#4398FF'},
  ];

  return (
    <svg
      viewBox="0 0 280 150"
      className="w-full h-full"
      role="img"
      aria-label="Abstract structured production workflow diagram"
    >
      {[60, 120, 180, 240].map((x) => (
        <line
          key={x}
          x1={x}
          x2={x}
          y1="20"
          y2="138"
          stroke="#101421"
          strokeOpacity="0.06"
          strokeDasharray="3 4"
        />
      ))}
      {lanes.map((lane, idx) => (
        <g key={idx}>
          <rect
            x="24"
            y={lane.y}
            width="232"
            height="14"
            rx="4"
            fill="#101421"
            fillOpacity="0.04"
          />
          <rect
            x={lane.start}
            y={lane.y}
            width={lane.len}
            height="14"
            rx="4"
            fill={lane.color}
          />
        </g>
      ))}
    </svg>
  );
}

const APPROACH_PILLARS = [
  {
    title: 'Audience First',
    description: 'Every creative decision starts with understanding the viewer.',
    graphic: <AudienceFirstChart />,
  },
  {
    title: 'Story Driven',
    description:
      'We focus on compelling narratives, strong openings, and satisfying storytelling.',
    graphic: <StoryDrivenChart />,
  },
  {
    title: 'Built to Scale',
    description:
      'Structured workflows connect research, scripting, editing, packaging, and publishing.',
    graphic: <BuiltToScaleChart />,
  },
];

export function ApproachSection() {
  return (
    <section className="bg-white py-24 sm:py-28 md:py-36">
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        <Reveal>
          <div className="text-center max-w-[700px] mx-auto mb-16 sm:mb-20">
            <p className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#1769F4] mb-4">
              The Galaxy Media Approach
            </p>
            <h2 className="font-display font-medium text-[#101421] tracking-[-0.03em] leading-[1.08] text-[clamp(2rem,4vw,3.35rem)] [text-wrap:balance]">
              Creative thinking. Production discipline.
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-10">
          {APPROACH_PILLARS.map((pillar, index) => (
            <Reveal key={pillar.title} delay={index * 0.08}>
              <div className="flex flex-col">
                <div className="aspect-[16/10] w-full rounded-2xl bg-[#FAFBFD] border border-[#101421]/[0.08] p-5 flex items-center justify-center mb-6">
                  {pillar.graphic}
                </div>
                <h3 className="font-display font-medium text-[21px] sm:text-[23px] tracking-[-0.02em] text-[#101421]">
                  {pillar.title}
                </h3>
                <p className="mt-2.5 text-[15.5px] leading-[1.65] text-[#101421]/66">
                  {pillar.description}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
