import {useState, type FormEvent} from 'react';
import {AlertCircle, CheckCircle2, Loader2} from 'lucide-react';
import {Reveal} from './Reveal';
import {MagneticButton} from './MagneticButton';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [consent, setConsent] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [imgFailed, setImgFailed] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setStatusMessage(null);

    const trimmed = email.trim();
    if (!EMAIL_PATTERN.test(trimmed)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (!consent) {
      setError('Please confirm that you consent to receiving Galaxy Insights emails.');
      return;
    }

    setSubmitting(true);
    try {
      const response = await fetch('/api/newsletter', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email: trimmed, consent: true}),
      });

      const data = await response.json();
      if (!response.ok || !data.ok) {
        setError(data.error || 'Could not complete your subscription. Please try again.');
        return;
      }

      setStatusMessage(data.message);
      setEmail('');
      setConsent(false);
    } catch {
      setError('Network error while subscribing. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="bg-white py-24 sm:py-28 md:py-36">
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Left: Editorial Newsletter Form (inspired by Frame 00:10) */}
          <div className="lg:col-span-6">
            <Reveal>
              <p className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#1769F4] mb-4">
                Galaxy Insights
              </p>
              <h2 className="font-display font-medium text-[#101421] tracking-[-0.03em] leading-[1.08] text-[clamp(2rem,3.8vw,3.15rem)] [text-wrap:balance]">
                Good ideas deserve to travel.
              </h2>
              <p className="mt-4 text-[16px] sm:text-[17px] leading-[1.65] text-[#101421]/66 max-w-[490px]">
                Occasional insights on storytelling, production, audience behavior, and the future
                of digital media.
              </p>

              <form onSubmit={handleSubmit} noValidate className="mt-8 max-w-[490px]">
                <div className="flex flex-col sm:flex-row gap-3">
                  <label htmlFor="newsletter-email" className="sr-only">
                    Email address
                  </label>
                  <input
                    id="newsletter-email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (error) setError(null);
                    }}
                    placeholder="Enter your email address"
                    aria-invalid={Boolean(error)}
                    className="flex-1 rounded-lg bg-[#FAFBFD] border border-[#101421]/15 hover:border-[#101421]/30 px-4 py-3 text-[15px] text-[#101421] placeholder:text-[#101421]/40 focus:outline-none focus:ring-2 focus:ring-[#1769F4] transition-colors"
                  />
                  <MagneticButton
                    type="submit"
                    disabled={submitting}
                    proximity={42}
                    maxPull={7}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 text-[14.5px] font-medium text-white bg-[#030B2C] hover:bg-[#0B328D] disabled:opacity-65 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1769F4]"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Subscribing...</span>
                      </>
                    ) : (
                      <span>Subscribe</span>
                    )}
                  </MagneticButton>
                </div>

                {/* Explicit Consent Checkbox */}
                <label className="mt-4 flex items-start gap-2.5 text-[13px] leading-[1.5] text-[#101421]/60 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={consent}
                    onChange={(e) => {
                      setConsent(e.target.checked);
                      if (error) setError(null);
                    }}
                    className="mt-0.5 h-4 w-4 rounded border-[#101421]/30 text-[#1769F4] focus:ring-[#1769F4]"
                  />
                  <span>
                    I agree to receive occasional editorial dispatches from Galaxy Media. You can
                    unsubscribe at any time.
                  </span>
                </label>

                {error && (
                  <div
                    role="alert"
                    className="mt-4 flex items-start gap-2 text-[13.5px] text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3.5 py-2.5"
                  >
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                {statusMessage && (
                  <div
                    role="status"
                    aria-live="polite"
                    className="mt-4 flex items-start gap-2 text-[13.5px] text-[#0B328D] bg-[#EAF3FF] border border-[#1769F4]/25 rounded-lg px-3.5 py-2.5"
                  >
                    <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-[#1769F4]" />
                    <span>{statusMessage}</span>
                  </div>
                )}
              </form>
            </Reveal>
          </div>

          {/* Right: Glossy 3D Blue Media Envelope Editorial Visual (matching Frame 00:10) */}
          <div className="lg:col-span-6">
            <Reveal delay={0.1}>
              <div className="relative aspect-[4/3] w-full rounded-2xl overflow-hidden bg-[#EAF3FF] border border-[#1769F4]/12">
                {!imgFailed ? (
                  <img
                    src="/src/assets/images/newsletter_blue_envelope_1795094698950.jpg"
                    alt="Glossy royal blue 3D editorial media dispatch envelope"
                    referrerPolicy="no-referrer"
                    onError={() => setImgFailed(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div
                    className="w-full h-full flex items-center justify-center p-10"
                    style={{
                      background:
                        'radial-gradient(circle at 50% 45%, #EBF4FF 0%, #D5E8FF 100%)',
                    }}
                  >
                    <svg viewBox="0 0 240 160" className="w-56 h-auto" aria-hidden="true">
                      <defs>
                        <linearGradient id="fallbackEnv" x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0%" stopColor="#4398FF" />
                          <stop offset="50%" stopColor="#1769F4" />
                          <stop offset="100%" stopColor="#0B328D" />
                        </linearGradient>
                      </defs>
                      <rect
                        x="20"
                        y="24"
                        width="200"
                        height="112"
                        rx="14"
                        fill="url(#fallbackEnv)"
                      />
                      <path
                        d="M 26 32 L 120 94 L 214 32"
                        fill="none"
                        stroke="#BFE8FF"
                        strokeWidth="3"
                        strokeLinecap="round"
                      />
                    </svg>
                  </div>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
