import {
  useEffect,
  useRef,
  type AnchorHTMLAttributes,
  type ButtonHTMLAttributes,
  type ReactNode,
} from 'react';
import {motion, useMotionValue, useReducedMotion, useSpring} from 'motion/react';

type PointerListener = (clientX: number | null, clientY: number | null) => void;

const listeners = new Set<PointerListener>();
let globalListenersAttached = false;

function handleGlobalPointerMove(e: PointerEvent) {
  if (e.pointerType !== 'mouse') return;
  listeners.forEach((fn) => fn(e.clientX, e.clientY));
}

function handleGlobalPointerLeave() {
  listeners.forEach((fn) => fn(null, null));
}

function subscribePointer(fn: PointerListener) {
  listeners.add(fn);
  if (!globalListenersAttached && typeof window !== 'undefined') {
    window.addEventListener('pointermove', handleGlobalPointerMove, {passive: true});
    document.documentElement.addEventListener('pointerleave', handleGlobalPointerLeave, {
      passive: true,
    });
    window.addEventListener('blur', handleGlobalPointerLeave);
    globalListenersAttached = true;
  }

  return () => {
    listeners.delete(fn);
    if (listeners.size === 0 && globalListenersAttached && typeof window !== 'undefined') {
      window.removeEventListener('pointermove', handleGlobalPointerMove);
      document.documentElement.removeEventListener('pointerleave', handleGlobalPointerLeave);
      window.removeEventListener('blur', handleGlobalPointerLeave);
      globalListenersAttached = false;
    }
  };
}

interface MagneticBaseProps {
  children: ReactNode;
  className?: string;
  /** Magnetic pull radius outside the button bounds in px */
  proximity?: number;
  /** Maximum displacement in px */
  maxPull?: number;
  disabledMagnetic?: boolean;
}

type MagneticButtonElementProps = MagneticBaseProps & {
  as?: 'button';
} & Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className' | 'children'>;

type MagneticAnchorElementProps = MagneticBaseProps & {
  as: 'a';
} & Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'className' | 'children'>;

export type MagneticButtonProps = MagneticButtonElementProps | MagneticAnchorElementProps;

export function MagneticButton(props: MagneticButtonProps) {
  const {
    children,
    className = '',
    proximity = 44,
    maxPull = 8,
    disabledMagnetic = false,
    ...rest
  } = props;

  const containerRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();
  const isDisabled =
    disabledMagnetic ||
    Boolean(prefersReducedMotion) ||
    (props.as !== 'a' && Boolean((props as ButtonHTMLAttributes<HTMLButtonElement>).disabled));

  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);

  const springConfig = {stiffness: 280, damping: 20, mass: 0.45};
  const x = useSpring(rawX, springConfig);
  const y = useSpring(rawY, springConfig);

  useEffect(() => {
    if (isDisabled) {
      rawX.set(0);
      rawY.set(0);
      return;
    }

    return subscribePointer((clientX, clientY) => {
      const el = containerRef.current;
      if (!el || clientX === null || clientY === null) {
        rawX.set(0);
        rawY.set(0);
        return;
      }

      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;

      // Distance from pointer to nearest point on button bounding box
      const clampedX = Math.max(rect.left, Math.min(clientX, rect.right));
      const clampedY = Math.max(rect.top, Math.min(clientY, rect.bottom));
      const distOutside = Math.hypot(clientX - clampedX, clientY - clampedY);

      if (distOutside > proximity) {
        rawX.set(0);
        rawY.set(0);
        return;
      }

      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const offsetX = clientX - centerX;
      const offsetY = clientY - centerY;

      // Smooth falloff from full strength inside the button to 0 at proximity boundary
      const falloff = distOutside === 0 ? 1 : Math.pow(1 - distOutside / proximity, 1.4);

      // Normalize pull against button half-extents + proximity
      const maxReachX = rect.width / 2 + proximity;
      const maxReachY = rect.height / 2 + proximity;

      const pullX = (offsetX / maxReachX) * maxPull * falloff;
      const pullY = (offsetY / maxReachY) * maxPull * falloff;

      rawX.set(pullX);
      rawY.set(pullY);
    });
  }, [isDisabled, proximity, maxPull, rawX, rawY]);

  const wrapperClass = className.includes('w-full') ? 'block w-full' : 'inline-block';

  if (props.as === 'a') {
    const {as: _as, ...anchorProps} = rest as Omit<
      MagneticAnchorElementProps,
      keyof MagneticBaseProps
    >;
    return (
      <div ref={containerRef} className={wrapperClass}>
        <motion.div style={{x, y}} className="will-change-transform">
          <a {...anchorProps} className={className}>
            {children}
          </a>
        </motion.div>
      </div>
    );
  }

  const {as: _as, ...buttonProps} = rest as Omit<
    MagneticButtonElementProps,
    keyof MagneticBaseProps
  >;

  return (
    <div ref={containerRef} className={wrapperClass}>
      <motion.div style={{x, y}} className="will-change-transform">
        <button {...buttonProps} className={className}>
          {children}
        </button>
      </motion.div>
    </div>
  );
}
