import {useState} from 'react';
import {ArrowUpRight} from 'lucide-react';
import {AnimatePresence, motion, useReducedMotion, type Variants} from 'motion/react';
import {SERVICES} from '../data/siteContent';
import {Reveal} from './Reveal';
import {MagneticButton} from './MagneticButton';

interface ServicesSectionProps {
  onSelectServiceForContact: (serviceTitle: string) => void;
}

const serviceListVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.09,
      delayChildren: 0.06,
    },
  },
};

const serviceItemVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 28,
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.72,
      ease: [0.16, 1, 0.3, 1],
    },
  },
};

export function ServicesSection({onSelectServiceForContact}: ServicesSectionProps) {
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const prefersReducedMotion = useReducedMotion();
  const activeService = SERVICES[activeIndex];

  return (
    <section id="services" className="bg-white py-24 sm:py-28 md:py-36">
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        {/* Editorial Intro Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-end pb-14 sm:pb-16 border-b border-[#101421]/10">
          <div className="lg:col-span-7">
            <Reveal>
              <p className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#1769F4] mb-4">
                What We Do
              </p>
              <h2 className="font-display font-medium text-[#101421] tracking-[-0.03em] leading-[1.08] text-[clamp(2rem,4vw,3.35rem)] [text-wrap:balance]">
                Great content doesn&apos;t happen by accident.
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-5">
            <Reveal delay={0.08}>
              <p className="text-[16px] sm:text-[17px] leading-[1.65] text-[#101421]/68 max-w-[460px]">
                We combine creative storytelling, production expertise, and audience-first thinking
                to build content people choose to watch.
              </p>
            </Reveal>
          </div>
        </div>

        {/* Asymmetric Editorial Grid inspired by the reference's crisp white + deep blue panel */}
        <div className="mt-12 sm:mt-16 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Left: Clean Numbered Editorial Service List with orchestrated staggered entrance */}
          <motion.div
            variants={prefersReducedMotion ? undefined : serviceListVariants}
            initial={prefersReducedMotion ? false : 'hidden'}
            whileInView={prefersReducedMotion ? undefined : 'visible'}
            viewport={{once: true, amount: 0.12}}
            className="lg:col-span-7 divide-y divide-[#101421]/10 border-b border-[#101421]/10"
          >
            {SERVICES.map((service, index) => {
              const isSelected = index === activeIndex;
              return (
                <motion.div
                  key={service.number}
                  variants={prefersReducedMotion ? undefined : serviceItemVariants}
                >
                  <button
                    type="button"
                    onClick={() => setActiveIndex(index)}
                    onMouseEnter={() => setActiveIndex(index)}
                    className={`group w-full text-left py-7 sm:py-8 transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#1769F4] rounded ${
                      isSelected ? 'bg-[#FAFBFD]' : 'hover:bg-[#FAFBFD]/70'
                    }`}
                  >
                    <div className="px-3 sm:px-5 flex items-start justify-between gap-6">
                      <div className="flex items-start gap-5 sm:gap-7">
                        <span
                          className={`font-mono text-[13px] pt-1.5 tabular-nums transition-colors duration-200 ${
                            isSelected ? 'text-[#1769F4] font-medium' : 'text-[#101421]/40'
                          }`}
                        >
                          {service.number}
                        </span>
                        <div>
                          <h3
                            className={`font-display text-[20px] sm:text-[23px] font-medium tracking-[-0.02em] transition-colors duration-200 ${
                              isSelected
                                ? 'text-[#030B2C]'
                                : 'text-[#101421]/85 group-hover:text-[#030B2C]'
                            }`}
                          >
                            {service.title}
                          </h3>
                          <p className="mt-2 text-[15px] leading-[1.6] text-[#101421]/65 max-w-[520px]">
                            {service.summary}
                          </p>
                          <div className="mt-3 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[12.5px] text-[#101421]/50">
                            {service.deliverables.map((item, i) => (
                              <span key={item} className="inline-flex items-center gap-2.5">
                                {i > 0 && <span aria-hidden="true">·</span>}
                                <span>{item}</span>
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      <ArrowUpRight
                        className={`w-5 h-5 shrink-0 mt-1.5 transition-all duration-200 ${
                          isSelected
                            ? 'text-[#1769F4] translate-x-0.5 -translate-y-0.5'
                            : 'text-[#101421]/30 group-hover:text-[#1769F4]'
                        }`}
                      />
                    </div>
                  </button>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Right: Sticky Royal-Blue Editorial Focus Panel echoing the reference's blue accent card */}
          <div className="lg:col-span-5 lg:sticky lg:top-28">
            <Reveal delay={0.14} y={28}>
              <div
                className="relative rounded-2xl overflow-hidden p-8 sm:p-10 text-white"
                style={{
                  background:
                    'linear-gradient(155deg, #030B2C 0%, #0B328D 55%, #1769F4 100%)',
                }}
              >
                {/* Halftone corner texture */}
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute right-0 bottom-0 w-48 h-48 halftone-dots-card opacity-55"
                  style={{
                    maskImage: 'radial-gradient(circle at 100% 100%, black 0%, transparent 72%)',
                    WebkitMaskImage: 'radial-gradient(circle at 100% 100%, black 0%, transparent 72%)',
                  }}
                />

                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeService.number}
                    initial={prefersReducedMotion ? false : {opacity: 0, y: 10}}
                    animate={{opacity: 1, y: 0}}
                    exit={prefersReducedMotion ? undefined : {opacity: 0, y: -6}}
                    transition={{duration: 0.28, ease: [0.16, 1, 0.3, 1]}}
                    className="relative z-10"
                  >
                    <div className="flex items-center justify-between text-[12px] font-mono text-[#BFE8FF]/80 mb-8">
                      <span>Discipline {activeService.number} / 05</span>
                      <span>{activeService.cadenceNote}</span>
                    </div>

                    <div className="font-display font-medium text-[56px] sm:text-[68px] leading-none tracking-[-0.04em] text-white/95 tabular-nums mb-5">
                      {activeService.number}
                    </div>

                    <h3 className="font-display font-medium text-[24px] sm:text-[28px] tracking-[-0.025em] text-white">
                      {activeService.title}
                    </h3>

                    <p className="mt-3.5 text-[15.5px] leading-[1.65] text-white/80">
                      {activeService.summary}
                    </p>

                    <div className="mt-8 pt-6 border-t border-white/15">
                      <p className="text-[11.5px] font-medium uppercase tracking-[0.12em] text-[#BFE8FF]/80 mb-3.5">
                        Core Focus Areas
                      </p>
                      <ul className="space-y-2.5 text-[14.5px] text-white/90">
                        {activeService.deliverables.map((item) => (
                          <li key={item} className="flex items-center gap-3">
                            <span
                              aria-hidden="true"
                              className="w-1.5 h-1.5 rounded-full bg-[#E7FF4B] shrink-0"
                            />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-9">
                      <MagneticButton
                        type="button"
                        onClick={() => onSelectServiceForContact(activeService.title)}
                        proximity={44}
                        maxPull={8}
                        className="inline-flex items-center gap-2 px-5 py-2.5 text-[13.5px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md transition-colors whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                      >
                        <span>Discuss {activeService.title}</span>
                        <ArrowUpRight className="w-4 h-4" />
                      </MagneticButton>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
