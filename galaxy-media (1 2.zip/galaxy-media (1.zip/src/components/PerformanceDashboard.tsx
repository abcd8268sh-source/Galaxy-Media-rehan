import {useState} from 'react';
import {motion, useReducedMotion} from 'motion/react';
import {
  DASHBOARD_DATASETS,
  PUBLISHING_TIMELINE_SAMPLE,
  type DashboardDataset,
} from '../data/siteContent';
import {BrandMark} from './BrandMark';

type TabView = 'overview' | 'retention' | 'timeline';

function formatCompactNumber(num: number): string {
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(2)}M`;
  if (num >= 1_000) return `${(num / 1_000).toFixed(1)}k`;
  return String(num);
}

export function PerformanceDashboard() {
  const [timeframe, setTimeframe] = useState<'30D' | '90D' | '12M'>('90D');
  const [activeTab, setActiveTab] = useState<TabView>('overview');
  const [hoveredIndex, setHoveredIndex] = useState<number>(5);
  const prefersReducedMotion = useReducedMotion();

  const dataset: DashboardDataset = DASHBOARD_DATASETS[timeframe];
  const points = dataset.points;

  // Build SVG path geometry
  const width = 620;
  const height = 220;
  const padX = 22;
  const padTop = 26;
  const padBottom = 34;

  const maxViews = Math.max(...points.map((p) => p.views)) * 1.12;
  const minViews = Math.min(...points.map((p) => p.views)) * 0.72;

  const coords = points.map((pt, idx) => {
    const x = padX + (idx / (points.length - 1)) * (width - padX * 2);
    const normalized = (pt.views - minViews) / (maxViews - minViews || 1);
    const y = height - padBottom - normalized * (height - padTop - padBottom);
    return {x, y, ...pt};
  });

  // Smooth cubic bezier line
  const linePath = coords.reduce((acc, pt, i, arr) => {
    if (i === 0) return `M ${pt.x} ${pt.y}`;
    const prev = arr[i - 1];
    const cpX = (prev.x + pt.x) / 2;
    return `${acc} C ${cpX} ${prev.y}, ${cpX} ${pt.y}, ${pt.x} ${pt.y}`;
  }, '');

  const areaPath = `${linePath} L ${coords[coords.length - 1].x} ${height - padBottom} L ${coords[0].x} ${height - padBottom} Z`;

  const safeIndex = Math.min(hoveredIndex, coords.length - 1);
  const activePoint = coords[safeIndex];

  // Retention curve path
  const retW = 300;
  const retH = 104;
  const retCoords = dataset.retentionCurve.map((val, idx, arr) => {
    const x = 10 + (idx / (arr.length - 1)) * (retW - 20);
    const y = retH - 14 - ((val - 40) / 65) * (retH - 26);
    return {x, y, val};
  });
  const retLine = retCoords.reduce((acc, pt, i, arr) => {
    if (i === 0) return `M ${pt.x} ${pt.y}`;
    const prev = arr[i - 1];
    const cpX = (prev.x + pt.x) / 2;
    return `${acc} C ${cpX} ${prev.y}, ${cpX} ${pt.y}, ${pt.x} ${pt.y}`;
  }, '');
  const retArea = `${retLine} L ${retCoords[retCoords.length - 1].x} ${retH - 10} L ${retCoords[0].x} ${retH - 10} Z`;

  return (
    <motion.div
      initial={prefersReducedMotion ? false : {opacity: 0, y: 28}}
      animate={{opacity: 1, y: 0}}
      transition={{duration: 0.8, delay: 0.22, ease: [0.16, 1, 0.3, 1]}}
      className="relative mx-auto w-full max-w-[1100px] rounded-xl sm:rounded-2xl bg-[#05123D]/92 border border-[#BFE8FF]/22 shadow-[0_32px_90px_-16px_rgba(3,11,44,0.75)] backdrop-blur-xl overflow-hidden text-left"
    >
      {/* Top hairline glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#BFE8FF]/65 to-transparent"
      />

      {/* Dashboard Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 sm:px-7 py-4 border-b border-white/10 bg-[#040D31]/75">
        <div className="flex items-center gap-3 min-w-0">
          <BrandMark className="w-5 h-5 text-[#BFE8FF] shrink-0" />
          <span className="font-display font-medium text-[14px] text-white tracking-tight truncate">
            Galaxy Media Studio Analytics
          </span>
          <span aria-hidden="true" className="hidden sm:inline text-white/25">
            /
          </span>
          <span className="hidden sm:inline text-[12px] text-[#BFE8FF]/70 whitespace-nowrap">
            Illustrative sample data
          </span>
        </div>

        {/* Interactive View Tabs + Timeframe Selector */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <div
            role="tablist"
            aria-label="Dashboard view"
            className="inline-flex items-center p-0.5 rounded-lg bg-white/[0.06] border border-white/10"
          >
            {(
              [
                {id: 'overview', label: 'Portfolio'},
                {id: 'retention', label: 'Retention'},
                {id: 'timeline', label: 'Publishing'},
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={activeTab === tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 text-[12px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === tab.id
                    ? 'bg-[#1769F4] text-white'
                    : 'text-white/65 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div
            role="group"
            aria-label="Sample timeframe"
            className="inline-flex items-center p-0.5 rounded-lg bg-white/[0.06] border border-white/10"
          >
            {(['30D', '90D', '12M'] as const).map((tf) => (
              <button
                key={tf}
                type="button"
                onClick={() => setTimeframe(tf)}
                className={`px-2.5 py-1.5 text-[11.5px] font-mono tabular-nums rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  timeframe === tf
                    ? 'bg-white text-[#030B2C] font-medium'
                    : 'text-white/65 hover:text-white'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content Body */}
      <div className="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-white/10">
        {/* Left Primary Performance Panel (8 cols) */}
        <div className="lg:col-span-8 p-5 sm:p-7">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-5">
            <div>
              <p className="text-[12px] text-[#BFE8FF]/75 mb-1">
                Sample Portfolio Views · {dataset.rangeLabel}
              </p>
              <div className="flex items-baseline gap-3">
                <span className="font-display font-semibold text-[32px] sm:text-[40px] leading-none tracking-[-0.03em] text-white tabular-nums">
                  {dataset.totalViews}
                </span>
                <span className="font-mono text-[13px] font-medium text-[#E7FF4B] tabular-nums">
                  {dataset.viewsDelta} sample trend
                </span>
              </div>
            </div>

            <div className="flex items-center gap-5 text-[12px] text-white/75 tabular-nums">
              <div>
                <span className="block text-white/45 text-[11px]">Selected period</span>
                <span className="font-mono text-white font-medium">
                  {activePoint.label} · {formatCompactNumber(activePoint.views)} views
                </span>
              </div>
              <div className="hidden sm:block">
                <span className="block text-white/45 text-[11px]">Avg retention</span>
                <span className="font-mono text-[#BFE8FF] font-medium">
                  {activePoint.retention}%
                </span>
              </div>
            </div>
          </div>

          {/* Interactive SVG Performance Graph */}
          <div className="relative w-full">
            <svg
              viewBox={`0 0 ${width} ${height}`}
              className="w-full h-auto overflow-visible select-none"
              role="img"
              aria-label={`Illustrative sample content performance chart for ${dataset.rangeLabel}`}
            >
              <defs>
                <linearGradient id="gmChartFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#4398FF" stopOpacity="0.42" />
                  <stop offset="65%" stopColor="#1769F4" stopOpacity="0.14" />
                  <stop offset="100%" stopColor="#05123D" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="gmChartStroke" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#4398FF" />
                  <stop offset="65%" stopColor="#BFE8FF" />
                  <stop offset="100%" stopColor="#E7FF4B" />
                </linearGradient>
              </defs>

              {/* Horizontal baseline grid */}
              {[0.2, 0.5, 0.8].map((ratio) => {
                const y = padTop + ratio * (height - padTop - padBottom);
                return (
                  <line
                    key={ratio}
                    x1={padX}
                    x2={width - padX}
                    y1={y}
                    y2={y}
                    stroke="rgba(191, 232, 255, 0.1)"
                    strokeDasharray="3 5"
                  />
                );
              })}

              {/* Area fill */}
              <motion.path
                key={`area-${timeframe}`}
                d={areaPath}
                fill="url(#gmChartFill)"
                initial={prefersReducedMotion ? false : {opacity: 0}}
                animate={{opacity: 1}}
                transition={{duration: 0.6}}
              />

              {/* Performance line */}
              <motion.path
                key={`line-${timeframe}`}
                d={linePath}
                fill="none"
                stroke="url(#gmChartStroke)"
                strokeWidth="2.4"
                strokeLinecap="round"
                initial={prefersReducedMotion ? false : {pathLength: 0}}
                animate={{pathLength: 1}}
                transition={{duration: 0.9, ease: [0.16, 1, 0.3, 1]}}
              />

              {/* Active vertical guide */}
              <line
                x1={activePoint.x}
                x2={activePoint.x}
                y1={padTop}
                y2={height - padBottom}
                stroke="rgba(231, 255, 75, 0.35)"
                strokeWidth="1"
                strokeDasharray="3 3"
              />

              {/* Interactive nodes */}
              {coords.map((pt, idx) => {
                const isSelected = idx === safeIndex;
                return (
                  <g key={pt.label}>
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isSelected ? 5.5 : 3}
                      fill={isSelected ? '#E7FF4B' : '#4398FF'}
                      stroke="#05123D"
                      strokeWidth={isSelected ? 2 : 1.5}
                      className="transition-all duration-150"
                    />
                    {isSelected && (
                      <circle
                        cx={pt.x}
                        cy={pt.y}
                        r="11"
                        fill="#E7FF4B"
                        fillOpacity="0.16"
                      />
                    )}
                    {/* X-axis label */}
                    <text
                      x={pt.x}
                      y={height - 10}
                      textAnchor="middle"
                      className="fill-white/50 text-[10.5px] font-mono"
                    >
                      {pt.label}
                    </text>
                    {/* Wide transparent hit target for hover & click */}
                    <rect
                      x={pt.x - 36}
                      y={0}
                      width="72"
                      height={height}
                      fill="transparent"
                      className="cursor-pointer"
                      onMouseEnter={() => setHoveredIndex(idx)}
                      onClick={() => setHoveredIndex(idx)}
                    />
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Clean Metric Strip beneath chart */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-5 mt-3 border-t border-white/10">
            <div>
              <p className="text-[11.5px] text-white/55 mb-1">Avg. Retention</p>
              <p className="font-display font-semibold text-[19px] text-white tabular-nums">
                {dataset.avgRetention}
              </p>
            </div>
            <div>
              <p className="text-[11.5px] text-white/55 mb-1">Sample CTR</p>
              <p className="font-display font-semibold text-[19px] text-white tabular-nums">
                {dataset.ctr}
              </p>
            </div>
            <div>
              <p className="text-[11.5px] text-white/55 mb-1">Watch Hours</p>
              <p className="font-display font-semibold text-[19px] text-white tabular-nums">
                {dataset.watchHours}
              </p>
            </div>
            <div>
              <p className="text-[11.5px] text-white/55 mb-1">Publishing Cadence</p>
              <p className="font-display font-semibold text-[19px] text-[#BFE8FF] tabular-nums">
                {dataset.episodesShipped}
              </p>
            </div>
          </div>
        </div>

        {/* Right Side Panel (4 cols): Switches emphasis based on tab, always showing rich media data */}
        <div className="lg:col-span-4 p-5 sm:p-6 bg-[#07184B]/55 flex flex-col justify-between gap-6">
          {/* Audience Retention Curve Module */}
          <div
            className={`transition-opacity duration-200 ${
              activeTab === 'timeline' ? 'opacity-65' : 'opacity-100'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-[13px] font-medium text-white">
                Audience Retention Curve
              </h3>
              <span className="font-mono text-[11px] text-[#BFE8FF]/80 tabular-nums">
                Hook 88%
              </span>
            </div>
            <p className="text-[12px] text-white/55 mb-3">
              Illustrative retention curve across long-form episodes.
            </p>
            <div className="rounded-lg bg-[#040F34]/80 border border-white/10 p-3">
              <svg
                viewBox={`0 0 ${retW} ${retH}`}
                className="w-full h-auto"
                role="img"
                aria-label="Sample audience retention curve"
              >
                <defs>
                  <linearGradient id="gmRetFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#1769F4" stopOpacity="0.45" />
                    <stop offset="100%" stopColor="#1769F4" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <path d={retArea} fill="url(#gmRetFill)" />
                <path
                  d={retLine}
                  fill="none"
                  stroke="#BFE8FF"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
                <text x="10" y={retH - 1} className="fill-white/40 text-[9.5px] font-mono">
                  0:00
                </text>
                <text
                  x={retW / 2}
                  y={retH - 1}
                  textAnchor="middle"
                  className="fill-white/40 text-[9.5px] font-mono"
                >
                  Mid-Roll
                </text>
                <text
                  x={retW - 10}
                  y={retH - 1}
                  textAnchor="end"
                  className="fill-white/40 text-[9.5px] font-mono"
                >
                  Outro
                </text>
              </svg>
            </div>
          </div>

          {/* Content Publishing Timeline */}
          <div
            className={`transition-opacity duration-200 ${
              activeTab === 'retention' ? 'opacity-65' : 'opacity-100'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[13px] font-medium text-white">
                Publishing Timeline
              </h3>
              <span className="text-[11px] text-white/50">Sample slate</span>
            </div>

            <div className="space-y-3.5">
              {PUBLISHING_TIMELINE_SAMPLE.map((item) => (
                <div key={item.code} className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2 text-[12px]">
                    <span className="text-white/90 font-medium truncate">
                      <span className="font-mono text-[#4398FF] mr-1.5">{item.code}</span>
                      {item.title}
                    </span>
                    <span className="text-[11px] text-white/50 whitespace-nowrap shrink-0">
                      {item.window}
                    </span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-[#1769F4] to-[#BFE8FF]"
                      style={{width: `${item.progress}%`}}
                    />
                  </div>
                  <p className="text-[11px] text-white/45">{item.stage}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Subtle footer note clarifying illustrative data */}
      <div className="px-5 sm:px-7 py-2.5 bg-[#030A26]/90 border-t border-white/[0.07] flex flex-wrap items-center justify-between gap-2 text-[11.5px] text-white/45">
        <span>
          Interface preview — all charts and figures above represent illustrative sample data.
        </span>
        <span className="font-mono text-white/55">Galaxy Media Production OS</span>
      </div>
    </motion.div>
  );
}
