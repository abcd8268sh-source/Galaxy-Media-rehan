import {useEffect, useMemo, useState} from 'react';
import {
  Clock,
  Database,
  Download,
  ExternalLink,
  Globe,
  Loader2,
  MessageSquare,
  Monitor,
  Search,
  ShieldAlert,
  Trash2,
  Users,
  Wifi,
  X,
} from 'lucide-react';
import {AnimatePresence, motion, useReducedMotion} from 'motion/react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  type Timestamp,
} from 'firebase/firestore';
import {
  ADMIN_EMAIL,
  useFirebase,
  type UserProfileRecord,
  type UserSessionRecord,
} from '../context/FirebaseContext';
import {db} from '../lib/firebase';
import {handleFirestoreError, OperationType} from '../lib/firestoreError';

interface AdminChatRecord {
  id: string;
  userId: string;
  role: 'user' | 'model';
  content: string;
  modelUsed: string;
  createdAt?: Timestamp;
}

interface AdminDashboardModalProps {
  open: boolean;
  onClose: () => void;
}

const CONSOLE_DB_URL =
  'https://console.firebase.google.com/project/gen-lang-client-0843066663/firestore/databases/ai-studio-galaxymedia-614eb401-f88d-4261-b94b-a2c96cfb33ce/data';

function formatTs(ts?: {toDate?: () => Date}): string {
  if (!ts || typeof ts.toDate !== 'function') return 'Just now';
  try {
    return ts.toDate().toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return 'Just now';
  }
}

function escapeCsv(val: string | undefined): string {
  const safe = (val ?? '').replace(/"/g, '""');
  return `"${safe}"`;
}

export function AdminDashboardModal({open, onClose}: AdminDashboardModalProps) {
  const {authReady, isAdmin, user, signingIn, authError, signInWithGoogle} = useFirebase();
  const prefersReducedMotion = useReducedMotion();

  const [allUsers, setAllUsers] = useState<UserProfileRecord[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUid, setSelectedUid] = useState<string | null>(null);
  const [detailTab, setDetailTab] = useState<'sessions' | 'chats'>('sessions');

  const [userSessions, setUserSessions] = useState<UserSessionRecord[]>([]);
  const [userChats, setUserChats] = useState<AdminChatRecord[]>([]);
  const [loadingDetails, setLoadingDetails] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, onClose]);

  // Real-time listener on /users ONLY when modal is open and user is verified admin
  useEffect(() => {
    if (!open || !authReady || !isAdmin) {
      setAllUsers([]);
      return;
    }

    setLoadingUsers(true);
    const unsub = onSnapshot(
      collection(db, 'users'),
      (snapshot) => {
        const list = snapshot.docs.map((d) => d.data() as UserProfileRecord);
        list.sort((a, b) => {
          const tA = a.updatedAt?.toMillis?.() ?? 0;
          const tB = b.updatedAt?.toMillis?.() ?? 0;
          return tB - tA;
        });
        setAllUsers(list);
        setLoadingUsers(false);
        setSelectedUid((prev) => {
          if (prev && list.some((u) => u.uid === prev)) return prev;
          return list[0]?.uid ?? null;
        });
      },
      (err) => {
        setLoadingUsers(false);
        handleFirestoreError(err, OperationType.LIST, 'users');
      },
    );

    return () => unsub();
  }, [open, authReady, isAdmin]);

  // Real-time listeners for selected user's sessions & chatMessages
  useEffect(() => {
    if (!open || !authReady || !isAdmin || !selectedUid) {
      setUserSessions([]);
      setUserChats([]);
      return;
    }

    setLoadingDetails(true);
    const sessionsPath = `users/${selectedUid}/sessions`;
    const chatsPath = `users/${selectedUid}/chatMessages`;

    const unsubSessions = onSnapshot(
      collection(db, 'users', selectedUid, 'sessions'),
      (snapshot) => {
        const list: UserSessionRecord[] = snapshot.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<UserSessionRecord, 'id'>),
        }));
        list.sort((a, b) => (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0));
        setUserSessions(list);
        setLoadingDetails(false);
      },
      (err) => {
        setLoadingDetails(false);
        handleFirestoreError(err, OperationType.LIST, sessionsPath);
      },
    );

    const unsubChats = onSnapshot(
      collection(db, 'users', selectedUid, 'chatMessages'),
      (snapshot) => {
        const list: AdminChatRecord[] = snapshot.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<AdminChatRecord, 'id'>),
        }));
        list.sort((a, b) => (a.createdAt?.toMillis?.() ?? 0) - (b.createdAt?.toMillis?.() ?? 0));
        setUserChats(list);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, chatsPath);
      },
    );

    return () => {
      unsubSessions();
      unsubChats();
    };
  }, [open, authReady, isAdmin, selectedUid]);

  const filteredUsers = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return allUsers;
    return allUsers.filter(
      (u) =>
        u.displayName.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.lastIpAddress.toLowerCase().includes(q) ||
        u.lastTimezone.toLowerCase().includes(q),
    );
  }, [allUsers, searchTerm]);

  const selectedUser = allUsers.find((u) => u.uid === selectedUid) ?? null;

  const handleExportCsv = () => {
    const headers = [
      'UID',
      'Display Name',
      'Email',
      'Last IP Address',
      'Network Type',
      'Timezone',
      'Language',
      'Screen Resolution',
      'User Agent',
      'Last Active',
    ];
    const rows = allUsers.map((u) =>
      [
        u.uid,
        u.displayName,
        u.email,
        u.lastIpAddress,
        u.lastNetworkType,
        u.lastTimezone,
        u.lastLanguage,
        u.lastScreenResolution,
        u.lastUserAgent,
        u.updatedAt?.toDate?.()?.toISOString?.() ?? '',
      ]
        .map(escapeCsv)
        .join(','),
    );
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], {type: 'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `galaxy-media-users-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDeleteSession = async (uid: string, sessionId: string) => {
    const path = `users/${uid}/sessions/${sessionId}`;
    try {
      await deleteDoc(doc(db, 'users', uid, 'sessions', sessionId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  const handleDeleteChatMessage = async (uid: string, messageId: string) => {
    const path = `users/${uid}/chatMessages/${messageId}`;
    try {
      await deleteDoc(doc(db, 'users', uid, 'chatMessages', messageId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={prefersReducedMotion ? false : {opacity: 0}}
          animate={{opacity: 1}}
          exit={prefersReducedMotion ? undefined : {opacity: 0}}
          transition={{duration: 0.2}}
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-labelledby="admin-dashboard-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#030B2C]/82 backdrop-blur-sm"
        >
          <motion.div
            initial={prefersReducedMotion ? false : {opacity: 0, y: 18, scale: 0.98}}
            animate={{opacity: 1, y: 0, scale: 1}}
            exit={prefersReducedMotion ? undefined : {opacity: 0, y: 10, scale: 0.98}}
            transition={{duration: 0.24, ease: [0.16, 1, 0.3, 1]}}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[1160px] h-[88vh] rounded-2xl overflow-hidden bg-[#05123D] text-white border border-[#BFE8FF]/22 shadow-[0_36px_100px_rgba(3,11,44,0.82)] flex flex-col"
          >
            {/* Header Bar */}
            <div className="px-5 sm:px-7 py-4 bg-[#040D31] border-b border-white/10 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-lg bg-[#1769F4]/25 border border-[#4398FF]/40 flex items-center justify-center shrink-0">
                  <Database className="w-4 h-4 text-[#BFE8FF]" />
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#BFE8FF]/75">
                    Firestore Admin Console
                  </p>
                  <h2
                    id="admin-dashboard-title"
                    className="font-display font-medium text-[18px] text-white tracking-[-0.02em] truncate"
                  >
                    Galaxy Media User Database
                  </h2>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                {isAdmin && allUsers.length > 0 && (
                  <button
                    type="button"
                    onClick={handleExportCsv}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-[12.5px] font-medium text-white bg-white/[0.07] hover:bg-white/[0.14] border border-white/15 rounded-md transition-colors whitespace-nowrap"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export CSV</span>
                  </button>
                )}

                <a
                  href={CONSOLE_DB_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-[12.5px] font-medium text-[#BFE8FF] hover:text-white border border-white/15 hover:border-white/35 rounded-md transition-colors whitespace-nowrap"
                >
                  <span>Firebase Console</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                <button
                  type="button"
                  onClick={onClose}
                  aria-label="Close admin database dashboard"
                  className="inline-flex items-center justify-center w-9 h-9 rounded-lg border border-white/15 text-white/75 hover:text-white hover:border-white/35 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Body */}
            {!isAdmin ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center max-w-md mx-auto space-y-4">
                <ShieldAlert className="w-9 h-9 text-[#E7FF4B]" />
                <h3 className="font-display text-xl font-medium text-white">
                  Admin Access Required
                </h3>
                <p className="text-[14.5px] leading-relaxed text-white/70">
                  This dashboard is restricted by Firestore security rules to the verified admin
                  account (<span className="font-mono text-[#BFE8FF]">{ADMIN_EMAIL}</span>).
                </p>
                {authError && (
                  <div className="w-full text-[13px] text-rose-200 bg-rose-500/15 border border-rose-400/35 rounded-lg px-3.5 py-2.5 space-y-2 text-left">
                    <p className="leading-relaxed">{authError.message}</p>
                    {authError.actionUrl && authError.actionLabel && (
                      <a
                        href={authError.actionUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-[#E7FF4B] hover:underline"
                      >
                        <span>{authError.actionLabel}</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                )}
                {!user && (
                  <button
                    type="button"
                    disabled={signingIn}
                    onClick={() => void signInWithGoogle()}
                    className="inline-flex items-center gap-2 px-5 py-2.5 text-[14px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] disabled:opacity-65 rounded-md transition-colors"
                  >
                    {signingIn ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Opening Google Sign-In...</span>
                      </>
                    ) : (
                      <span>Sign in with Google</span>
                    )}
                  </button>
                )}
              </div>
            ) : (
              <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-white/10">
                {/* Left Directory Pane (4 cols) */}
                <div className="lg:col-span-4 flex flex-col min-h-0 bg-[#040F34]/75">
                  <div className="p-4 border-b border-white/10 space-y-3">
                    <div className="flex items-center justify-between text-[12px] text-white/60">
                      <span className="inline-flex items-center gap-1.5 font-medium text-white/85">
                        <Users className="w-3.5 h-3.5 text-[#4398FF]" />
                        Registered Users
                      </span>
                      <span className="font-mono tabular-nums text-[#BFE8FF]">
                        {allUsers.length} total
                      </span>
                    </div>

                    <div className="relative">
                      <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Search name, email, IP..."
                        aria-label="Search registered users"
                        className="w-full rounded-lg bg-[#081A52] border border-white/12 pl-9 pr-3 py-2 text-[13px] text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-[#4398FF]"
                      />
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto divide-y divide-white/[0.07]">
                    {loadingUsers ? (
                      <div className="p-8 flex items-center justify-center gap-2 text-[13px] text-white/60">
                        <Loader2 className="w-4 h-4 animate-spin text-[#4398FF]" />
                        <span>Loading users...</span>
                      </div>
                    ) : filteredUsers.length === 0 ? (
                      <div className="p-6 text-[13px] text-white/55 text-center">
                        No matching user records found.
                      </div>
                    ) : (
                      filteredUsers.map((u) => {
                        const isSelected = u.uid === selectedUid;
                        return (
                          <button
                            key={u.uid}
                            type="button"
                            onClick={() => setSelectedUid(u.uid)}
                            className={`w-full text-left px-4 py-3.5 transition-colors flex items-start gap-3 ${
                              isSelected
                                ? 'bg-[#1769F4]/25'
                                : 'hover:bg-white/[0.04]'
                            }`}
                          >
                            {u.photoURL ? (
                              <img
                                src={u.photoURL}
                                alt={u.displayName}
                                referrerPolicy="no-referrer"
                                className="w-9 h-9 rounded-full border border-white/20 object-cover shrink-0 mt-0.5"
                              />
                            ) : (
                              <div className="w-9 h-9 rounded-full bg-[#0B328D] border border-white/20 flex items-center justify-center font-display text-[13px] font-semibold text-white shrink-0 mt-0.5">
                                {u.displayName[0]?.toUpperCase() || 'U'}
                              </div>
                            )}
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center justify-between gap-2">
                                <p className="text-[13.5px] font-medium text-white truncate">
                                  {u.displayName}
                                </p>
                                <span className="text-[11px] font-mono text-white/45 shrink-0 tabular-nums">
                                  {formatTs(u.updatedAt)}
                                </span>
                              </div>
                              <p className="text-[12px] text-white/60 truncate">{u.email}</p>
                              <p className="text-[11.5px] font-mono text-[#BFE8FF]/80 mt-1 tabular-nums truncate">
                                {u.lastIpAddress} · {u.lastNetworkType}
                              </p>
                            </div>
                          </button>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* Right Detail Workspace (8 cols) */}
                <div className="lg:col-span-8 flex flex-col min-h-0 overflow-hidden">
                  {!selectedUser ? (
                    <div className="flex-1 flex items-center justify-center text-[14px] text-white/55 p-8">
                      Select a user from the directory to inspect their Firestore diagnostics and
                      chat history.
                    </div>
                  ) : (
                    <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
                      {/* User Header & Snapshot Cards */}
                      <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-white/10">
                        <div className="min-w-0">
                          <h3 className="font-display font-medium text-[20px] text-white truncate">
                            {selectedUser.displayName}
                          </h3>
                          <p className="text-[13px] text-white/65 truncate">
                            {selectedUser.email} ·{' '}
                            <span className="font-mono text-white/45 text-[11.5px]">
                              UID: {selectedUser.uid}
                            </span>
                          </p>
                        </div>
                        <div className="text-right text-[12px] text-white/55 font-mono tabular-nums">
                          <span>Last seen: {formatTs(selectedUser.updatedAt)}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                        <div className="rounded-xl bg-[#07184B]/70 border border-white/10 p-3.5">
                          <p className="flex items-center gap-1.5 text-[11.5px] text-white/55 mb-1">
                            <Globe className="w-3.5 h-3.5 text-[#4398FF]" />
                            IP Address
                          </p>
                          <p className="font-mono text-[13.5px] text-white tabular-nums break-all">
                            {selectedUser.lastIpAddress}
                          </p>
                        </div>

                        <div className="rounded-xl bg-[#07184B]/70 border border-white/10 p-3.5">
                          <p className="flex items-center gap-1.5 text-[11.5px] text-white/55 mb-1">
                            <Wifi className="w-3.5 h-3.5 text-[#4398FF]" />
                            Network Type
                          </p>
                          <p className="font-mono text-[13px] text-white truncate">
                            {selectedUser.lastNetworkType}
                          </p>
                        </div>

                        <div className="rounded-xl bg-[#07184B]/70 border border-white/10 p-3.5">
                          <p className="flex items-center gap-1.5 text-[11.5px] text-white/55 mb-1">
                            <Clock className="w-3.5 h-3.5 text-[#4398FF]" />
                            Timezone / Lang
                          </p>
                          <p className="text-[13px] text-white truncate">
                            {selectedUser.lastTimezone} · {selectedUser.lastLanguage}
                          </p>
                        </div>

                        <div className="rounded-xl bg-[#07184B]/70 border border-white/10 p-3.5">
                          <p className="flex items-center gap-1.5 text-[11.5px] text-white/55 mb-1">
                            <Monitor className="w-3.5 h-3.5 text-[#4398FF]" />
                            Screen
                          </p>
                          <p className="font-mono text-[13px] text-white tabular-nums truncate">
                            {selectedUser.lastScreenResolution}
                          </p>
                        </div>
                      </div>

                      <div className="rounded-xl bg-[#040D31]/75 border border-white/10 px-4 py-3 text-[12px] text-white/60 break-words">
                        <span className="text-white/40 uppercase tracking-wider text-[10.5px] font-semibold mr-2">
                          User Agent
                        </span>
                        <span className="font-mono">{selectedUser.lastUserAgent}</span>
                      </div>

                      {/* Segmented Detail Tabs */}
                      <div>
                        <div className="flex items-center justify-between gap-4 mb-4">
                          <div
                            role="tablist"
                            aria-label="User records"
                            className="inline-flex items-center p-0.5 rounded-lg bg-white/[0.06] border border-white/10"
                          >
                            <button
                              type="button"
                              role="tab"
                              aria-selected={detailTab === 'sessions'}
                              onClick={() => setDetailTab('sessions')}
                              className={`px-3.5 py-1.5 text-[12.5px] font-medium rounded-md transition-colors whitespace-nowrap ${
                                detailTab === 'sessions'
                                  ? 'bg-[#1769F4] text-white'
                                  : 'text-white/65 hover:text-white'
                              }`}
                            >
                              Session Logs ({userSessions.length})
                            </button>
                            <button
                              type="button"
                              role="tab"
                              aria-selected={detailTab === 'chats'}
                              onClick={() => setDetailTab('chats')}
                              className={`px-3.5 py-1.5 text-[12.5px] font-medium rounded-md transition-colors whitespace-nowrap ${
                                detailTab === 'chats'
                                  ? 'bg-[#1769F4] text-white'
                                  : 'text-white/65 hover:text-white'
                              }`}
                            >
                              AI Chat History ({userChats.length})
                            </button>
                          </div>
                        </div>

                        {loadingDetails ? (
                          <div className="py-10 flex items-center justify-center gap-2 text-[13px] text-white/60">
                            <Loader2 className="w-4 h-4 animate-spin text-[#4398FF]" />
                            <span>Loading user records...</span>
                          </div>
                        ) : detailTab === 'sessions' ? (
                          userSessions.length === 0 ? (
                            <p className="text-[13.5px] text-white/55 py-6">
                              No session snapshots recorded for this user yet.
                            </p>
                          ) : (
                            <div className="divide-y divide-white/10 rounded-xl border border-white/10 bg-[#040D31]/65">
                              {userSessions.map((sess) => (
                                <div
                                  key={sess.id}
                                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-[12.5px]"
                                >
                                  <div className="space-y-1 min-w-0">
                                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                                      <span className="font-mono text-white font-medium tabular-nums">
                                        {sess.ipAddress}
                                      </span>
                                      <span className="text-white/30">·</span>
                                      <span className="text-[#BFE8FF]">{sess.networkType}</span>
                                      <span className="text-white/30">·</span>
                                      <span className="font-mono text-white/65 tabular-nums">
                                        {sess.downlinkMbps} / {sess.rttMs}
                                      </span>
                                    </div>
                                    <p className="text-white/55 truncate">
                                      {sess.platform} · {sess.screenResolution} · {sess.timezone} ·{' '}
                                      {sess.language}
                                    </p>
                                  </div>

                                  <div className="flex items-center gap-3 shrink-0">
                                    <span className="font-mono text-[11.5px] text-white/45 tabular-nums">
                                      {formatTs(sess.createdAt)}
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        void handleDeleteSession(selectedUser.uid, sess.id)
                                      }
                                      title="Delete session log"
                                      aria-label="Delete session log"
                                      className="p-1.5 rounded text-white/40 hover:text-rose-300 hover:bg-white/[0.06] transition-colors"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )
                        ) : userChats.length === 0 ? (
                          <p className="text-[13.5px] text-white/55 py-6">
                            No Gemini AI chat messages stored for this user yet.
                          </p>
                        ) : (
                          <div className="space-y-2.5">
                            {userChats.map((msg) => (
                              <div
                                key={msg.id}
                                className="rounded-xl bg-[#040D31]/70 border border-white/10 p-4 flex items-start justify-between gap-3"
                              >
                                <div className="space-y-1 min-w-0">
                                  <div className="flex items-center gap-2 text-[11.5px]">
                                    <MessageSquare className="w-3.5 h-3.5 text-[#4398FF]" />
                                    <span className="font-medium text-[#BFE8FF] capitalize">
                                      {msg.role === 'user' ? selectedUser.displayName : 'AI Agent'}
                                    </span>
                                    <span className="text-white/30">·</span>
                                    <span className="font-mono text-white/45">{msg.modelUsed}</span>
                                    <span className="text-white/30">·</span>
                                    <span className="font-mono text-white/45 tabular-nums">
                                      {formatTs(msg.createdAt)}
                                    </span>
                                  </div>
                                  <p className="text-[13.5px] text-white/86 leading-relaxed whitespace-pre-wrap break-words">
                                    {msg.content}
                                  </p>
                                </div>

                                <button
                                  type="button"
                                  onClick={() =>
                                    void handleDeleteChatMessage(selectedUser.uid, msg.id)
                                  }
                                  title="Delete message"
                                  aria-label="Delete message"
                                  className="p-1.5 rounded text-white/40 hover:text-rose-300 hover:bg-white/[0.06] transition-colors shrink-0"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
