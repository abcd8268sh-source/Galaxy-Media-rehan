import {ArrowUpRight, Clock, Film} from 'lucide-react';
import {motion, useReducedMotion, type Variants} from 'motion/react';
import {CONTENT_FORMATS} from '../data/siteContent';
import {Reveal} from './Reveal';
import {MagneticButton} from './MagneticButton';

interface FormatsSectionProps {
  onSelectFormatForContact: (formatTitle: string) => void;
}

const formatsGridVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.05,
    },
  },
};

const formatCardVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 30,
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.74,
      ease: [0.16, 1, 0.3, 1],
    },
  },
};

export function FormatsSection({onSelectFormatForContact}: FormatsSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="formats"
      className="bg-white py-24 sm:py-28 md:py-36 border-t border-[#101421]/[0.07]"
    >
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        {/* Editorial Intro Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-end pb-14 sm:pb-16 border-b border-[#101421]/10">
          <div className="lg:col-span-7">
            <Reveal>
              <p className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#1769F4] mb-3.5">
                Our Formats
              </p>
              <h2 className="font-display font-medium text-[#101421] tracking-[-0.03em] leading-[1.08] text-[clamp(2rem,4vw,3.35rem)] [text-wrap:balance]">
                We don&apos;t follow trends. We invent formats.
              </h2>
            </Reveal>
          </div>
          <div className="lg:col-span-5">
            <Reveal delay={0.08}>
              <p className="text-[16px] sm:text-[17px] leading-[1.65] text-[#101421]/68 max-w-[460px]">
                Original storytelling structures engineered from the ground up—designed to turn
                breakout ideas into signature YouTube formats audiences immediately recognize.
              </p>
            </Reveal>
          </div>
        </div>

        {/* 2x2 Popular Formats Editorial Grid */}
        <motion.div
          variants={prefersReducedMotion ? undefined : formatsGridVariants}
          initial={prefersReducedMotion ? false : 'hidden'}
          whileInView={prefersReducedMotion ? undefined : 'visible'}
          viewport={{once: true, amount: 0.1}}
          className="mt-12 sm:mt-16 grid grid-cols-1 md:grid-cols-2 gap-7 lg:gap-8"
        >
          {CONTENT_FORMATS.map((format) => (
            <motion.article
              key={format.id}
              variants={prefersReducedMotion ? undefined : formatCardVariants}
              className="group relative flex flex-col justify-between rounded-2xl bg-[#FAFBFD] border border-[#101421]/[0.09] hover:border-[#1769F4]/40 transition-colors duration-200 overflow-hidden"
            >
              {/* Top Royal-Blue Editorial Accent Header */}
              <div className="px-6 sm:px-8 pt-7 pb-6 border-b border-[#101421]/[0.07] bg-white">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                  <span className="font-mono text-[13px] font-medium text-[#1769F4] tabular-nums">
                    Format {format.number}
                  </span>
                  <div className="flex items-center gap-3.5 text-[12.5px] text-[#101421]/55">
                    <span className="inline-flex items-center gap-1.5">
                      <Film className="w-3.5 h-3.5 text-[#1769F4]" />
                      <span>{format.style}</span>
                    </span>
                    <span aria-hidden="true" className="text-[#101421]/25">
                      ·
                    </span>
                    <span className="inline-flex items-center gap-1 font-mono tabular-nums">
                      <Clock className="w-3.5 h-3.5 text-[#101421]/45" />
                      <span>{format.runtime}</span>
                    </span>
                  </div>
                </div>

                <h3 className="font-display font-medium text-[24px] sm:text-[28px] tracking-[-0.025em] text-[#030B2C] group-hover:text-[#0B328D] transition-colors">
                  {format.title}
                </h3>
                <p className="mt-1 text-[14px] font-medium text-[#1769F4]">{format.subtitle}</p>
              </div>

              {/* Body: Description, Title Blueprint, and Narrative Beats */}
              <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between space-y-6">
                <div className="space-y-5">
                  <p className="text-[15px] leading-[1.68] text-[#101421]/72">
                    {format.description}
                  </p>

                  {/* Title Packaging Blueprint */}
                  <div className="rounded-xl bg-[#030B2C] text-white px-4 py-3.5 border border-[#0B328D]/40">
                    <p className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-[#BFE8FF]/70 mb-1">
                      Packaging Blueprint
                    </p>
                    <p className="font-display text-[14.5px] text-white/95 tracking-[-0.01em]">
                      {format.exampleHeadline}
                    </p>
                  </div>

                  {/* 4-Beat Retention Arc */}
                  <div>
                    <p className="text-[11px] font-semibold uppercase tracking-[0.13em] text-[#101421]/45 mb-2.5">
                      Narrative Pacing Structure
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {format.beats.map((beat, idx) => (
                        <div
                          key={beat}
                          className="rounded-lg bg-white border border-[#101421]/[0.08] px-3 py-2.5"
                        >
                          <span className="block font-mono text-[10.5px] text-[#1769F4] tabular-nums">
                            0{idx + 1}
                          </span>
                          <span className="block text-[12px] font-medium text-[#101421]/85 leading-snug mt-0.5">
                            {beat}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Footer: Ideal Fit + Magnetic CTA */}
                <div className="pt-5 border-t border-[#101421]/[0.08] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <p className="text-[13px] leading-snug text-[#101421]/58 max-w-[330px]">
                    {format.bestFor}
                  </p>

                  <MagneticButton
                    type="button"
                    onClick={() => onSelectFormatForContact(format.title)}
                    proximity={38}
                    maxPull={6}
                    className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 text-[13.5px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md transition-colors whitespace-nowrap shrink-0"
                  >
                    <span>Build This Format</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </MagneticButton>
                </div>
              </div>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
