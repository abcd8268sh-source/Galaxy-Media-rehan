interface BrandMarkProps {
  className?: string;
}

export function BrandMark({className = 'w-6 h-6'}: BrandMarkProps) {
  return (
    <svg
      viewBox="0 0 28 28"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <rect
        x="2"
        y="2"
        width="24"
        height="24"
        rx="6"
        stroke="currentColor"
        strokeOpacity="0.32"
        strokeWidth="1.5"
      />
      <path
        d="M19.5 11.2C18.3 8.9 15.8 7.5 13 7.8C9.7 8.1 7.2 11 7.5 14.4C7.8 17.8 10.8 20.3 14.3 20C17.2 19.7 19.6 17.5 20.2 14.7H14.2"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="19.6" cy="11.2" r="1.6" fill="#E7FF4B" />
    </svg>
  );
}
