import {useEffect} from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Database,
  ExternalLink,
  Loader2,
  LogOut,
  ShieldCheck,
  X,
} from 'lucide-react';
import {AnimatePresence, motion, useReducedMotion} from 'motion/react';
import {useFirebase} from '../context/FirebaseContext';
import {MagneticButton} from './MagneticButton';

interface AccountPanelModalProps {
  open: boolean;
  onClose: () => void;
  onOpenAdmin: () => void;
}

export function AccountPanelModal({open, onClose, onOpenAdmin}: AccountPanelModalProps) {
  const {
    user,
    authReady,
    isAdmin,
    signingIn,
    profile,
    authError,
    signInWithGoogle,
    signOutUser,
  } = useFirebase();
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, onClose]);

  const displayName = profile?.displayName || user?.displayName || 'Galaxy Member';

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={prefersReducedMotion ? false : {opacity: 0}}
          animate={{opacity: 1}}
          exit={prefersReducedMotion ? undefined : {opacity: 0}}
          transition={{duration: 0.2}}
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-labelledby="account-panel-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#030B2C]/78 backdrop-blur-sm"
        >
          <motion.div
            initial={prefersReducedMotion ? false : {opacity: 0, y: 18, scale: 0.98}}
            animate={{opacity: 1, y: 0, scale: 1}}
            exit={prefersReducedMotion ? undefined : {opacity: 0, y: 10, scale: 0.98}}
            transition={{duration: 0.25, ease: [0.16, 1, 0.3, 1]}}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-[480px] max-h-[88vh] overflow-y-auto rounded-2xl bg-[#05123D] text-white border border-[#BFE8FF]/20 shadow-[0_32px_90px_rgba(3,11,44,0.75)]"
          >
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between gap-4 px-6 py-5 bg-[#040D31]/95 backdrop-blur-md border-b border-white/10">
              <div>
                <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-[#BFE8FF]/80">
                  Galaxy Media Account
                </p>
                <h2
                  id="account-panel-title"
                  className="font-display font-medium text-[20px] text-white tracking-[-0.02em] mt-0.5"
                >
                  {user ? 'Login Successful' : 'Sign in with Google'}
                </h2>
              </div>

              <button
                type="button"
                onClick={onClose}
                aria-label="Close account panel"
                className="inline-flex items-center justify-center w-9 h-9 rounded-lg border border-white/15 text-white/75 hover:text-white hover:border-white/35 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {authError && (
                <div
                  role="alert"
                  className="rounded-lg bg-rose-500/15 border border-rose-400/35 px-4 py-3.5 text-[13.5px] text-rose-200 space-y-2.5"
                >
                  <div className="flex items-start gap-2.5">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{authError.message}</span>
                  </div>
                  {authError.actionUrl && authError.actionLabel && (
                    <div className="pl-6">
                      <a
                        href={authError.actionUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-[12.5px] font-medium text-[#E7FF4B] hover:underline"
                      >
                        <span>{authError.actionLabel}</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  )}
                </div>
              )}

              {!authReady ? (
                <div className="py-10 flex items-center justify-center gap-3 text-white/70 text-[14px]">
                  <Loader2 className="w-4 h-4 animate-spin text-[#4398FF]" />
                  <span>Connecting...</span>
                </div>
              ) : !user ? (
                <div className="py-2 space-y-5">
                  <p className="text-[15px] leading-[1.65] text-white/78">
                    Sign in with Google to access your Galaxy Media account and keep your AI Agent
                    conversations saved across sessions.
                  </p>

                  <div className="rounded-xl bg-[#07184B]/80 border border-white/10 p-4 flex items-start gap-3 text-[13px] text-[#BFE8FF]/85">
                    <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-[#E7FF4B]" />
                    <span>
                      Protected by Google Authentication. Your account data stays securely linked to
                      your verified profile.
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <MagneticButton
                      type="button"
                      disabled={signingIn}
                      onClick={() => void signInWithGoogle()}
                      proximity={42}
                      maxPull={7}
                      className="inline-flex items-center justify-center gap-2.5 px-6 py-3 text-[14.5px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] disabled:opacity-65 rounded-md transition-colors whitespace-nowrap"
                    >
                      {signingIn ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Opening Google Sign-In...</span>
                        </>
                      ) : (
                        <span>Continue with Google</span>
                      )}
                    </MagneticButton>
                  </div>
                </div>
              ) : (
                <div className="py-3 flex flex-col items-center text-center space-y-6">
                  <div className="w-14 h-14 rounded-full bg-[#E7FF4B]/12 border border-[#E7FF4B]/40 flex items-center justify-center">
                    <CheckCircle2 className="w-7 h-7 text-[#E7FF4B]" />
                  </div>

                  <div className="space-y-1.5">
                    <h3 className="font-display font-medium text-[22px] text-white tracking-[-0.02em]">
                      Login Successful
                    </h3>
                    <p className="text-[14.5px] leading-relaxed text-white/70 max-w-sm">
                      Welcome back, <span className="text-white font-medium">{displayName}</span>.
                      You are now signed in to Galaxy Media.
                    </p>
                  </div>

                  {/* Compact signed-in user card */}
                  <div className="w-full rounded-xl bg-[#07184B]/70 border border-white/10 px-4 py-3.5 flex items-center gap-3.5 text-left">
                    {user.photoURL ? (
                      <img
                        src={user.photoURL}
                        alt={displayName}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-full border border-white/20 object-cover shrink-0"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-[#1769F4] flex items-center justify-center font-display font-semibold text-white shrink-0">
                        {(displayName || user.email || 'G')[0].toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="font-display font-medium text-[15px] text-white truncate">
                        {displayName}
                      </p>
                      <p className="text-[12.5px] text-white/60 truncate">{user.email}</p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="w-full flex flex-wrap items-center justify-center gap-2.5 pt-1">
                    <MagneticButton
                      type="button"
                      onClick={onClose}
                      proximity={36}
                      maxPull={6}
                      className="inline-flex items-center justify-center px-6 py-2.5 text-[14px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md transition-colors whitespace-nowrap"
                    >
                      Continue
                    </MagneticButton>

                    {isAdmin && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onOpenAdmin();
                        }}
                        className="inline-flex items-center gap-1.5 px-4 py-2.5 text-[13.5px] font-medium text-white bg-[#1769F4] hover:bg-[#4398FF] rounded-md transition-colors whitespace-nowrap"
                      >
                        <Database className="w-4 h-4" />
                        <span>Admin Database</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => void signOutUser()}
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 text-[13.5px] font-medium text-white/80 hover:text-white border border-white/20 hover:border-white/45 rounded-md transition-colors whitespace-nowrap"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

