import {PROCESS_STEPS} from '../data/siteContent';
import {Reveal} from './Reveal';

export function ProcessSection() {
  return (
    <section id="process" className="bg-white py-10 sm:py-14 md:py-16">
      <div className="mx-auto max-w-[1380px] px-3 sm:px-6">
        <div
          className="relative overflow-hidden rounded-[24px] sm:rounded-[32px] px-6 sm:px-10 md:px-14 lg:px-20 py-20 sm:py-24 md:py-28 text-white"
          style={{
            background:
              'radial-gradient(ellipse 85% 65% at 50% 0%, #1769F4 0%, #0B328D 42%, #051340 76%, #030B2C 100%)',
          }}
        >
          {/* Halftone dot shimmer along lower corners */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 bottom-0 h-56 halftone-dots-fine opacity-45"
            style={{
              maskImage: 'linear-gradient(0deg, rgba(0,0,0,0.8) 0%, transparent 100%)',
              WebkitMaskImage: 'linear-gradient(0deg, rgba(0,0,0,0.8) 0%, transparent 100%)',
            }}
          />

          {/* Subtle abstract orbital curves inspired by the reference's dark process panel */}
          <svg
            aria-hidden="true"
            viewBox="0 0 1280 600"
            fill="none"
            className="pointer-events-none absolute inset-0 w-full h-full opacity-25"
          >
            <circle cx="640" cy="40" r="460" stroke="#BFE8FF" strokeOpacity="0.35" strokeWidth="1" />
            <circle
              cx="640"
              cy="40"
              r="620"
              stroke="#BFE8FF"
              strokeOpacity="0.2"
              strokeWidth="1"
              strokeDasharray="4 8"
            />
          </svg>

          {/* Centered Header */}
          <div className="relative z-10 text-center max-w-[760px] mx-auto mb-16 sm:mb-20">
            <Reveal>
              <p className="text-[12px] font-semibold tracking-[0.16em] uppercase text-[#BFE8FF] mb-4">
                Our Process
              </p>
              <h2 className="font-display font-medium text-white tracking-[-0.03em] leading-[1.08] text-[clamp(2rem,4.2vw,3.4rem)] [text-wrap:balance]">
                From the first idea to the final upload.
              </h2>
              <p className="mt-4 text-[16.5px] sm:text-[18px] leading-[1.6] text-white/78">
                A complete creative system, built around the story.
              </p>
            </Reveal>
          </div>

          {/* Connected 4-Step Editorial Process Architecture */}
          <div className="relative z-10 max-w-[1060px] mx-auto">
            {/* Subtle center vertical spine on desktop */}
            <div
              aria-hidden="true"
              className="hidden md:block absolute left-1/2 top-4 bottom-4 -translate-x-1/2 w-px bg-gradient-to-b from-[#BFE8FF]/45 via-[#4398FF]/35 to-transparent"
            />

            <div className="space-y-6 md:space-y-8">
              {PROCESS_STEPS.map((step, index) => {
                const isRight = index % 2 === 1;
                return (
                  <Reveal key={step.number} delay={index * 0.08}>
                    <div
                      className={`relative grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-12 items-center`}
                    >
                      {/* Center node marker on desktop */}
                      <div
                        aria-hidden="true"
                        className="hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-[#061852] border border-[#BFE8FF]/55 items-center justify-center shadow-[0_0_24px_rgba(67,152,255,0.45)]"
                      >
                        <span className="font-mono text-[11px] font-medium text-[#E7FF4B] tabular-nums">
                          {step.number}
                        </span>
                      </div>

                      {/* Step Card positioned alternating left/right */}
                      <div
                        className={`${
                          isRight ? 'md:col-start-2 md:pl-4' : 'md:col-start-1 md:pr-4'
                        }`}
                      >
                        <div className="rounded-xl sm:rounded-2xl bg-[#07194E]/78 border border-white/14 hover:border-[#BFE8FF]/40 backdrop-blur-md p-6 sm:p-8 transition-colors duration-300">
                          <div className="flex items-center justify-between gap-4 mb-4">
                            <span className="font-mono text-[12px] tracking-[0.08em] uppercase text-[#BFE8FF]/85 tabular-nums">
                              {step.number} — {step.title}
                            </span>
                            <span className="text-[12px] text-white/45">{step.phaseLabel}</span>
                          </div>

                          <h3 className="font-display font-medium text-[22px] sm:text-[25px] tracking-[-0.02em] text-white">
                            {step.title}
                          </h3>

                          <p className="mt-2.5 text-[15px] leading-[1.65] text-white/76">
                            {step.description}
                          </p>

                          <div className="mt-5 pt-4 border-t border-white/10 flex flex-wrap items-center gap-x-2.5 gap-y-1.5 text-[12.5px] text-[#BFE8FF]/78">
                            {step.outputs.map((output, i) => (
                              <span key={output} className="inline-flex items-center gap-2.5">
                                {i > 0 && <span aria-hidden="true" className="text-white/30">·</span>}
                                <span>{output}</span>
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
