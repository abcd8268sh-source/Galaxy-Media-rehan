import {ArrowRight} from 'lucide-react';
import {motion, useReducedMotion} from 'motion/react';
import {PerformanceDashboard} from './PerformanceDashboard';
import {MagneticButton} from './MagneticButton';

export function HeroSection() {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="home"
      className="relative overflow-hidden pt-32 sm:pt-36 md:pt-40 pb-20 sm:pb-24 md:pb-28 text-white"
      style={{
        background:
          'linear-gradient(180deg, #030B2C 0%, #05164D 22%, #0B328D 48%, #1769F4 74%, #4398FF 88%, #BFE8FF 100%)',
      }}
    >
      {/* Subtle editorial grid texture in upper navy band */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 editorial-grid-dark opacity-70"
        style={{
          maskImage: 'linear-gradient(180deg, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.12) 60%, transparent 90%)',
          WebkitMaskImage:
            'linear-gradient(180deg, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.12) 60%, transparent 90%)',
        }}
      />

      {/* Soft ambient radial light bloom behind hero headline & dashboard */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-[34%] -translate-x-1/2 -translate-y-1/2 w-[980px] h-[520px] rounded-full bg-[#4398FF]/28 blur-[120px] animate-ambient-glow"
      />

      {/* Restrained abstract orbital arc geometry */}
      <svg
        aria-hidden="true"
        viewBox="0 0 1440 760"
        fill="none"
        className="pointer-events-none absolute inset-x-0 top-12 w-full h-auto opacity-30"
      >
        <ellipse
          cx="720"
          cy="480"
          rx="660"
          ry="290"
          stroke="url(#heroOrbitGrad)"
          strokeWidth="1"
        />
        <ellipse
          cx="720"
          cy="520"
          rx="520"
          ry="210"
          stroke="url(#heroOrbitGrad)"
          strokeWidth="0.75"
          strokeDasharray="4 8"
        />
        <defs>
          <linearGradient id="heroOrbitGrad" x1="120" y1="240" x2="1320" y2="680">
            <stop offset="0%" stopColor="#BFE8FF" stopOpacity="0" />
            <stop offset="50%" stopColor="#BFE8FF" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#BFE8FF" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>

      {/* Left decorative dotted halftone column — inspired by the reference video */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-0 top-[24%] bottom-0 w-36 sm:w-56 md:w-72 halftone-dots-light animate-dot-drift"
        style={{
          maskImage:
            'radial-gradient(ellipse 90% 75% at 0% 78%, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.5) 45%, transparent 80%)',
          WebkitMaskImage:
            'radial-gradient(ellipse 90% 75% at 0% 78%, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.5) 45%, transparent 80%)',
        }}
      />

      {/* Right decorative dotted halftone column — inspired by the reference video */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-0 top-[24%] bottom-0 w-36 sm:w-56 md:w-72 halftone-dots-light animate-dot-drift"
        style={{
          maskImage:
            'radial-gradient(ellipse 90% 75% at 100% 78%, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.5) 45%, transparent 80%)',
          WebkitMaskImage:
            'radial-gradient(ellipse 90% 75% at 100% 78%, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.5) 45%, transparent 80%)',
        }}
      />

      {/* Centered Hero Copy & CTAs */}
      <div className="relative z-10 mx-auto max-w-[1320px] px-5 sm:px-8 text-center">
        <motion.p
          initial={prefersReducedMotion ? false : {opacity: 0, y: 12}}
          animate={{opacity: 1, y: 0}}
          transition={{duration: 0.55, ease: [0.16, 1, 0.3, 1]}}
          className="text-[12px] sm:text-[12.5px] font-medium tracking-[0.16em] uppercase text-[#BFE8FF]/90 mb-5"
        >
          Independent Digital Media Company
        </motion.p>

        <motion.h1
          initial={prefersReducedMotion ? false : {opacity: 0, y: 18}}
          animate={{opacity: 1, y: 0}}
          transition={{duration: 0.7, delay: 0.06, ease: [0.16, 1, 0.3, 1]}}
          className="font-display font-medium text-white tracking-[-0.035em] leading-[1.05] text-[clamp(2.5rem,5.8vw,4.75rem)] max-w-[820px] mx-auto [text-wrap:balance]"
        >
          We Build Media
          <br className="hidden sm:inline" /> That Moves People.
        </motion.h1>

        <motion.p
          initial={prefersReducedMotion ? false : {opacity: 0, y: 16}}
          animate={{opacity: 1, y: 0}}
          transition={{duration: 0.7, delay: 0.12, ease: [0.16, 1, 0.3, 1]}}
          className="mt-6 max-w-[630px] mx-auto text-[16px] sm:text-[17.5px] leading-[1.6] text-white/84"
        >
          From the first idea to the final frame, Galaxy Media creates compelling content, builds
          distinctive YouTube brands, and turns creative vision into lasting audience connection.
        </motion.p>

        <motion.div
          initial={prefersReducedMotion ? false : {opacity: 0, y: 14}}
          animate={{opacity: 1, y: 0}}
          transition={{duration: 0.65, delay: 0.18, ease: [0.16, 1, 0.3, 1]}}
          className="mt-9 mb-14 sm:mb-16 md:mb-20 flex flex-wrap items-center justify-center gap-3.5"
        >
          <MagneticButton
            as="a"
            href="#work"
            proximity={48}
            maxPull={9}
            className="group inline-flex items-center justify-center gap-2 px-6 py-3 text-[14.5px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md shadow-[0_10px_30px_rgba(231,255,75,0.22)] transition-all duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
          >
            <span>Explore Our Work</span>
            <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-0.5" />
          </MagneticButton>
          <MagneticButton
            as="a"
            href="#contact"
            proximity={48}
            maxPull={8}
            className="inline-flex items-center justify-center px-6 py-3 text-[14.5px] font-medium text-white bg-white/[0.06] hover:bg-white/[0.14] border border-white/32 hover:border-white/60 rounded-md transition-all duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E7FF4B]"
          >
            Start a Project
          </MagneticButton>
        </motion.div>

        {/* Featured Content Performance Dashboard */}
        <PerformanceDashboard />
      </div>

      {/* Soft seamless transition fade into crisp white below */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-b from-transparent to-white"
      />
    </section>
  );
}
