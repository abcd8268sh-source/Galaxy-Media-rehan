import {useEffect, useState} from 'react';
import {Database, Menu, User, X} from 'lucide-react';
import {AnimatePresence, motion, useReducedMotion} from 'motion/react';
import {NAV_LINKS} from '../data/siteContent';
import {BrandMark} from './BrandMark';
import {MagneticButton} from './MagneticButton';
import {useFirebase} from '../context/FirebaseContext';

interface NavbarProps {
  onOpenAccount: () => void;
  onOpenAdmin: () => void;
  onOpenPayments: () => void;
}

export function Navbar({onOpenAccount, onOpenAdmin, onOpenPayments}: NavbarProps) {
  const {user, isAdmin} = useFirebase();
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState<string>('home');
  const [mobileOpen, setMobileOpen] = useState(false);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 28);

      const sectionIds = ['home', 'services', 'work', 'formats', 'process', 'about', 'contact'];
      const scrollPosition = window.scrollY + 180;

      for (let i = sectionIds.length - 1; i >= 0; i--) {
        const el = document.getElementById(sectionIds[i]);
        if (el && el.offsetTop <= scrollPosition) {
          setActiveSection(sectionIds[i]);
          break;
        }
      }
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, {passive: true});
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (!mobileOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMobileOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [mobileOpen]);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#030B2C]/92 backdrop-blur-md border-b border-white/10 shadow-[0_8px_30px_rgba(3,11,44,0.28)]'
          : 'bg-[#030B2C]/80 backdrop-blur-xs border-b border-white/[0.06]'
      }`}
    >
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8 h-16 md:h-[72px] flex items-center justify-between gap-6">
        {/* Left: Compact brand mark + wordmark */}
        <a
          href="#home"
          className="flex items-center gap-2.5 text-white whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E7FF4B] rounded"
          aria-label="Galaxy Media Home"
        >
          <BrandMark className="w-6 h-6 text-white" />
          <span className="font-display font-semibold text-[15px] tracking-[0.04em] uppercase">
            Galaxy Media
          </span>
        </a>

        {/* Center: Primary navigation */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-7 lg:gap-8"
        >
          {NAV_LINKS.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <a
                key={item.id}
                href={item.href}
                className={`relative text-[14px] font-medium whitespace-nowrap shrink-0 transition-colors duration-200 py-1 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E7FF4B] rounded ${
                  isActive ? 'text-white' : 'text-white/70 hover:text-white'
                }`}
              >
                {item.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-[2px] h-[1.5px] bg-[#4398FF]"
                  />
                )}
              </a>
            );
          })}
          <button
            type="button"
            onClick={onOpenPayments}
            className="relative text-[14px] font-medium whitespace-nowrap shrink-0 text-white/70 hover:text-[#E7FF4B] transition-colors duration-200 py-1 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E7FF4B] rounded cursor-pointer"
          >
            Payments
          </button>
        </nav>

        {/* Right: Account / Sign In (+ Admin DB for verified admin) + Let's Talk outlined CTA */}
        <div className="hidden md:flex items-center gap-4 shrink-0">
          {isAdmin && (
            <button
              type="button"
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1.5 text-[13px] font-medium text-[#E7FF4B] hover:text-white transition-colors duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E7FF4B] rounded"
            >
              <Database className="w-3.5 h-3.5" />
              <span>Admin DB</span>
            </button>
          )}
          <button
            type="button"
            onClick={onOpenAccount}
            className="inline-flex items-center gap-2 text-[13.5px] font-medium text-white/80 hover:text-white transition-colors duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E7FF4B] rounded"
          >
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'Account'}
                referrerPolicy="no-referrer"
                className="w-6 h-6 rounded-full border border-white/25 object-cover"
              />
            ) : (
              <User className="w-4 h-4 text-[#BFE8FF]" />
            )}
            <span>{user ? (user.displayName?.split(' ')[0] || 'Account') : 'Sign In'}</span>
          </button>
          <MagneticButton
            as="a"
            href="#contact"
            proximity={36}
            maxPull={6}
            className="inline-flex items-center justify-center px-4 py-2 text-[13.5px] font-medium text-white border border-white/25 hover:border-white/60 hover:bg-white/[0.06] rounded-md transition-all duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E7FF4B]"
          >
            Let&apos;s Talk
          </MagneticButton>
        </div>

        {/* Mobile menu button */}
        <button
          type="button"
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-expanded={mobileOpen}
          aria-controls="mobile-navigation"
          aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
          className="md:hidden inline-flex items-center justify-center w-11 h-11 text-white/90 hover:text-white rounded-md border border-white/15 hover:border-white/30 transition-colors"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.nav
            id="mobile-navigation"
            aria-label="Mobile navigation"
            initial={prefersReducedMotion ? false : {opacity: 0, y: -8}}
            animate={{opacity: 1, y: 0}}
            exit={prefersReducedMotion ? undefined : {opacity: 0, y: -8}}
            transition={{duration: 0.22, ease: [0.16, 1, 0.3, 1]}}
            className="md:hidden bg-[#030B2C] border-b border-white/12 px-5 pt-3 pb-6"
          >
            <div className="flex flex-col divide-y divide-white/[0.08]">
              {NAV_LINKS.map((item) => (
                <a
                  key={item.id}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className={`py-3.5 text-[15px] font-medium transition-colors ${
                    activeSection === item.id ? 'text-[#BFE8FF]' : 'text-white/80 hover:text-white'
                  }`}
                >
                  {item.label}
                </a>
              ))}
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onOpenPayments();
                }}
                className="py-3.5 text-left text-[15px] font-medium text-[#E7FF4B] hover:text-white transition-colors"
              >
                Payments Dashboard
              </button>
              {isAdmin && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    onOpenAdmin();
                  }}
                  className="py-3.5 text-left text-[15px] font-medium text-[#E7FF4B] hover:text-white transition-colors"
                >
                  Admin Database
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false);
                  onOpenAccount();
                }}
                className="py-3.5 text-left text-[15px] font-medium text-[#BFE8FF] hover:text-white transition-colors"
              >
                {user ? `Account (${user.displayName?.split(' ')[0] || 'Signed In'})` : 'Sign in with Google'}
              </button>
              <a
                href="#contact"
                onClick={() => setMobileOpen(false)}
                className="py-3.5 text-[15px] font-medium text-white/80 hover:text-white transition-colors"
              >
                Contact
              </a>
            </div>
            <div className="pt-4">
              <MagneticButton
                as="a"
                href="#contact"
                onClick={() => setMobileOpen(false)}
                className="flex items-center justify-center w-full py-3 px-4 text-[14px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md transition-colors"
              >
                Let&apos;s Talk
              </MagneticButton>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
