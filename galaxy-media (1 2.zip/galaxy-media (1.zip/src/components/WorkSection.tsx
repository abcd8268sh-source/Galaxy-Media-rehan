import {useEffect, useState} from 'react';
import {ArrowUpRight, ExternalLink, Lock, X} from 'lucide-react';
import {AnimatePresence, motion, useReducedMotion, type Variants} from 'motion/react';
import {PORTFOLIO_PROJECTS, type PortfolioProject} from '../data/siteContent';
import {Reveal} from './Reveal';
import {MagneticButton} from './MagneticButton';

const CATEGORIES = ['All', 'Documentary', 'Creator Series', 'Brand Channel'] as const;
type CategoryFilter = (typeof CATEGORIES)[number];

const portfolioGridVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.11,
      delayChildren: 0.05,
    },
  },
};

const portfolioItemVariants: Variants = {
  hidden: {
    opacity: 0,
    y: 34,
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.78,
      ease: [0.16, 1, 0.3, 1],
    },
  },
};

interface WorkSectionProps {
  onStartSimilarProject: (projectTitle: string) => void;
  onOpenCheckout: (projectId: string) => void;
  unlockedProjects: Record<string, boolean>;
}

export function WorkSection({
  onStartSimilarProject,
  onOpenCheckout,
  unlockedProjects,
}: WorkSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>('All');
  const [activeProject, setActiveProject] = useState<PortfolioProject | null>(null);
  const prefersReducedMotion = useReducedMotion();

  const filteredProjects =
    selectedCategory === 'All'
      ? PORTFOLIO_PROJECTS
      : PORTFOLIO_PROJECTS.filter((p) => p.category === selectedCategory);

  useEffect(() => {
    if (!activeProject) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setActiveProject(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeProject]);

  return (
    <section id="work" className="bg-[#FAFBFD] py-24 sm:py-28 md:py-36 border-t border-[#101421]/[0.07]">
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        {/* Header & Functional Category Filter */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 sm:mb-14">
          <Reveal>
            <p className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#1769F4] mb-3.5">
              Our Work
            </p>
            <h2 className="font-display font-medium text-[#101421] tracking-[-0.03em] leading-[1.08] text-[clamp(2rem,4vw,3.35rem)] [text-wrap:balance]">
              Stories we&apos;ve brought to life.
            </h2>
            <p className="mt-3 text-[14.5px] text-[#101421]/60 max-w-[540px]">
              Selected production formats below are editable sample project slots ready to link to
              live YouTube channels, videos, or case studies.
            </p>
          </Reveal>

          <Reveal delay={0.08}>
            <div
              role="tablist"
              aria-label="Filter projects by category"
              className="inline-flex flex-wrap items-center gap-1 p-1 rounded-lg bg-white border border-[#101421]/10"
            >
              {CATEGORIES.map((category) => {
                const isActive = selectedCategory === category;
                return (
                  <button
                    key={category}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-3.5 py-2 text-[13px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                      isActive
                        ? 'bg-[#030B2C] text-white'
                        : 'text-[#101421]/68 hover:text-[#101421]'
                    }`}
                  >
                    {category}
                  </button>
                );
              })}
            </div>
          </Reveal>
        </div>

        {/* Portfolio Grid with orchestrated Framer Motion staggered fade-in & slide-up */}
        <motion.div
          key={selectedCategory}
          variants={prefersReducedMotion ? undefined : portfolioGridVariants}
          initial={prefersReducedMotion ? false : 'hidden'}
          whileInView={prefersReducedMotion ? undefined : 'visible'}
          viewport={{once: true, amount: 0.1}}
          className="grid grid-cols-1 md:grid-cols-12 gap-7 lg:gap-8"
        >
          {filteredProjects.map((project, index) => {
            const isWideFeatured = selectedCategory === 'All' && index === 0;
            const colSpan =
              selectedCategory === 'All'
                ? isWideFeatured
                  ? 'md:col-span-7'
                  : index === 1
                    ? 'md:col-span-5'
                    : 'md:col-span-6'
                : 'md:col-span-6';

            const isLockedProject = !unlockedProjects[project.id];

            return (
              <motion.article
                key={project.id}
                variants={prefersReducedMotion ? undefined : portfolioItemVariants}
                className={`${colSpan} group h-full flex flex-col bg-white rounded-2xl overflow-hidden border border-[#101421]/[0.08] transition-colors duration-200 hover:border-[#1769F4]/35`}
              >
                {/* Clean Editorial Project Card (No Images) */}
                <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                      <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[12.5px] text-[#101421]/55">
                        <span className="text-[#1769F4] font-medium">{project.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{project.productionType}</span>
                      </div>
                      <span className="font-mono text-[12px] text-[#101421]/40 tabular-nums">
                        {String(index + 1).padStart(2, '0')}
                      </span>
                    </div>

                    <h3 className="font-display font-medium text-[22px] sm:text-[25px] tracking-[-0.025em] text-[#101421] group-hover:text-[#0B328D] transition-colors">
                      {project.title}
                    </h3>

                    <p className="mt-3 text-[14.5px] sm:text-[15px] leading-[1.65] text-[#101421]/66">
                      {project.description}
                    </p>
                  </div>

                  <div className="mt-7 pt-4 border-t border-[#101421]/[0.07] flex flex-wrap items-center justify-between gap-4">
                    <span className="text-[12.5px] text-[#101421]/50 truncate">
                      {project.scope.slice(0, 3).join(' · ')}
                    </span>

                    <div className="flex items-center gap-4 shrink-0">
                      {isLockedProject && (
                        <button
                          type="button"
                          onClick={() => onOpenCheckout(project.id)}
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-[12.5px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md transition-colors whitespace-nowrap cursor-pointer"
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>Unlock · $499</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setActiveProject(project)}
                        className="inline-flex items-center gap-1.5 text-[13.5px] font-semibold text-[#0B328D] hover:text-[#1769F4] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#1769F4] rounded cursor-pointer"
                      >
                        <span>View Project</span>
                        <ArrowUpRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </motion.div>
      </div>

      {/* Project Overview Modal */}
      <AnimatePresence>
        {activeProject && (
          <motion.div
            initial={prefersReducedMotion ? false : {opacity: 0}}
            animate={{opacity: 1}}
            exit={prefersReducedMotion ? undefined : {opacity: 0}}
            transition={{duration: 0.2}}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#030B2C]/75 backdrop-blur-sm"
            onClick={() => setActiveProject(null)}
            role="dialog"
            aria-modal="true"
            aria-labelledby="project-modal-title"
          >
            <motion.div
              initial={prefersReducedMotion ? false : {opacity: 0, y: 18, scale: 0.98}}
              animate={{opacity: 1, y: 0, scale: 1}}
              exit={prefersReducedMotion ? undefined : {opacity: 0, y: 10, scale: 0.98}}
              transition={{duration: 0.25, ease: [0.16, 1, 0.3, 1]}}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-[780px] max-h-[90vh] overflow-y-auto rounded-2xl bg-white shadow-2xl border border-[#101421]/10"
            >
              <button
                type="button"
                onClick={() => setActiveProject(null)}
                aria-label="Close project details"
                className="absolute top-4 right-4 z-10 inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#030B2C]/80 text-white hover:bg-[#030B2C] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="p-6 sm:p-8 pr-16">
                <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[12.5px] text-[#101421]/55 mb-2">
                  <span className="font-medium text-[#1769F4]">{activeProject.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeProject.productionType}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeProject.sampleNote}</span>
                </div>

                <h3
                  id="project-modal-title"
                  className="font-display font-medium text-[26px] sm:text-[30px] tracking-[-0.025em] text-[#101421]"
                >
                  {activeProject.title}
                </h3>

                <p className="mt-4 text-[15.5px] leading-[1.68] text-[#101421]/72">
                  {activeProject.overview}
                </p>

                <div className="mt-6 pt-5 border-t border-[#101421]/10">
                  <p className="text-[12px] font-semibold uppercase tracking-[0.12em] text-[#101421]/45 mb-2.5">
                    Production Scope
                  </p>
                  <p className="text-[14.5px] text-[#101421]/85">
                    {activeProject.scope.join('  ·  ')}
                  </p>
                </div>

                <div className="mt-7 flex flex-wrap items-center justify-between gap-4 pt-5 border-t border-[#101421]/10">
                  <a
                    href={activeProject.externalUrlPlaceholder}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 text-[14px] font-medium text-[#101421]/70 hover:text-[#1769F4] transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Connect YouTube / Case Study URL</span>
                  </a>

                  <MagneticButton
                    type="button"
                    proximity={42}
                    maxPull={7}
                    onClick={() => {
                      const title = activeProject.title;
                      setActiveProject(null);
                      onStartSimilarProject(title);
                    }}
                    className="inline-flex items-center gap-2 px-5 py-2.5 text-[14px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md transition-colors whitespace-nowrap"
                  >
                    <span>Start a Similar Project</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </MagneticButton>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
