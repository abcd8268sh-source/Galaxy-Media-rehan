import {Reveal} from './Reveal';

function DiscoverVisual() {
  // Abstract dotted discovery matrix — crisp electric blue aesthetic
  const cols = 15;
  const rows = 9;
  const dots: Array<{x: number; y: number; r: number; opacity: number; highlight: boolean}> = [];

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const dx = col - 7;
      const dy = row - 4;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const isHighlight = (row === 3 && col === 9) || (row === 5 && col === 5) || (row === 4 && col === 7);
      const opacity = Math.max(0.16, 0.92 - dist * 0.11);
      const r = isHighlight ? 3.2 : Math.max(1.25, 2.7 - dist * 0.19);
      dots.push({
        x: 24 + col * 22,
        y: 28 + row * 21,
        r,
        opacity,
        highlight: isHighlight,
      });
    }
  }

  return (
    <svg
      viewBox="0 0 360 220"
      className="w-full h-full"
      role="img"
      aria-label="Abstract dotted content discovery matrix"
    >
      {/* Subtle geometric targeting rings */}
      <circle cx="178" cy="112" r="78" stroke="rgba(191,232,255,0.22)" strokeWidth="1" fill="none" />
      <circle
        cx="178"
        cy="112"
        r="44"
        stroke="rgba(191,232,255,0.34)"
        strokeWidth="1"
        strokeDasharray="3 4"
        fill="none"
      />
      {/* Connecting vectors between highlighted discovery nodes */}
      <path
        d="M 134 133 L 178 112 L 222 91"
        stroke="#BFE8FF"
        strokeOpacity="0.6"
        strokeWidth="1.25"
        fill="none"
      />
      {dots.map((dot, idx) => (
        <circle
          key={idx}
          cx={dot.x}
          cy={dot.y}
          r={dot.r}
          fill={dot.highlight ? '#E7FF4B' : '#FFFFFF'}
          fillOpacity={dot.highlight ? 0.98 : dot.opacity}
        />
      ))}
    </svg>
  );
}

function CreateVisual() {
  // Layered video production timeline & frame architecture
  return (
    <svg
      viewBox="0 0 360 220"
      className="w-full h-full"
      role="img"
      aria-label="Abstract video production timeline and editorial frame"
    >
      {/* Clean 16:9 viewport frame */}
      <rect
        x="48"
        y="28"
        width="264"
        height="104"
        rx="8"
        fill="rgba(3,11,44,0.38)"
        stroke="rgba(191,232,255,0.38)"
        strokeWidth="1"
      />
      {/* Framing crop guides */}
      <path d="M 64 48 V 40 H 72" stroke="#BFE8FF" strokeWidth="1.5" fill="none" />
      <path d="M 296 48 V 40 H 288" stroke="#BFE8FF" strokeWidth="1.5" fill="none" />
      <path d="M 64 112 V 120 H 72" stroke="#BFE8FF" strokeWidth="1.5" fill="none" />
      <path d="M 296 112 V 120 H 288" stroke="#BFE8FF" strokeWidth="1.5" fill="none" />

      {/* Abstract story waveform inside frame */}
      <path
        d="M 88 86 Q 116 54 146 78 T 206 72 T 272 82"
        stroke="#BFE8FF"
        strokeWidth="2"
        fill="none"
        strokeLinecap="round"
      />
      <circle cx="146" cy="78" r="3.5" fill="#FFFFFF" />
      <circle cx="206" cy="72" r="4" fill="#E7FF4B" />

      {/* Multi-track editorial timeline bars */}
      <rect x="48" y="148" width="96" height="10" rx="3" fill="rgba(191,232,255,0.75)" />
      <rect x="152" y="148" width="128" height="10" rx="3" fill="rgba(255,255,255,0.42)" />
      <rect x="288" y="148" width="24" height="10" rx="3" fill="rgba(255,255,255,0.22)" />

      <rect x="48" y="166" width="54" height="10" rx="3" fill="rgba(255,255,255,0.28)" />
      <rect x="110" y="166" width="144" height="10" rx="3" fill="#4398FF" />
      <rect x="262" y="166" width="50" height="10" rx="3" fill="rgba(191,232,255,0.55)" />

      <rect x="48" y="184" width="174" height="8" rx="3" fill="rgba(255,255,255,0.22)" />
      <rect x="230" y="184" width="82" height="8" rx="3" fill="rgba(231,255,75,0.72)" />

      {/* Playhead vertical cursor */}
      <line x1="206" y1="22" x2="206" y2="198" stroke="#E7FF4B" strokeWidth="1.5" />
      <polygon points="200,22 212,22 206,30" fill="#E7FF4B" />
    </svg>
  );
}

function GrowVisual() {
  // Abstract rising performance curve & connected audience nodes
  const nodes = [
    {x: 44, y: 174},
    {x: 96, y: 158},
    {x: 146, y: 132},
    {x: 198, y: 112},
    {x: 252, y: 78},
    {x: 312, y: 44},
  ];

  return (
    <svg
      viewBox="0 0 360 220"
      className="w-full h-full"
      role="img"
      aria-label="Abstract rising audience growth curve and connected nodes"
    >
      <defs>
        <linearGradient id="growArea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#BFE8FF" stopOpacity="0.48" />
          <stop offset="100%" stopColor="#1769F4" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Subtle architectural baseline ticks */}
      {[56, 98, 140, 182].map((y) => (
        <line
          key={y}
          x1="34"
          x2="326"
          y1={y}
          y2={y}
          stroke="rgba(255,255,255,0.12)"
          strokeDasharray="2 5"
        />
      ))}

      {/* Area fill beneath curve */}
      <path
        d="M 44 174 C 70 166, 76 164, 96 158 C 122 150, 126 140, 146 132 C 174 121, 178 122, 198 112 C 228 97, 232 90, 252 78 C 280 61, 290 54, 312 44 L 312 192 L 44 192 Z"
        fill="url(#growArea)"
      />

      {/* Primary growth trajectory */}
      <path
        d="M 44 174 C 70 166, 76 164, 96 158 C 122 150, 126 140, 146 132 C 174 121, 178 122, 198 112 C 228 97, 232 90, 252 78 C 280 61, 290 54, 312 44"
        fill="none"
        stroke="#FFFFFF"
        strokeWidth="2.4"
        strokeLinecap="round"
      />

      {/* Secondary network connections */}
      <path
        d="M 96 158 L 154 92 L 252 78 M 198 112 L 266 136 L 312 44"
        fill="none"
        stroke="rgba(191,232,255,0.34)"
        strokeWidth="1"
        strokeDasharray="3 4"
      />
      <circle cx="154" cy="92" r="2.5" fill="#BFE8FF" fillOpacity="0.65" />
      <circle cx="266" cy="136" r="2.5" fill="#BFE8FF" fillOpacity="0.65" />

      {/* Trajectory nodes */}
      {nodes.map((node, i) => {
        const isLast = i === nodes.length - 1;
        return (
          <g key={i}>
            {isLast && <circle cx={node.x} cy={node.y} r="13" fill="#E7FF4B" fillOpacity="0.22" />}
            <circle
              cx={node.x}
              cy={node.y}
              r={isLast ? 5 : 3.5}
              fill={isLast ? '#E7FF4B' : '#FFFFFF'}
              stroke="#0B328D"
              strokeWidth="1.5"
            />
          </g>
        );
      })}
    </svg>
  );
}

const FEATURE_CARDS = [
  {
    id: 'discover',
    index: '01',
    title: 'Discover',
    description:
      'Uncover high-conviction video concepts, audience whitespace, and distinctive positioning before cameras ever roll.',
    visual: <DiscoverVisual />,
    gradient: 'linear-gradient(165deg, #061854 0%, #0E42B8 52%, #3C94FF 100%)',
  },
  {
    id: 'create',
    index: '02',
    title: 'Create',
    description:
      'Turn raw ideas into tightly paced stories through retention-minded scripts, purposeful editing, sound, and packaging.',
    visual: <CreateVisual />,
    gradient: 'linear-gradient(165deg, #071D63 0%, #1769F4 56%, #6AB7FF 100%)',
  },
  {
    id: 'grow',
    index: '03',
    title: 'Grow',
    description:
      'Build repeatable publishing systems that compound viewer trust, deepen watch sessions, and establish an enduring channel brand.',
    visual: <GrowVisual />,
    gradient: 'linear-gradient(165deg, #051649 0%, #104BC7 52%, #4BA0FF 100%)',
  },
];

export function FeatureCardsSection() {
  return (
    <section className="bg-white pb-24 sm:pb-28 md:pb-36">
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        <Reveal>
          <div className="max-w-[680px] mb-12 sm:mb-14">
            <p className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#1769F4] mb-3.5">
              Built for Momentum
            </p>
            <h2 className="font-display font-medium text-[#101421] tracking-[-0.03em] leading-[1.1] text-[clamp(1.85rem,3.4vw,2.9rem)] [text-wrap:balance]">
              Three disciplines working as one creative engine.
            </h2>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-7">
          {FEATURE_CARDS.map((card, index) => (
            <Reveal key={card.id} delay={index * 0.08} className="h-full">
              <article className="group h-full flex flex-col rounded-2xl overflow-hidden bg-[#FAFBFD] border border-[#101421]/[0.08] transition-transform duration-300 hover:-translate-y-1">
                {/* Vivid Electric Blue Abstract Visualization Window */}
                <div
                  className="relative aspect-[16/11] w-full overflow-hidden p-4"
                  style={{background: card.gradient}}
                >
                  {/* Subtle fine dotted halftone shimmer */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 halftone-dots-card opacity-30"
                    style={{
                      maskImage:
                        'linear-gradient(180deg, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.18) 70%, transparent 100%)',
                      WebkitMaskImage:
                        'linear-gradient(180deg, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.18) 70%, transparent 100%)',
                    }}
                  />
                  {/* Soft lower sky-blue ambient light */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute -bottom-10 inset-x-4 h-24 rounded-full bg-[#BFE8FF]/35 blur-2xl transition-opacity duration-300 group-hover:opacity-95 opacity-70"
                  />
                  <div className="relative z-10 w-full h-full transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.03]">
                    {card.visual}
                  </div>
                </div>

                {/* Editorial Card Copy */}
                <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between bg-white">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-display font-medium text-[22px] tracking-[-0.02em] text-[#101421]">
                        {card.title}
                      </h3>
                      <span className="font-mono text-[12px] text-[#1769F4] tabular-nums">
                        {card.index}
                      </span>
                    </div>
                    <p className="text-[15px] leading-[1.6] text-[#101421]/68">
                      {card.description}
                    </p>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
