import {Component, type ErrorInfo, type ReactNode} from 'react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {hasError: false, errorMessage: ''};
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {hasError: true, errorMessage: error.message || 'An unexpected error occurred.'};
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Application ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#030B2C] text-white flex items-center justify-center p-6">
          <div className="max-w-md w-full rounded-2xl bg-[#07184B] border border-white/15 p-8 space-y-4">
            <p className="text-[12px] font-semibold uppercase tracking-[0.14em] text-[#BFE8FF]">
              Galaxy Media
            </p>
            <h1 className="font-display text-2xl font-medium">Something interrupted the session.</h1>
            <p className="text-[14px] text-white/75 leading-relaxed break-words">
              {this.state.errorMessage.includes('Quota exceeded')
                ? 'Firestore daily free-tier quota was reached. Quota resets tomorrow.'
                : 'A runtime or database permission error occurred. You can reload to recover.'}
            </p>
            <button
              type="button"
              onClick={() => {
                this.setState({hasError: false, errorMessage: ''});
                window.location.reload();
              }}
              className="inline-flex items-center justify-center px-5 py-2.5 text-[14px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md transition-colors"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
