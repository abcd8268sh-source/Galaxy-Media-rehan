import {useEffect, useMemo, useState, type FormEvent} from 'react';
import {
  AlertCircle,
  ArrowLeft,
  ArrowUpRight,
  CheckCircle2,
  CreditCard,
  Layers,
  Lock,
  ShieldAlert,
  Tag,
  Unlock,
} from 'lucide-react';
import {motion, useReducedMotion} from 'motion/react';
import {PORTFOLIO_PROJECTS} from '../data/siteContent';
import {BrandMark} from './BrandMark';
import {MagneticButton} from './MagneticButton';

export type PaymentDashboardTab = 'card' | 'promo' | 'packages';

interface PaymentPackage {
  id: string;
  title: string;
  category: string;
  amountUsd: number;
  billingCycle: 'One-Time' | 'Monthly';
  summary: string;
  deliverables: string[];
}

const VALID_PROMO_CODE = 'ABDULREHANM';

const PORTFOLIO_UNLOCK_PACKAGES: PaymentPackage[] = PORTFOLIO_PROJECTS.map((project) => ({
  id: project.id,
  title: `${project.title} — Full Access`,
  category: `Our Work · ${project.category}`,
  amountUsd: 499,
  billingCycle: 'One-Time',
  summary: project.description,
  deliverables: [
    'Full project breakdown & documentation',
    ...project.scope.slice(0, 2),
  ],
}));

const SERVICE_PACKAGES: PaymentPackage[] = [
  {
    id: 'strategy-audit',
    title: 'Channel Strategy & Retention Audit Sprint',
    category: 'Content Strategy',
    amountUsd: 1250,
    billingCycle: 'One-Time',
    summary:
      'Deep-dive YouTube channel positioning audit, audience retention diagnostics, and a 90-day high-conviction topic slate.',
    deliverables: [
      'Audience & competitor positioning brief',
      'Retention drop-off analysis across recent uploads',
      '12 vetted video concepts with title/thumbnail direction',
    ],
  },
  {
    id: 'production-deposit',
    title: 'Flagship Video Production Kickoff Deposit',
    category: 'Video Production',
    amountUsd: 2500,
    billingCycle: 'One-Time',
    summary:
      'Reserve a dedicated Galaxy Media production slot covering research, script lock, editorial cut, motion graphics, and sound mix.',
    deliverables: [
      'End-to-end documentary or essay video edit',
      'Custom motion graphics & visual storytelling pass',
      'Master audio mix, color grade, and 3 thumbnail concepts',
    ],
  },
];

const PAYMENT_PACKAGES: PaymentPackage[] = [...PORTFOLIO_UNLOCK_PACKAGES, ...SERVICE_PACKAGES];

interface CheckoutPaymentTabProps {
  projectId: string;
  initialView?: PaymentDashboardTab;
  unlockedProjects: Record<string, boolean>;
  onUnlockAllWork: (extraPackageId?: string) => void;
  onResetLocks: () => void;
  onBack: () => void;
}

export function CheckoutPaymentTab({
  projectId,
  initialView = 'card',
  unlockedProjects,
  onUnlockAllWork,
  onResetLocks,
  onBack,
}: CheckoutPaymentTabProps) {
  const prefersReducedMotion = useReducedMotion();

  const [activeTab, setActiveTab] = useState<PaymentDashboardTab>(initialView);
  const [selectedPackageId, setSelectedPackageId] = useState<string>(
    PAYMENT_PACKAGES.some((p) => p.id === projectId) ? projectId : PORTFOLIO_PROJECTS[0].id,
  );

  // Promotional Code state
  const [promoInput, setPromoInput] = useState('');
  const [promoError, setPromoError] = useState<string | null>(null);
  const [promoApplied, setPromoApplied] = useState(false);

  // Card status feedback (no card numbers collected or saved)
  const [cardAttemptDeclined, setCardAttemptDeclined] = useState(false);

  useEffect(() => {
    setActiveTab(initialView);
  }, [initialView]);

  useEffect(() => {
    if (PAYMENT_PACKAGES.some((p) => p.id === projectId)) {
      setSelectedPackageId(projectId);
    }
  }, [projectId]);

  useEffect(() => {
    window.scrollTo({top: 0, behavior: 'instant' as ScrollBehavior});
  }, []);

  const selectedPackage = useMemo(
    () => PAYMENT_PACKAGES.find((p) => p.id === selectedPackageId) ?? PAYMENT_PACKAGES[0],
    [selectedPackageId],
  );

  const isSelectedUnlocked = Boolean(unlockedProjects[selectedPackage.id]);
  const unlockedWorkCount = PORTFOLIO_PROJECTS.filter((p) => unlockedProjects[p.id]).length;

  const handleSelectPackage = (pkgId: string, nextTab: PaymentDashboardTab = 'card') => {
    setSelectedPackageId(pkgId);
    setPromoError(null);
    setPromoApplied(false);
    setCardAttemptDeclined(false);
    setActiveTab(nextTab);
  };

  const handleRedeemPromo = (e: FormEvent) => {
    e.preventDefault();
    setPromoError(null);

    const normalized = promoInput.trim().toUpperCase();
    if (!normalized) {
      setPromoError('Please enter a promotional code.');
      return;
    }

    if (normalized !== VALID_PROMO_CODE) {
      setPromoApplied(false);
      setPromoError('Invalid promotional code. Please check the code and try again.');
      return;
    }

    setPromoApplied(true);
    onUnlockAllWork(selectedPackage.id);
  };

  return (
    <div className="min-h-screen bg-[#030B2C] text-white flex flex-col">
      {/* Top Dashboard Navigation Bar */}
      <header className="sticky top-0 z-30 bg-[#030B2C]/92 backdrop-blur-md border-b border-white/10">
        <div className="mx-auto max-w-[1240px] px-5 sm:px-8 h-16 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 text-[13.5px] font-medium text-white/80 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Galaxy Media</span>
          </button>

          <div className="flex items-center gap-2.5 text-white">
            <BrandMark className="w-5 h-5 text-white" />
            <span className="font-display font-semibold text-[13.5px] tracking-[0.06em] uppercase">
              Galaxy Media
            </span>
            <span className="text-white/30">·</span>
            <span className="text-[13px] font-medium text-[#BFE8FF]">Payments Dashboard</span>
          </div>

          <div className="hidden sm:inline-flex items-center gap-1.5 text-[12px] text-white/65">
            {isSelectedUnlocked ? (
              <>
                <Unlock className="w-3.5 h-3.5 text-[#E7FF4B]" />
                <span className="text-[#E7FF4B]">Access Unlocked</span>
              </>
            ) : (
              <>
                <Lock className="w-3.5 h-3.5 text-[#BFE8FF]" />
                <span>Access Portal</span>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 py-10 sm:py-14 px-5 sm:px-8">
        <div className="mx-auto max-w-[1200px] space-y-8">
          {/* Heading + Segmented Dashboard Tabs */}
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-6 border-b border-white/10">
            <div>
              <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-[#BFE8FF]/80">
                Billing &amp; Access Workspace
              </p>
              <h1 className="font-display font-medium text-[clamp(1.85rem,3.4vw,2.65rem)] tracking-[-0.03em] text-white mt-1 leading-tight">
                Galaxy Media Payments Dashboard
              </h1>
              <p className="mt-2 text-[14.5px] text-white/65 max-w-[600px]">
                Unlock blurred previews from Our Work via the Card Payment tab or redeem an
                authorized promotional code for instant access.
              </p>
            </div>

            <div
              role="tablist"
              aria-label="Payments dashboard tabs"
              className="inline-flex flex-wrap items-center gap-1.5 p-1.5 rounded-xl bg-[#05123D] border border-[#BFE8FF]/20 self-start lg:self-auto"
            >
              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'card'}
                onClick={() => setActiveTab('card')}
                className={`inline-flex items-center gap-2 px-4 py-2.5 text-[13.5px] font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'card'
                    ? 'bg-[#E7FF4B] text-[#030B2C] font-semibold'
                    : 'text-white/75 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>Card Payment</span>
              </button>

              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'promo'}
                onClick={() => setActiveTab('promo')}
                className={`inline-flex items-center gap-2 px-4 py-2.5 text-[13.5px] font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'promo'
                    ? 'bg-[#E7FF4B] text-[#030B2C] font-semibold'
                    : 'text-white/75 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Tag className="w-4 h-4" />
                <span>Promotional Code</span>
              </button>

              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'packages'}
                onClick={() => setActiveTab('packages')}
                className={`inline-flex items-center gap-2 px-4 py-2.5 text-[13.5px] font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'packages'
                    ? 'bg-[#1769F4] text-white'
                    : 'text-white/75 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Layers className="w-4 h-4" />
                <span>Packages</span>
              </button>
            </div>
          </div>

          {/* KPI Summary Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="rounded-xl bg-[#05123D] border border-white/10 p-5">
              <p className="text-[11.5px] font-semibold uppercase tracking-[0.12em] text-white/50">
                Selected Package
              </p>
              <p className="font-display font-medium text-[16px] text-white mt-1.5 truncate">
                {selectedPackage.category}
              </p>
              <p className="text-[12.5px] text-[#BFE8FF] mt-0.5 truncate">
                ${selectedPackage.amountUsd.toLocaleString()}.00 · {selectedPackage.billingCycle}
              </p>
            </div>

            <div className="rounded-xl bg-[#05123D] border border-white/10 p-5">
              <p className="text-[11.5px] font-semibold uppercase tracking-[0.12em] text-white/50">
                Card Billing Status
              </p>
              <p className="font-display font-medium text-[16px] text-rose-300 mt-1.5">
                Unavailable
              </p>
              <p className="text-[12.5px] text-white/60 mt-0.5">No card data collected or stored</p>
            </div>

            <div className="rounded-xl bg-[#05123D] border border-white/10 p-5">
              <p className="text-[11.5px] font-semibold uppercase tracking-[0.12em] text-white/50">
                Promotional Access
              </p>
              <p className="font-display font-medium text-[16px] text-[#E7FF4B] mt-1.5">
                Active
              </p>
              <p className="text-[12.5px] text-white/60 mt-0.5">Unlocks all Our Work images</p>
            </div>

            <div className="rounded-xl bg-[#05123D] border border-white/10 p-5">
              <p className="text-[11.5px] font-semibold uppercase tracking-[0.12em] text-white/50">
                Our Work Previews
              </p>
              <p className="font-display font-medium text-[22px] text-white mt-1 tabular-nums">
                {unlockedWorkCount} / {PORTFOLIO_PROJECTS.length}
              </p>
              <p className="text-[12.5px] text-white/60 mt-0.5">
                {unlockedWorkCount === PORTFOLIO_PROJECTS.length
                  ? 'All previews unlocked'
                  : 'Blurred until unlocked'}
              </p>
            </div>
          </div>

          {/* TAB 1: CARD PAYMENT (NO CARD DATA COLLECTED OR STORED) */}
          {activeTab === 'card' && (
            <motion.div
              key="card"
              initial={prefersReducedMotion ? false : {opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              transition={{duration: 0.25}}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
            >
              {/* Left Column: Selected Item Summary + Blurred Preview */}
              <div className="lg:col-span-5 rounded-2xl bg-[#05123D] border border-[#BFE8FF]/18 p-6 sm:p-7 space-y-6">
                <div>
                  <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-[#BFE8FF]/80">
                    Order Summary
                  </p>
                  <h2 className="font-display font-medium text-[22px] tracking-[-0.02em] text-white mt-1">
                    {selectedPackage.title}
                  </h2>
                  <p className="text-[13px] text-white/60 mt-1">
                    {selectedPackage.category} · {selectedPackage.billingCycle}
                  </p>
                </div>

                <div>
                  <label
                    htmlFor="card-tab-package-select"
                    className="block text-[11.5px] font-semibold uppercase tracking-[0.12em] text-white/50 mb-2"
                  >
                    Selected Item
                  </label>
                  <select
                    id="card-tab-package-select"
                    value={selectedPackage.id}
                    onChange={(e) => {
                      setSelectedPackageId(e.target.value);
                      setCardAttemptDeclined(false);
                    }}
                    className="w-full rounded-lg bg-[#081A52] border border-white/15 px-3.5 py-2.5 text-[13.5px] text-white focus:outline-none focus:ring-2 focus:ring-[#4398FF]"
                  >
                    {PAYMENT_PACKAGES.map((pkg) => (
                      <option key={pkg.id} value={pkg.id} className="bg-[#05123D] text-white">
                        {pkg.title} — ${pkg.amountUsd.toLocaleString()}.00
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2.5 pt-2 border-t border-white/10 text-[14px]">
                  <div className="flex items-center justify-between text-white/75">
                    <span>{selectedPackage.category}</span>
                    <span className="font-mono tabular-nums text-white">
                      ${selectedPackage.amountUsd.toLocaleString()}.00
                    </span>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="font-medium text-white">Total Due (USD)</span>
                    <span className="font-display font-semibold text-[26px] text-[#E7FF4B] tabular-nums">
                      ${selectedPackage.amountUsd.toLocaleString()}.00
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Column: Card Processing Disabled / Declined Notice (Zero Card Inputs) */}
              <div className="lg:col-span-7 rounded-2xl bg-white text-[#101421] p-6 sm:p-8 shadow-[0_28px_80px_rgba(3,11,44,0.55)] space-y-6">
                <div className="flex items-center justify-between gap-3 pb-5 border-b border-[#101421]/10">
                  <div>
                    <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-[#1769F4]">
                      Card Payment Tab
                    </p>
                    <h2 className="font-display font-medium text-[22px] tracking-[-0.02em] text-[#101421] mt-0.5">
                      Direct Card Payment
                    </h2>
                  </div>
                  <CreditCard className="w-6 h-6 text-[#0B328D]" />
                </div>

                {cardAttemptDeclined && (
                  <div
                    role="alert"
                    className="rounded-xl bg-rose-50 border border-rose-200 p-4 flex items-start gap-3 text-[13.5px] text-rose-700"
                  >
                    <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5 text-rose-600" />
                    <div>
                      <p className="font-semibold text-rose-800">Card Payment Rejected</p>
                      <p className="mt-0.5 leading-relaxed">
                        Direct card transactions are currently disabled for this portal and cannot
                        be authorized. No card information is collected or stored. Switch to the{' '}
                        <strong>Promotional Code</strong> tab to unlock access instead.
                      </p>
                    </div>
                  </div>
                )}

                <div className="rounded-xl bg-[#FAFBFD] border border-[#101421]/10 p-5 space-y-3">
                  <p className="text-[14.5px] font-medium text-[#101421]">
                    Online card authorization is currently paused
                  </p>
                  <p className="text-[13.5px] leading-relaxed text-[#101421]/68">
                    For security, Galaxy Media does not collect or save credit card details inside
                    this portal. Card payment attempts are automatically rejected until a live
                    merchant processor is connected. Use the{' '}
                    <strong className="text-[#101421]">Promotional Code</strong> tab to unlock all
                    Our Work images instantly.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => setCardAttemptDeclined(true)}
                    className="inline-flex items-center justify-center gap-2 px-5 py-3 text-[14px] font-semibold text-white bg-[#030B2C] hover:bg-[#0B328D] rounded-lg transition-colors cursor-pointer"
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>Attempt Card Payment (${selectedPackage.amountUsd.toLocaleString()})</span>
                  </button>

                  <MagneticButton
                    type="button"
                    onClick={() => setActiveTab('promo')}
                    proximity={36}
                    maxPull={6}
                    className="inline-flex items-center justify-center gap-2 px-5 py-3 text-[14px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-lg transition-colors"
                  >
                    <Tag className="w-4 h-4" />
                    <span>Open Promotional Code Tab</span>
                  </MagneticButton>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 2: PROMOTIONAL CODE REDEMPTION */}
          {activeTab === 'promo' && (
            <motion.div
              key="promo"
              initial={prefersReducedMotion ? false : {opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              transition={{duration: 0.25}}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
            >
              {/* Left Column: Selected Item + Live Blurred/Unblurred Preview */}
              <div className="lg:col-span-5 rounded-2xl bg-[#05123D] border border-[#BFE8FF]/18 p-6 sm:p-7 space-y-6">
                <div>
                  <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-[#BFE8FF]/80">
                    Selected Unlock
                  </p>
                  <h2 className="font-display font-medium text-[22px] tracking-[-0.02em] text-white mt-1">
                    {selectedPackage.title}
                  </h2>
                  <p className="text-[13px] text-white/60 mt-1">
                    {selectedPackage.category} · {selectedPackage.billingCycle}
                  </p>
                </div>

                <div className="space-y-2.5 pt-2 border-t border-white/10 text-[14px]">
                  <div className="flex items-center justify-between text-white/75">
                    <span>Standard Price</span>
                    <span
                      className={`font-mono tabular-nums ${
                        isSelectedUnlocked ? 'line-through text-white/45' : 'text-white'
                      }`}
                    >
                      ${selectedPackage.amountUsd.toLocaleString()}.00
                    </span>
                  </div>
                  {isSelectedUnlocked && (
                    <div className="flex items-center justify-between text-[#E7FF4B] text-[13px]">
                      <span>Promotional Code ({VALID_PROMO_CODE})</span>
                      <span className="font-mono tabular-nums">
                        -${selectedPackage.amountUsd.toLocaleString()}.00
                      </span>
                    </div>
                  )}
                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="font-medium text-white">Total Due (USD)</span>
                    <span className="font-display font-semibold text-[26px] text-[#E7FF4B] tabular-nums">
                      {isSelectedUnlocked
                        ? '$0.00'
                        : `$${selectedPackage.amountUsd.toLocaleString()}.00`}
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Column: Promotional Code Form */}
              <div className="lg:col-span-7 rounded-2xl bg-white text-[#101421] p-6 sm:p-8 shadow-[0_28px_80px_rgba(3,11,44,0.55)]">
                <div className="flex items-center justify-between gap-3 pb-5 border-b border-[#101421]/10">
                  <div>
                    <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-[#1769F4]">
                      Promotional Code Redemption
                    </p>
                    <h2 className="font-display font-medium text-[22px] tracking-[-0.02em] text-[#101421] mt-0.5">
                      Unlock with Promotional Code
                    </h2>
                  </div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#030B2C] text-white text-[12px] font-semibold">
                    <Tag className="w-3.5 h-3.5 text-[#E7FF4B]" />
                    <span>Promo Access</span>
                  </div>
                </div>

                {isSelectedUnlocked || promoApplied ? (
                  <div className="mt-6 space-y-5">
                    <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-5 flex items-start gap-3.5">
                      <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <p className="font-display font-semibold text-[17px] text-emerald-950">
                          Promotional Code Applied — All Our Work Previews Unlocked
                        </p>
                        <p className="text-[13.5px] text-emerald-800 leading-relaxed">
                          Code <span className="font-mono font-semibold">{VALID_PROMO_CODE}</span>{' '}
                          has unlocked all portfolio previews on Our Work ($0.00 due).
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <MagneticButton
                        type="button"
                        onClick={onBack}
                        proximity={36}
                        maxPull={6}
                        className="inline-flex items-center justify-center gap-2 px-6 py-3 text-[14.5px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-lg transition-colors"
                      >
                        <Unlock className="w-4 h-4" />
                        <span>View Unlocked Our Work</span>
                      </MagneticButton>

                      <button
                        type="button"
                        onClick={() => {
                          setPromoApplied(false);
                          setPromoInput('');
                          onResetLocks();
                        }}
                        className="px-4 py-3 text-[13.5px] font-medium text-[#101421]/70 hover:text-[#101421] border border-[#101421]/15 rounded-lg transition-colors cursor-pointer"
                      >
                        Re-lock Previews
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleRedeemPromo} className="mt-6 space-y-5">
                    {promoError && (
                      <div
                        role="alert"
                        className="rounded-lg bg-rose-50 border border-rose-200 px-4 py-3 text-[13.5px] text-rose-700 flex items-start gap-2.5"
                      >
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{promoError}</span>
                      </div>
                    )}

                    <div>
                      <label
                        htmlFor="promo-code-input"
                        className="block text-[13px] font-medium text-[#101421]/80 mb-1.5"
                      >
                        Enter Promotional Code
                      </label>
                      <input
                        id="promo-code-input"
                        type="text"
                        autoComplete="off"
                        value={promoInput}
                        onChange={(e) => {
                          setPromoInput(e.target.value.toUpperCase());
                          if (promoError) setPromoError(null);
                        }}
                        placeholder="Enter promotional code"
                        className="w-full rounded-lg border border-[#101421]/15 bg-[#FAFBFD] px-4 py-3 font-mono text-[15px] tracking-[0.06em] uppercase text-[#101421] placeholder:font-sans placeholder:tracking-normal placeholder:normal-case placeholder:text-[#101421]/40 focus:outline-none focus:ring-2 focus:ring-[#1769F4]"
                      />
                    </div>

                    <div className="pt-1">
                      <MagneticButton
                        type="submit"
                        proximity={40}
                        maxPull={6}
                        className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 text-[15px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-lg transition-colors"
                      >
                        <Tag className="w-4 h-4" />
                        <span>Apply Promotional Code</span>
                      </MagneticButton>
                    </div>
                  </form>
                )}
              </div>
            </motion.div>
          )}

          {/* TAB 3: PACKAGES */}
          {activeTab === 'packages' && (
            <motion.div
              key="packages"
              initial={prefersReducedMotion ? false : {opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              transition={{duration: 0.25}}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              {PAYMENT_PACKAGES.map((pkg) => {
                const isSelected = pkg.id === selectedPackage.id;
                const pkgUnlocked = Boolean(unlockedProjects[pkg.id]);
                return (
                  <div
                    key={pkg.id}
                    className={`rounded-2xl p-6 sm:p-7 flex flex-col justify-between border transition-colors ${
                      isSelected
                        ? 'bg-[#07184B] border-[#4398FF]/65 shadow-[0_20px_50px_rgba(3,11,44,0.45)]'
                        : 'bg-[#05123D] border-white/10 hover:border-white/25'
                    }`}
                  >
                    <div className="space-y-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-[#BFE8FF]/80">
                            {pkg.category} · {pkg.billingCycle}
                          </p>
                          <h2 className="font-display font-medium text-[20px] text-white tracking-[-0.02em] mt-1">
                            {pkg.title}
                          </h2>
                        </div>
                        <span className="font-display font-semibold text-[24px] text-[#E7FF4B] tabular-nums shrink-0">
                          {pkgUnlocked ? 'Unlocked' : `$${pkg.amountUsd.toLocaleString()}`}
                        </span>
                      </div>

                      <p className="text-[14px] leading-relaxed text-white/70">{pkg.summary}</p>

                      <ul className="space-y-2 pt-2 border-t border-white/10 text-[13.5px] text-white/80">
                        {pkg.deliverables.map((item) => (
                          <li key={item} className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-[#4398FF] shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-6 pt-5 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => handleSelectPackage(pkg.id, 'card')}
                        className="text-[13px] font-medium text-white/75 hover:text-white transition-colors cursor-pointer"
                      >
                        Card Payment
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectPackage(pkg.id, 'promo')}
                        className="inline-flex items-center gap-1.5 px-4 py-2.5 text-[13.5px] font-semibold text-[#030B2C] bg-[#E7FF4B] hover:bg-[#dcfa2d] rounded-md transition-colors whitespace-nowrap cursor-pointer"
                      >
                        <span>{pkgUnlocked ? 'Manage Access' : 'Use Promotional Code'}</span>
                        <ArrowUpRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </motion.div>
          )}
        </div>
      </main>
    </div>
  );
}
