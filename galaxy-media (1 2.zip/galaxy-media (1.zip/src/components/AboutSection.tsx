import {Reveal} from './Reveal';

export function AboutSection() {
  return (
    <section
      id="about"
      className="bg-[#FAFBFD] py-24 sm:py-28 md:py-36 border-t border-[#101421]/[0.07]"
    >
      <div className="mx-auto max-w-[1320px] px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
          {/* Left: Royal-blue architectural statement visual (inspired by Frame 00:09) */}
          <Reveal className="lg:col-span-6 flex">
            <div
              className="relative w-full rounded-2xl overflow-hidden p-8 sm:p-11 md:p-12 flex flex-col justify-between text-white min-h-[360px]"
              style={{
                background:
                  'linear-gradient(145deg, #030B2C 0%, #0B328D 55%, #1769F4 100%)',
              }}
            >
              {/* Subtle editorial dot field */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute right-0 top-0 w-64 h-64 halftone-dots-card opacity-40"
                style={{
                  maskImage: 'radial-gradient(circle at 100% 0%, black 0%, transparent 72%)',
                  WebkitMaskImage: 'radial-gradient(circle at 100% 0%, black 0%, transparent 72%)',
                }}
              />

              {/* Restrained geometric orbital motif */}
              <svg
                aria-hidden="true"
                viewBox="0 0 400 220"
                fill="none"
                className="pointer-events-none absolute -right-10 -bottom-10 w-[340px] opacity-25"
              >
                <circle cx="240" cy="140" r="130" stroke="#BFE8FF" strokeWidth="1" />
                <circle
                  cx="240"
                  cy="140"
                  r="86"
                  stroke="#BFE8FF"
                  strokeWidth="1"
                  strokeDasharray="3 6"
                />
                <circle cx="162" cy="102" r="3.5" fill="#E7FF4B" />
              </svg>

              <div className="relative z-10">
                <p className="text-[12px] font-semibold tracking-[0.14em] uppercase text-[#BFE8FF]/85 mb-5">
                  About Galaxy Media
                </p>
                <h2 className="font-display font-medium text-white tracking-[-0.03em] leading-[1.08] text-[clamp(2rem,3.6vw,3.15rem)] [text-wrap:balance]">
                  Independent thinking.
                  <br />
                  Collective creativity.
                </h2>
              </div>

              <div className="relative z-10 mt-12 pt-6 border-t border-white/15 flex flex-wrap items-center justify-between gap-4 text-[13px] text-[#BFE8FF]/80">
                <span>Digital-first creative media studio</span>
                <span className="font-mono text-white/65">YouTube &amp; Original Formats</span>
              </div>
            </div>
          </Reveal>

          {/* Right: Spacious Editorial Copy & Operating Ethos */}
          <Reveal delay={0.08} className="lg:col-span-6 flex flex-col justify-between py-2">
            <div>
              <p className="text-[19px] sm:text-[22px] leading-[1.55] text-[#101421] font-display font-normal tracking-[-0.015em]">
                Galaxy Media is a digital-first creative media company focused on developing
                content, building memorable media brands, and bringing ambitious storytelling ideas
                to life.
              </p>

              <p className="mt-6 text-[16px] leading-[1.7] text-[#101421]/68">
                We partner with creators, channel owners, founders, and media-minded organizations
                who care deeply about craft. Rather than treating video as disposable marketing, we
                approach every channel like an enduring editorial publication—anchored in sharp
                research, thoughtful pacing, and unmistakable visual identity.
              </p>
            </div>

            <div className="mt-10 pt-8 border-t border-[#101421]/10 grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <h3 className="font-display font-medium text-[15.5px] text-[#101421] mb-1.5">
                  Editorial Standards
                </h3>
                <p className="text-[14.5px] leading-[1.6] text-[#101421]/62">
                  Every concept, hook, and cut is evaluated on whether a viewer genuinely values the
                  time they spend watching.
                </p>
              </div>
              <div>
                <h3 className="font-display font-medium text-[15.5px] text-[#101421] mb-1.5">
                  Long-Term Partnership
                </h3>
                <p className="text-[14.5px] leading-[1.6] text-[#101421]/62">
                  We build repeatable production systems designed to evolve alongside your channel
                  and audience.
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
