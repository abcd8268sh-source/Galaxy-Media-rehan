export interface ServiceItem {
  number: string;
  title: string;
  summary: string;
  deliverables: string[];
  cadenceNote: string;
}

export interface PortfolioProject {
  id: string;
  title: string;
  category: 'Documentary' | 'Creator Series' | 'Brand Channel';
  productionType: string;
  description: string;
  overview: string;
  scope: string[];
  featured?: boolean;
  sampleNote: string;
  externalUrlPlaceholder: string;
}

export interface ProcessStep {
  number: string;
  phaseLabel: string;
  title: string;
  description: string;
  outputs: string[];
}

export interface ContentFormat {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  runtime: string;
  style: string;
  description: string;
  exampleHeadline: string;
  beats: string[];
  bestFor: string;
}

export interface DashboardPoint {
  label: string;
  views: number;
  retention: number;
  watchHours: number;
}

export interface DashboardDataset {
  id: '30D' | '90D' | '12M';
  rangeLabel: string;
  totalViews: string;
  viewsDelta: string;
  avgRetention: string;
  ctr: string;
  watchHours: string;
  episodesShipped: string;
  points: DashboardPoint[];
  retentionCurve: number[];
}

export const NAV_LINKS = [
  {label: 'Home', href: '#home', id: 'home'},
  {label: 'Services', href: '#services', id: 'services'},
  {label: 'Our Work', href: '#work', id: 'work'},
  {label: 'Formats', href: '#formats', id: 'formats'},
  {label: 'Process', href: '#process', id: 'process'},
  {label: 'About', href: '#about', id: 'about'},
] as const;

export const DASHBOARD_DATASETS: Record<'30D' | '90D' | '12M', DashboardDataset> = {
  '30D': {
    id: '30D',
    rangeLabel: 'Last 30 days',
    totalViews: '842,600',
    viewsDelta: '+14.2%',
    avgRetention: '66.8%',
    ctr: '8.9%',
    watchHours: '118.4k hrs',
    episodesShipped: '6 releases',
    points: [
      {label: 'Day 01', views: 19200, retention: 63, watchHours: 2800},
      {label: 'Day 05', views: 24800, retention: 65, watchHours: 3420},
      {label: 'Day 10', views: 23400, retention: 64, watchHours: 3180},
      {label: 'Day 15', views: 31500, retention: 68, watchHours: 4510},
      {label: 'Day 20', views: 36900, retention: 67, watchHours: 5240},
      {label: 'Day 25', views: 41200, retention: 70, watchHours: 5890},
      {label: 'Day 30', views: 47800, retention: 71, watchHours: 6620},
    ],
    retentionCurve: [100, 86, 78, 74, 71, 68, 66, 62, 56],
  },
  '90D': {
    id: '90D',
    rangeLabel: 'Last 90 days',
    totalViews: '2,418,300',
    viewsDelta: '+28.4%',
    avgRetention: '68.4%',
    ctr: '9.4%',
    watchHours: '342.1k hrs',
    episodesShipped: '18 releases',
    points: [
      {label: 'Wk 01', views: 142000, retention: 61, watchHours: 19800},
      {label: 'Wk 03', views: 168000, retention: 64, watchHours: 23400},
      {label: 'Wk 05', views: 191000, retention: 66, watchHours: 27100},
      {label: 'Wk 07', views: 184000, retention: 65, watchHours: 26300},
      {label: 'Wk 09', views: 236000, retention: 69, watchHours: 33900},
      {label: 'Wk 11', views: 274000, retention: 71, watchHours: 39200},
      {label: 'Wk 13', views: 312000, retention: 72, watchHours: 44600},
    ],
    retentionCurve: [100, 88, 81, 76, 73, 70, 68, 65, 59],
  },
  '12M': {
    id: '12M',
    rangeLabel: 'Trailing 12 months',
    totalViews: '8,940,500',
    viewsDelta: '+64.0%',
    avgRetention: '69.1%',
    ctr: '9.8%',
    watchHours: '1.28M hrs',
    episodesShipped: '64 releases',
    points: [
      {label: 'Jan', views: 410000, retention: 60, watchHours: 58000},
      {label: 'Mar', views: 540000, retention: 63, watchHours: 76000},
      {label: 'May', views: 690000, retention: 66, watchHours: 98000},
      {label: 'Jul', views: 780000, retention: 68, watchHours: 112000},
      {label: 'Sep', views: 940000, retention: 70, watchHours: 136000},
      {label: 'Nov', views: 1120000, retention: 71, watchHours: 161000},
      {label: 'Dec', views: 1290000, retention: 73, watchHours: 186000},
    ],
    retentionCurve: [100, 89, 82, 78, 74, 71, 69, 66, 61],
  },
};

export const PUBLISHING_TIMELINE_SAMPLE = [
  {
    code: 'EP 19',
    title: 'Long-Form Documentary Pilot',
    stage: 'Color & Sound Mix',
    progress: 86,
    window: 'Scheduled Thu',
  },
  {
    code: 'EP 20',
    title: 'Founder Deep-Dive Essay',
    stage: 'Motion Graphics Pass',
    progress: 58,
    window: 'Next Week',
  },
  {
    code: 'EP 21',
    title: 'Packaging & Thumbnail Concepts',
    stage: 'Script Lock',
    progress: 34,
    window: 'In Development',
  },
];

export const SERVICES: ServiceItem[] = [
  {
    number: '01',
    title: 'Content Strategy',
    summary:
      'Research, audience analysis, content positioning, video ideas, and channel direction.',
    deliverables: ['Audience & topic mapping', 'Format architecture', 'Quarterly editorial roadmap'],
    cadenceNote: 'Foundation & ongoing alignment',
  },
  {
    number: '02',
    title: 'Scriptwriting & Storytelling',
    summary:
      'Narrative development, compelling hooks, retention-driven scripting, and researched storytelling.',
    deliverables: ['Story structure & beats', 'Opening hook engineering', 'Research-backed scripts'],
    cadenceNote: 'Story lock before edit',
  },
  {
    number: '03',
    title: 'Video Production',
    summary:
      'Voiceover workflows, video editing, motion graphics, visual storytelling, and complete content production.',
    deliverables: ['Editorial cut & pacing', 'Bespoke motion graphics', 'Sound design & final grade'],
    cadenceNote: 'End-to-end post-production',
  },
  {
    number: '04',
    title: 'Thumbnails & Packaging',
    summary:
      'Visual concepts, thumbnail design, title development, and content packaging.',
    deliverables: ['Concept framing & titles', 'Custom visual composition', 'Packaging iteration'],
    cadenceNote: 'Developed alongside the idea',
  },
  {
    number: '05',
    title: 'Channel Development',
    summary:
      'Content planning, production operations, publishing workflows, and channel optimization.',
    deliverables: ['Production systems', 'Publishing cadence & metadata', 'Post-release review loops'],
    cadenceNote: 'Built for repeatable scale',
  },
];

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'meridian-archive',
    title: 'The Architecture of Modern Systems',
    category: 'Documentary',
    productionType: 'Long-Form Documentary Series',
    description:
      'A researched visual essay format exploring design, engineering, and human stories with cinema-grade pacing and custom motion sequences.',
    overview:
      'Designed as a flagship YouTube documentary template demonstrating end-to-end narrative research, custom visual storytelling, and theatrical sound design. Replace this editable sample entry with your live documentary case study and YouTube playlist link.',
    scope: ['Content Strategy', 'Documentary Scriptwriting', 'Video Production', 'Packaging'],
    featured: true,
    sampleNote: 'Editable sample project concept',
    externalUrlPlaceholder: 'https://youtube.com',
  },
  {
    id: 'studio-chronicles',
    title: 'Inside the Modern Editing Suite',
    category: 'Creator Series',
    productionType: 'Creator Flagship Production',
    description:
      'High-retention storytelling built around an editorial host, blending narrative interviews with tight visual rhythm and crisp packaging.',
    overview:
      'Illustrates Galaxy Media’s turnkey creator production workflow—from topic selection and script beats through editorial cut, color grading, and title-thumbnail framing. Editable placeholder ready for genuine channel links.',
    scope: ['Story Development', 'Editorial Post-Production', 'Sound & Color', 'Thumbnails'],
    featured: true,
    sampleNote: 'Editable sample project concept',
    externalUrlPlaceholder: 'https://youtube.com',
  },
  {
    id: 'signal-broadcast',
    title: 'Founders & Makers Studio Format',
    category: 'Brand Channel',
    productionType: 'Episodic Brand Channel',
    description:
      'An owned digital media channel structured for recurring episodes, recognizable studio visual identity, and durable audience loyalty.',
    overview:
      'Demonstrates a repeatable studio format for businesses and founders building an authority YouTube presence. Covers set visual language, episode architecture, and publishing workflow.',
    scope: ['Channel Development', 'Format Design', 'Multi-Camera Post', 'Publishing Ops'],
    featured: false,
    sampleNote: 'Editable sample project concept',
    externalUrlPlaceholder: 'https://youtube.com',
  },
  {
    id: 'packaging-craft',
    title: 'Visual Identity & Storyboard Systems',
    category: 'Brand Channel',
    productionType: 'Packaging & Creative Direction',
    description:
      'Cohesive title architecture, storyboard planning, and custom thumbnail art direction built to make every upload instantly recognizable.',
    overview:
      'Showcases how pre-production storyboarding and packaging direction work together before an edit begins, establishing a consistent visual signature across an entire channel library.',
    scope: ['Thumbnails & Packaging', 'Art Direction', 'Title Architecture'],
    featured: false,
    sampleNote: 'Editable sample project concept',
    externalUrlPlaceholder: 'https://youtube.com',
  },
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    number: '01',
    phaseLabel: 'Stage 01',
    title: 'Discover',
    description:
      'Understand the audience, uncover compelling opportunities, and define the creative direction.',
    outputs: ['Audience positioning brief', 'High-conviction topic slate', 'Channel opportunity audit'],
  },
  {
    number: '02',
    phaseLabel: 'Stage 02',
    title: 'Develop',
    description:
      'Research the story, structure the narrative, and craft the concept.',
    outputs: ['Packaging & title concepts', 'Narrative outline & hook', 'Production-ready script'],
  },
  {
    number: '03',
    phaseLabel: 'Stage 03',
    title: 'Produce',
    description:
      'Transform the concept into a polished video with thoughtful editing, visuals, and sound.',
    outputs: ['Voiceover & narrative assembly', 'Motion graphics & visual pacing', 'Final mix, color & thumbnail'],
  },
  {
    number: '04',
    phaseLabel: 'Stage 04',
    title: 'Refine',
    description:
      'Review performance, improve the creative approach, and plan the next production.',
    outputs: ['Retention & drop-off review', 'Packaging takeaway notes', 'Next-episode iteration plan'],
  },
];

export const CONTENT_FORMATS: ContentFormat[] = [
  {
    id: 'explainer-format',
    number: '01',
    title: 'Explainer Format',
    subtitle: 'Visual Clarity for Complex Ideas',
    runtime: '12–18 min',
    style: 'Motion-Led Visual Essay',
    description:
      'Breaks down complex systems, science, economics, or technology into intuitive visual stories powered by bespoke motion graphics, clear analogies, and tight retention pacing.',
    exampleHeadline: '“How [Complex System] Actually Works Under the Hood”',
    beats: ['Curiosity Hook', 'Core Mental Model', 'Visual Breakdown', 'Real-World Payoff'],
    bestFor: 'Tech, finance, science, and education channels built for evergreen discovery.',
  },
  {
    id: '7-levels-of',
    number: '02',
    title: '7 Levels Of...',
    subtitle: 'Escalating Stakes & Tiered Mastery',
    runtime: '15–24 min',
    style: 'Progressive Escalation Series',
    description:
      'Guides viewers through seven escalating tiers—from entry-level basics to world-class execution—using clear chapter milestones and rising curiosity to hold watch time.',
    exampleHeadline: '“7 Levels of [Craft / Skill / System]: Beginner to Master”',
    beats: ['Level 1 Baseline', 'Mid-Tier Shift', 'Expert Escalation', 'Level 7 Climax'],
    bestFor: 'Creator flagship series, engineering breakdowns, and repeatable signature formats.',
  },
  {
    id: 'the-rise-and-fall-of',
    number: '03',
    title: 'The Rise and Fall Of...',
    subtitle: 'High-Stakes Narrative Documentary',
    runtime: '20–35 min',
    style: 'Mini-Documentary Arc',
    description:
      'Chronicles the ambition, peak dominance, decisive turning points, and eventual unraveling of iconic brands, movements, or cultural moments with theatrical pacing and deep research.',
    exampleHeadline: '“The Rise and Fall of [Iconic Brand or Movement]”',
    beats: ['Cold Open Peak', 'Meteoric Ascent', 'The Turning Point', 'Collapse & Legacy'],
    bestFor: 'Business documentaries, culture commentary, and founder storytelling channels.',
  },
  {
    id: 'the-entire-history-of',
    number: '04',
    title: 'The Entire History Of...',
    subtitle: 'Definitive Long-Form Anthology',
    runtime: '30–60+ min',
    style: 'Comprehensive Deep-Dive',
    description:
      'Delivers the complete, chronological chronicle of an industry, technology, franchise, or era in a single binge-worthy tentpole release engineered for high session watch time.',
    exampleHeadline: '“The Entire History of [Industry / Phenomenon], Explained”',
    beats: ['Origins & Catalyst', 'Defining Eras', 'Pivotal Shifts', 'Modern Legacy'],
    bestFor: 'Tentpole documentary channels and brands building authoritative flagship libraries.',
  },
];

export const CONTACT_SERVICE_OPTIONS = [
  'Content Strategy',
  'Scriptwriting & Storytelling',
  'Full Video Production',
  'Thumbnails & Packaging',
  'Channel Development & Retainer',
  'General Inquiry',
] as const;
