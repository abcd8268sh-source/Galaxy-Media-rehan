/**
 * Security Rules Specification Verification Matrix (Dirty Dozen)
 *
 * Designed to be executed against the Firebase Emulator Suite (`@firebase/rules-unit-testing`)
 * to validate every rule in `firestore.rules` against the 12 adversarial payloads documented in `security_spec.md`.
 */

export interface SecurityTestCase {
  id: number;
  name: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  path: string;
  auth: {uid: string; email?: string; email_verified: boolean} | null;
  payload?: Record<string, unknown>;
  expected: 'PERMISSION_DENIED';
  enforcingGate: string;
}

export const DIRTY_DOZEN_SECURITY_CASES: SecurityTestCase[] = [
  {
    id: 1,
    name: 'Unauthenticated Profile Read & List',
    operation: 'list',
    path: '/users',
    auth: null,
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'isBootstrappedAdmin() requires request.auth != null',
  },
  {
    id: 2,
    name: 'Cross-User PII Read (PII Blanket Test)',
    operation: 'get',
    path: '/users/victimUid',
    auth: {uid: 'attackerUid', email: 'attacker@example.com', email_verified: true},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'isOwner(userId) || isBootstrappedAdmin() blocks non-owner regular users',
  },
  {
    id: 3,
    name: 'Admin Email Spoofing Attack (Email Spoofing Test)',
    operation: 'list',
    path: '/users',
    auth: {uid: 'spoofUid', email: 'abcd8268sh@gmail.com', email_verified: false},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'isBootstrappedAdmin() mandates isVerified() (email_verified == true)',
  },
  {
    id: 4,
    name: 'Identity Spoofing on Create',
    operation: 'create',
    path: '/users/attackerUid',
    auth: {uid: 'attackerUid', email: 'a@example.com', email_verified: true},
    payload: {uid: 'victimUid', displayName: 'Attacker', email: 'a@example.com'},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'isValidUserProfile checks data.uid == request.auth.uid && data.uid == userId',
  },
  {
    id: 5,
    name: 'Shadow Field Injection (Shadow Update Test)',
    operation: 'create',
    path: '/users/attackerUid',
    auth: {uid: 'attackerUid', email: 'a@example.com', email_verified: true},
    payload: {uid: 'attackerUid', isAdmin: true, role: 'superadmin'},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'isValidUserProfile enforces data.keys().hasOnly([...])',
  },
  {
    id: 6,
    name: 'Immutable createdAt Tampering',
    operation: 'update',
    path: '/users/attackerUid',
    auth: {uid: 'attackerUid', email: 'a@example.com', email_verified: true},
    payload: {createdAt: '2020-01-01T00:00:00Z'},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'allow update checks incoming().createdAt == existing().createdAt and affectedKeys().hasOnly([...])',
  },
  {
    id: 7,
    name: 'Client-Forged Timestamp',
    operation: 'create',
    path: '/users/attackerUid/sessions/sess_1',
    auth: {uid: 'attackerUid', email: 'a@example.com', email_verified: true},
    payload: {userId: 'attackerUid', createdAt: '2022-01-01T00:00:00Z'},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'allow create enforces incoming().createdAt == request.time',
  },
  {
    id: 8,
    name: 'Orphaned Subcollection Write (Master Gate)',
    operation: 'create',
    path: '/users/orphanUid/sessions/sess_1',
    auth: {uid: 'orphanUid', email: 'o@example.com', email_verified: true},
    payload: {userId: 'orphanUid'},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'parentUserExists(userId) verifies parent /users/{userId} exists()',
  },
  {
    id: 9,
    name: 'ID Poisoning Attack',
    operation: 'create',
    path: '/users/attackerUid/sessions/invalid!@#id',
    auth: {uid: 'attackerUid', email: 'a@example.com', email_verified: true},
    payload: {userId: 'attackerUid'},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'isValidId(sessionId) enforces ^[a-zA-Z0-9_\\-]+$ and <= 128 chars',
  },
  {
    id: 10,
    name: 'Value Poisoning / Oversized Chat Content or Invalid Role',
    operation: 'create',
    path: '/users/attackerUid/chatMessages/msg_1',
    auth: {uid: 'attackerUid', email: 'a@example.com', email_verified: true},
    payload: {userId: 'attackerUid', role: 'system', content: 'x'.repeat(9000)},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'isValidChatMessage restricts role to user|model and content.size() <= 8000',
  },
  {
    id: 11,
    name: 'Forbidden Immutable Session Mutation',
    operation: 'update',
    path: '/users/attackerUid/sessions/sess_1',
    auth: {uid: 'attackerUid', email: 'a@example.com', email_verified: true},
    payload: {ipAddress: '127.0.0.1'},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'allow update: if false on /users/{userId}/sessions/{sessionId}',
  },
  {
    id: 12,
    name: 'Cross-User Subcollection List Query',
    operation: 'list',
    path: '/users/victimUid/sessions',
    auth: {uid: 'attackerUid', email: 'a@example.com', email_verified: true},
    expected: 'PERMISSION_DENIED',
    enforcingGate: 'allow list checks (isOwner(userId) && resource.data.userId == request.auth.uid) || isBootstrappedAdmin()',
  },
];
